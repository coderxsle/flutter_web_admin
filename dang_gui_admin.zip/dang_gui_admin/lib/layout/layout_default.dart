/// @file LayoutDefault 组件
/// @description 默认布局组件，包含左侧边栏和右侧内容区域
import 'package:dang_gui_admin/layout/layout.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

/// 默认布局组件
class LayoutDefault extends StatelessWidget {

  const LayoutDefault({super.key});

  @override
  Widget build(BuildContext context) {
    final appController = Get.find<AppLayoutController>();
    
    return Scaffold(
      // 添加右侧抽屉
      endDrawer: Drawer(
        child: const SettingDrawer(),
      ),
      body: Row(
        children: [
          // 左侧边栏
          const AppAsider(),
          
          // 右侧内容区域
          Expanded(
            child: Column(
              children: [
                // 头部组件
                const AppHeader(),
                
                // 标签页组件（根据设置显示/隐藏）
                Obx(() => appController.tabVisible 
                    ? const AppTabs()
                    : const SizedBox.shrink()),
                
                // 主内容区
                const Main(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
