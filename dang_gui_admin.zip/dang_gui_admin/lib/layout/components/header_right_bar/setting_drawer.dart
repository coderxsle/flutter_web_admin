/// @file SettingDrawer 组件
/// @description 设置抽屉组件，提供布局模式、主题设置等配置选项
import 'package:dang_gui_admin/theme/theme_selector.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../layout_index.dart';

/// 设置抽屉组件
class SettingDrawer extends StatefulWidget {
  const SettingDrawer({super.key});

  @override
  State<SettingDrawer> createState() => SettingDrawerState();
}

class SettingDrawerState extends State<SettingDrawer> {
  /// 缓存的主题数据
  ThemeData? _cachedTheme;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 缓存主题数据以避免在 Obx 中访问已销毁的 context
    _cachedTheme = Theme.of(context);
  }


  @override
  Widget build(BuildContext context) {
    return _buildDrawerContent();
  }

  /// 构建布局模式选择器
  Widget _buildLayoutModeSelector() {
    final appController = Get.find<AppLayoutController>();
    final theme = _cachedTheme ?? Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '布局模式',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: theme.textTheme.titleMedium?.color,
          ),
        ),
        
        const SizedBox(height: 16),
        
        // 布局选项
        Obx(() => Column(
          children: [
            _buildLayoutOption(
              title: '默认布局',
              description: '左侧菜单 + 右侧内容',
              layoutType: LayoutType.defaultLayout,
              currentLayout: appController.layout,
              onChanged: (layout) => appController.layout = layout,
            ),
            
            const SizedBox(height: 12),
            
            _buildLayoutOption(
              title: '混合布局',
              description: '顶部导航 + 左侧菜单',
              layoutType: LayoutType.mix,
              currentLayout: appController.layout,
              onChanged: (layout) => appController.layout = layout,
            ),
            
            const SizedBox(height: 12),
            
            _buildLayoutOption(
              title: '顶部布局',
              description: '顶部横向导航',
              layoutType: LayoutType.top,
              currentLayout: appController.layout,
              onChanged: (layout) => appController.layout = layout,
            ),
          ],
        )),
      ],
    );
  }

  /// 构建布局选项
  Widget _buildLayoutOption({
    required String title,
    required String description,
    required LayoutType layoutType,
    required LayoutType currentLayout,
    required void Function(LayoutType) onChanged,
  }) {
    final theme = _cachedTheme ?? Theme.of(context);
    final isSelected = currentLayout == layoutType;
    
    return GestureDetector(
      onTap: () => onChanged(layoutType),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected 
              ? theme.primaryColor.withOpacity(0.1)
              : theme.cardColor,
          border: Border.all(
            color: isSelected 
                ? theme.primaryColor 
                : theme.dividerColor,
            width: 2,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            // 布局预览图
            Container(
              width: 60,
              height: 40,
              decoration: BoxDecoration(
                color: theme.dividerColor.withOpacity(0.3),
                borderRadius: BorderRadius.circular(4),
              ),
              child: _buildLayoutPreview(layoutType, theme),
            ),
            
            const SizedBox(width: 16),
            
            // 布局信息
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: isSelected 
                          ? theme.primaryColor 
                          : theme.textTheme.titleMedium?.color,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: TextStyle(
                      fontSize: 12,
                      color: theme.textTheme.bodySmall?.color,
                    ),
                  ),
                ],
              ),
            ),
            
            // 选中状态
            if (isSelected)
              Icon(
                Icons.check_circle,
                color: theme.primaryColor,
                size: 20,
              ),
          ],
        ),
      ),
    );
  }

  /// 构建布局预览图
  Widget _buildLayoutPreview(LayoutType layoutType, ThemeData theme) {
    switch (layoutType) {
      case LayoutType.defaultLayout:
        return Row(
          children: [
            Container(
              width: 16,
              height: double.infinity,
              color: theme.primaryColor.withOpacity(0.3),
            ),
            Expanded(
              child: Container(
                color: theme.primaryColor.withOpacity(0.1),
              ),
            ),
          ],
        );
      
      case LayoutType.mix:
        return Column(
          children: [
            Container(
              height: 12,
              color: theme.primaryColor.withOpacity(0.2),
            ),
            Expanded(
              child: Row(
                children: [
                  Container(
                    width: 16,
                    height: double.infinity,
                    color: theme.primaryColor.withOpacity(0.3),
                  ),
                  Expanded(
                    child: Container(
                      color: theme.primaryColor.withOpacity(0.1),
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      
      case LayoutType.top:
        return Column(
          children: [
            Container(
              height: 12,
              color: theme.primaryColor.withOpacity(0.3),
            ),
            Expanded(
              child: Container(
                color: theme.primaryColor.withOpacity(0.1),
              ),
            ),
          ],
        );
    }
  }

  /// 构建主题设置
  Widget _buildThemeSettings() {
    final appController = Get.find<AppLayoutController>();
    final theme = _cachedTheme ?? Theme.of(context);
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '主题设置',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: theme.textTheme.titleMedium?.color,
          ),
        ),
        
        const SizedBox(height: 16),
        
        // 暗黑菜单
        Obx(() => SwitchListTile(
          title: const Text('暗黑菜单'),
          subtitle: const Text('菜单栏使用暗黑主题'),
          value: appController.menuDark,
          onChanged: (value) => appController.menuDark = value,
        )),
        
        // 手风琴菜单
        Obx(() => SwitchListTile(
          title: const Text('手风琴菜单'),
          subtitle: const Text('只展开一个菜单项'),
          value: appController.menuAccordion,
          onChanged: (value) => appController.menuAccordion = value,
        )),
        
        // 标签页可见性
        Obx(() => SwitchListTile(
          title: const Text('显示标签页'),
          subtitle: const Text('是否显示页面标签页'),
          value: appController.tabVisible,
          onChanged: (value) => appController.tabVisible = value,
        )),
      ],
    );
  }

  /// 构建标签页样式设置
  Widget _buildTabStyleSettings() {
    final appController = Get.find<AppLayoutController>();
    final theme = _cachedTheme ?? Theme.of(context);
    
    final tabStyles = [
      {'key': 'line', 'name': '线条样式'},
      {'key': 'card', 'name': '卡片样式'},
      {'key': 'custom1', 'name': '自定义1'},
      {'key': 'custom2', 'name': '标签样式'},
    ];
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '标签页样式',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: theme.textTheme.titleMedium?.color,
          ),
        ),
        
        const SizedBox(height: 16),
        
        Obx(() => Wrap(
          spacing: 8,
          runSpacing: 8,
          children: tabStyles.map((style) {
            final isSelected = appController.tab == style['key'];
            return GestureDetector(
              onTap: () => appController.tab = style['key']!,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: isSelected 
                      ? theme.primaryColor 
                      : theme.cardColor,
                  border: Border.all(
                    color: isSelected 
                        ? theme.primaryColor 
                        : theme.dividerColor,
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  style['name']!,
                  style: TextStyle(
                    fontSize: 12,
                    color: isSelected 
                        ? Colors.white 
                        : theme.textTheme.bodyMedium?.color,
                  ),
                ),
              ),
            );
          }).toList(),
        )),
      ],
    );
  }

  /// 构建抽屉内容
  Widget _buildDrawerContent() {
    final theme = _cachedTheme ?? Theme.of(context);
    return Column(
      children: [
        // 标题
        Row(
          children: [
            const Icon(Icons.color_lens, size: 24),
            const SizedBox(width: 8),
            const Expanded(
              child: Text('主题设置', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.of(context).pop()),
          ],
        ),
        const Divider(),
        // 内容
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
    
                const ThemeSelector(),
    
                const SizedBox(height: 32),
    
                _buildLayoutModeSelector(),
                
                const SizedBox(height: 32),
                
                _buildThemeSettings(),
                
                const SizedBox(height: 32),
                
                _buildTabStyleSettings(),
                
                const SizedBox(height: 32),
                
                // 重置按钮
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _resetSettings,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: theme.colorScheme.error,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('重置设置'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// 重置设置
  void _resetSettings() {
    final appController = Get.find<AppLayoutController>();
    
    Get.dialog(
      AlertDialog(
        title: const Text('确认重置'),
        content: const Text('确定要重置所有设置到默认值吗？'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              // 重置到默认设置
              appController.layout = LayoutType.defaultLayout;
              appController.menuDark = false;
              appController.menuAccordion = true;
              appController.tabVisible = true;
              appController.tab = 'line';
              appController.menuCollapse = false;
              
              Get.back();
              Get.snackbar('提示', '设置已重置');
            },
            child: const Text('确认'),
          ),
        ],
      ),
    );
  }
}
