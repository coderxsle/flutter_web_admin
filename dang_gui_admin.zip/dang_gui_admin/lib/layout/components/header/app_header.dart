/// @file Header 组件
/// @description 头部组件，包含折叠按钮、面包屑导航和右侧工具栏
import 'package:flutter/material.dart';
import '../breadcrumb/app_breadcrumb.dart';
import '../header_right_bar/header_right_bar.dart';
import '../menu_fold_btn.dart';

/// 头部组件
class AppHeader extends StatelessWidget {
  const AppHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: theme.appBarTheme.backgroundColor ?? theme.cardColor,
        border: Border(
          bottom: BorderSide(
            color: theme.dividerColor,
            width: 1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        children: [
          // 折叠按钮区域
          const MenuFoldBtn(),
          
          // 中间内容区域
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(left: 16),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  // 响应式布局
                  if (constraints.maxWidth > 768) {
                    // 桌面端布局
                    return const Row(
                      children: [
                        // 面包屑导航（左侧）
                        Expanded(
                          flex: 5,
                          child: AppBreadcrumb(),
                        ),
                        
                        // 右侧工具栏
                        Expanded(
                          flex: 7,
                          child: HeaderRightBar(),
                        ),
                      ],
                    );
                  } else {
                    // 移动端布局（只显示右侧工具栏）
                    return const Row(
                      children: [
                        Expanded(child: SizedBox.shrink()),
                        HeaderRightBar(),
                      ],
                    );
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Header组件的便捷构造函数
class Header extends StatelessWidget {
  const Header({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppHeader();
  }
}
