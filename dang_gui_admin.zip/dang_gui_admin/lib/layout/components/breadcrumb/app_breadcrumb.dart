/// @file Breadcrumb 组件
/// @description 面包屑导航组件，支持路由导航、动画效果和自定义样式
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/route_controller.dart';
import '../../controllers/tabs_controller.dart';
import '../../models/route_record.dart';

/// 面包屑导航组件
class AppBreadcrumb extends StatefulWidget {
  const AppBreadcrumb({super.key});

  @override
  State<AppBreadcrumb> createState() => _AppBreadcrumbState();
}

class _AppBreadcrumbState extends State<AppBreadcrumb>
    with TickerProviderStateMixin {
  /// 面包屑列表
  List<RouteRecord> _breadcrumbList = [];
  
  /// 动画控制器
  late AnimationController _animationController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;

  /// 首页路由缓存
  RouteRecord? _homeRoute;

  @override
  void initState() {
    super.initState();
    
    // 初始化动画
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0.2, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));

    // 获取初始面包屑
    _getBreadcrumbList();
    
    // 监听路由变化
    // 注意：在实际应用中，应该使用GetX的路由监听机制
    _getBreadcrumbList();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  /// 获取首页路由信息
  void _getHomeRoute() {
    if (_homeRoute != null) return;
    
    final routeController = Get.find<RouteController>();
    _homeRoute = routeController.findRouteByPath('/home');
  }

  /// 获取面包屑列表
  void _getBreadcrumbList() {
    _getHomeRoute();
    
    final currentRoute = Get.currentRoute;
    final routeController = Get.find<RouteController>();
    
    // 获取当前路由的层级结构
    final hierarchy = routeController.getRouteHierarchy(currentRoute);
    
    // 过滤面包屑项
    final filteredHierarchy = hierarchy.where((route) => 
        route.meta?.title != null && 
        route.meta?.breadcrumb != false).toList();
    
    // 添加首页到面包屑开头
    final newBreadcrumbList = <RouteRecord>[];
    if (_homeRoute != null) {
      newBreadcrumbList.add(_homeRoute!);
    }
    newBreadcrumbList.addAll(filteredHierarchy);
    
    setState(() {
      _breadcrumbList = newBreadcrumbList;
    });
    
    // 播放动画
    _animationController.forward(from: 0);
  }

  /// 判断是否为最后一项
  bool _isLastItem(int index) => index == _breadcrumbList.length - 1;

  /// 判断是否有重定向
  bool _hasRedirect(RouteRecord item) =>
      item.redirect != null && 
      item.redirect != 'noRedirect' && 
      item.redirect!.isNotEmpty;

  /// 处理路由跳转
  void _handleLink(RouteRecord item) {
    final redirect = item.redirect;
    if (redirect != null && redirect.isNotEmpty) {
      Get.toNamed(redirect);
      return;
    }
    Get.toNamed(item.path);
  }

  /// 获取最后的标题
  String _getLastTitle() {
    try {
      final tabsController = Get.find<TabsController>();
      final currentRoute = Get.currentRoute;
      final currentTab = tabsController.tabList.firstWhereOrNull(
        (tab) => tab.path == currentRoute,
      );
      return currentTab?.meta?.title ?? '';
    } catch (e) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    if (_breadcrumbList.isEmpty) {
      return const SizedBox.shrink();
    }

    return SlideTransition(
      position: _slideAnimation,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Row(
          children: _breadcrumbList.asMap().entries.map((entry) {
            final index = entry.key;
            final item = entry.value;
            final isLast = _isLastItem(index);
            final hasRedirect = _hasRedirect(item);
            final lastTitle = _getLastTitle();
            
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 面包屑项
                Flexible(
                  child: GestureDetector(
                    onTap: (isLast && !hasRedirect) 
                        ? null 
                        : () => _handleLink(item),
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 150),
                      child: Text(
                        isLast && lastTitle.isNotEmpty 
                            ? lastTitle 
                            : (item.meta?.title ?? ''),
                        style: TextStyle(
                          fontSize: 14,
                          color: (isLast && !hasRedirect)
                              ? theme.textTheme.bodyMedium?.color
                              : theme.primaryColor,
                          fontWeight: (isLast && !hasRedirect)
                              ? FontWeight.normal
                              : FontWeight.w500,
                          decoration: (isLast && !hasRedirect)
                              ? TextDecoration.none
                              : TextDecoration.none,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ),
                  ),
                ),
                
                // 分隔符
                if (!isLast) ...[
                  const SizedBox(width: 8),
                  Icon(
                    Icons.chevron_right,
                    size: 14,
                    color: theme.iconTheme.color?.withOpacity(0.5),
                  ),
                  const SizedBox(width: 8),
                ],
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}

/// Breadcrumb组件的便捷构造函数
class Breadcrumb extends StatelessWidget {
  const Breadcrumb({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppBreadcrumb();
  }
}
