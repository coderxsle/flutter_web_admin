/// @file Asider 组件
/// @description 侧边栏组件，支持可折叠、滚动视图和暗黑主题适配
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../logger.dart';
import '../../layout_index.dart';
import '../app_logo.dart';
import '../menu/app_menu.dart';
import '../menu_fold_btn.dart';

/// 侧边栏组件
class AppAsider extends StatelessWidget {
  const AppAsider({super.key});

  /// 处理折叠状态变化
  void _handleCollapse(bool isCollapsed) {
    final appController = Get.find<AppLayoutController>();
    appController.menuCollapse = isCollapsed;
  }

  @override
  Widget build(BuildContext context) {
    final appController = Get.find<AppLayoutController>();
    final deviceController = Get.find<DeviceController>();
    final theme = Theme.of(context);
    
    return Obx(() {
      // 仅在桌面端显示侧边栏
      if (!deviceController.isDesktop) {
        return const SizedBox.shrink();
      }

      final isCollapsed = appController.menuCollapse;
      final isDark = appController.menuDark;
      
      return AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: isCollapsed ? 64 : 220,
        decoration: BoxDecoration(
          color: isDark 
              ? Colors.grey[900] 
              : theme.cardColor,
          border: Border(
            right: BorderSide(
              color: theme.dividerColor,
              width: 1,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8,
              offset: const Offset(2, 0),
            ),
          ],
        ),
        child: Column(
          children: [
            // Logo区域
            Logo(collapsed: isCollapsed),
            
            // 菜单滚动区域
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Scrollbar(
                  child: SingleChildScrollView(
                    child: AppMenu(
                      props: AppMenuProps(
                        collapsed: isCollapsed,
                        decoration: BoxDecoration(
                          color: isDark 
                              ? Colors.grey[900] 
                              : Colors.transparent,
                        ),
                      ),
                      onRouteChanged: (path) {
                        // 路由状态已在菜单组件中更新，这里不需要重复更新
                        logger.d('Route changed in asider: $path');
                      },
                    ),
                  ),
                ),
              ),
            ),
            
            // 折叠按钮区域（可选）
            if (!isCollapsed) ...[
              const Divider(height: 1),
              Container(
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Text(
                      'Admin Pro',
                      style: TextStyle(
                        fontSize: 12,
                        color: theme.textTheme.bodySmall?.color,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      iconSize: 16,
                      padding: const EdgeInsets.all(4),
                      constraints: const BoxConstraints(
                        minWidth: 24,
                        minHeight: 24,
                      ),
                      onPressed: () => _handleCollapse(true),
                      icon: Icon(
                        Icons.keyboard_arrow_left,
                        color: theme.iconTheme.color?.withOpacity(0.6),
                      ),
                      tooltip: '折叠侧边栏',
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      );
    });
  }
}

/// Asider组件的便捷构造函数
class Asider extends StatelessWidget {
  const Asider({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppAsider();
  }
}
