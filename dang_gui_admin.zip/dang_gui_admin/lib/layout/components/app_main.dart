/// @file Main 组件
/// @description 主内容区组件，支持路由切换动画、页面缓存和组件重载功能
import 'package:dang_gui_admin/layout/controllers/route_controller.dart';
import 'package:dang_gui_admin/layout/controllers/tabs_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../layout_index.dart';


/// Main组件的便捷构造函数
class Main extends StatelessWidget {
  const Main({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppMain();
  }
}

/// 主内容区组件
class AppMain extends StatefulWidget {
  const AppMain({super.key});

  @override
  State<AppMain> createState() => _AppMainState();
}

class _AppMainState extends State<AppMain> {
  late RouteController _routeController;
  
  /// 路由组件缓存，避免重复创建
  final Map<String, Widget> _routeWidgetCache = {};
  
  /// 上一个路由路径，用于检测路由变化
  String _previousRoute = '';

  @override
  void initState() {
    super.initState();
    _routeController = Get.find<RouteController>();
    _previousRoute = _routeController.internalPath;
  }

  /// 获取过渡动画
  Widget _buildTransition(Widget child, Animation<double> animation) {
    final appController = Get.find<AppLayoutController>();
    
    switch (appController.transitionName) {
      case 'slide-right':
        return SlideTransition(
          position: animation.drive(
            Tween(begin: const Offset(1.0, 0.0), end: Offset.zero),
          ),
          child: child,
        );
      case 'slide-left':
        return SlideTransition(
          position: animation.drive(
            Tween(begin: const Offset(-1.0, 0.0), end: Offset.zero),
          ),
          child: child,
        );
      case 'fade':
        return FadeTransition(opacity: animation, child: child);
      default:
        return FadeTransition(opacity: animation, child: child);
    }
  }

  @override
  Widget build(BuildContext context) {
    final tabsController = Get.find<TabsController>();
    
    return Expanded(
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
        ),
        child: Obx(() {
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            transitionBuilder: (child, animation) => 
                _buildTransition(child, animation),
            child: tabsController.reloadFlag
                ? _buildRouterView()
                : const SizedBox.shrink(),
          );
        }),
      ),
    );
  }

  /// 构建路由视图
  Widget _buildRouterView() {
    return Obx(() {
      // 直接使用内部路径，避免在 Obx 中调用可能引起状态变化的 getter
      final currentRoute = _routeController.internalPath;
      
      // 检测路由变化，清理缓存（可选）
      if (_previousRoute != currentRoute) {
        debugPrint('AppMain: Route changed from $_previousRoute to $currentRoute');
        _previousRoute = currentRoute;
        // 可以根据需要清理缓存，这里我们保留缓存以提高性能
        // 如果需要清理缓存，可以取消注释下面的行：
        // _clearRouteCache();
      }
      
      return Container(
        key: ValueKey(currentRoute),
        decoration: const BoxDecoration(
          color: Colors.white,
        ),
        child: Navigator(
          key: ValueKey('nested_navigator_$currentRoute'),
          initialRoute: '/',
          onGenerateRoute: (settings) {
            // 简化路由处理：只处理当前目标路由
            final routeName = settings.name ?? currentRoute;
            
            // 处理根路由重定向
            if (routeName == '/' && currentRoute != '/') {
              debugPrint('AppMain onGenerateRoute: Redirecting root route to $currentRoute');
              return _getRouteWidget(currentRoute);
            }
            
            // 如果是当前路由，显示目标页面
            if (routeName == currentRoute) {
              debugPrint('AppMain onGenerateRoute: Processing route: $routeName');
              return _getRouteWidget(currentRoute);
            } else {
              // 其他情况直接返回当前路由的页面
              debugPrint('AppMain onGenerateRoute: Redirecting $routeName to $currentRoute');
              return _getRouteWidget(currentRoute);
            }
          },
        ),
      );
    });
  }

  /// 获取路由对应的 Widget
  PageRoute _getRouteWidget(String routeName) {
    debugPrint('AppMain _getRouteWidget: routeName=$routeName');
    
    // 检查缓存
    if (_routeWidgetCache.containsKey(routeName)) {
      debugPrint('AppMain _getRouteWidget: Using cached widget for $routeName');
      return MaterialPageRoute(
        builder: (context) => _routeWidgetCache[routeName]!,
        settings: RouteSettings(name: routeName),
      );
    }
    
    // 使用 RouteController 查找路由配置
    final routeController = Get.find<RouteController>();
    final routeRecord = routeController.findRouteByPath(routeName);
    debugPrint('AppMain _getRouteWidget: routeRecord=${routeRecord?.path}, component=${routeRecord?.component != null}');
    
    Widget pageWidget;
    if (routeRecord?.component != null) {
      // 使用 RouteRecord 中定义的组件
      pageWidget = routeRecord!.component!;
    } else if (routeRecord?.redirect != null) {
      // 处理重定向路由
      debugPrint('AppMain _getRouteWidget: Redirecting from $routeName to ${routeRecord!.redirect}');
      final redirectRoute = routeController.findRouteByPath(routeRecord.redirect!);
      if (redirectRoute?.component != null) {
        pageWidget = redirectRoute!.component!;
      } else {
        pageWidget = _buildDefaultContent();
      }
    } else {
      // 回退到硬编码映射
      pageWidget = _buildDefaultContent();
    }
    
    // 缓存组件（只缓存有实际组件的路由）
    if (routeRecord?.component != null) {
      _routeWidgetCache[routeName] = pageWidget;
    }
    
    return MaterialPageRoute(
      builder: (context) => pageWidget, 
      settings: RouteSettings(name: routeName, arguments: routeRecord),
    );
  }


  /// 默认页面内容
  Widget _buildDefaultContent() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.info, size: 64, color: Colors.grey),
          const SizedBox(height: 16),
          Text('页面内容区域', style: Theme.of(Get.context!).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text('当前路由: ${_routeController.internalPath}', style: Theme.of(Get.context!).textTheme.bodyMedium),
        ],
      ),
    );
  }
}
