/// @file Logo 组件
/// @description 系统 Logo 组件，支持折叠状态和首页导航功能
import 'package:flutter/material.dart';
import 'package:get/get.dart';

/// Logo组件属性
class AppLogoProps {
  /// 是否折叠状态
  final bool collapsed;

  const AppLogoProps({
    this.collapsed = false,
  });
}

/// 系统Logo组件
class AppLogo extends StatelessWidget {
  /// 组件属性
  final AppLogoProps props;

  const AppLogo({
    super.key,
    this.props = const AppLogoProps(),
  });

  /// 处理首页导航
  void _handleHomeNavigation() {
    Get.offAllNamed('/');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return GestureDetector(
      onTap: _handleHomeNavigation,
      child: Container(
        height: 56,
        padding: EdgeInsets.symmetric(
          horizontal: props.collapsed ? 0 : 12,
        ),
        child: Row(
          mainAxisAlignment: props.collapsed 
              ? MainAxisAlignment.center 
              : MainAxisAlignment.start,
          children: [
            // Logo 图片
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: theme.primaryColor,
              ),
              child: const Icon(
                Icons.admin_panel_settings,
                color: Colors.white,
                size: 24,
              ),
            ),
            
            // 系统名称
            if (!props.collapsed) ...[
              const SizedBox(width: 10),
              Expanded(
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 200),
                  opacity: props.collapsed ? 0 : 1,
                  child: Text(
                    'Admin Pro',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: theme.textTheme.titleLarge?.color,
                      overflow: TextOverflow.ellipsis,
                    ),
                    maxLines: 1,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// Logo组件的便捷构造函数
class Logo extends StatelessWidget {
  final bool collapsed;

  const Logo({
    super.key,
    this.collapsed = false,
  });

  @override
  Widget build(BuildContext context) {
    return AppLogo(
      props: AppLogoProps(collapsed: collapsed),
    );
  }
}
