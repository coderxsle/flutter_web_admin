/// @file Tabs 组件
/// @description 系统标签页组件，支持多种标签样式、右键菜单和快捷操作
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/tabs_controller.dart';
import '../../layout_index.dart';
import 'magic_icon.dart';
import 'reload_icon.dart';

/// 标签页组件
class AppTabs extends StatefulWidget {
  const AppTabs({super.key});

  @override
  State<AppTabs> createState() => _AppTabsState();
}

class _AppTabsState extends State<AppTabs> with TickerProviderStateMixin {
  /// 标签页控制器
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    final tabsController = Get.find<TabsController>();
    _tabController = TabController(
      length: tabsController.tabList.length,
      vsync: this,
    );
    
    // 监听标签页变化
    ever(tabsController.tabListObs, (_) => _updateTabController());
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  /// 更新标签页控制器
  void _updateTabController() {
    final tabsController = Get.find<TabsController>();
    final newLength = tabsController.tabList.length;
    
    if (newLength != _tabController.length) {
      _tabController.dispose();
      _tabController = TabController(
        length: newLength,
        vsync: this,
        initialIndex: tabsController.getCurrentTabIndex().clamp(0, newLength - 1),
      );
    }
  }

  /// 处理标签页点击
  void _handleTabClick(int index) {
    final tabsController = Get.find<TabsController>();
    if (index < tabsController.tabList.length) {
      final targetTab = tabsController.tabList[index];
      Get.toNamed(targetTab.fullPath ?? targetTab.path);
    }
  }

  /// 处理标签页关闭
  void _handleTabClose(int index) {
    final tabsController = Get.find<TabsController>();
    if (index < tabsController.tabList.length) {
      final targetTab = tabsController.tabList[index];
      tabsController.closeCurrent(targetTab.path);
    }
  }

  /// 构建右键菜单
  Widget _buildContextMenu(TabItem tab) {
    final tabsController = Get.find<TabsController>();
    
    return PopupMenuButton<String>(
      onSelected: (value) {
        switch (value) {
          case 'close':
            tabsController.closeCurrent(tab.path);
            break;
          case 'closeRight':
            tabsController.closeRight(tab.path);
            break;
          case 'closeOther':
            tabsController.closeOther(tab.path);
            break;
        }
      },
      itemBuilder: (context) => [
        const PopupMenuItem(
          value: 'close',
          child: Row(
            children: [
              Icon(Icons.close, size: 16),
              SizedBox(width: 8),
              Text('关闭当前'),
            ],
          ),
        ),
        const PopupMenuItem(
          value: 'closeRight',
          child: Row(
            children: [
              Icon(Icons.close, size: 16),
              SizedBox(width: 8),
              Text('关闭右侧'),
            ],
          ),
        ),
        const PopupMenuItem(
          value: 'closeOther',
          child: Row(
            children: [
              Icon(Icons.clear_all, size: 16),
              SizedBox(width: 8),
              Text('关闭其他'),
            ],
          ),
        ),
      ],
      child: _buildTabItem(tab),
    );
  }

  /// 构建标签页项
  Widget _buildTabItem(TabItem tab) {
    final appController = Get.find<AppLayoutController>();
    final theme = Theme.of(context);
    final isActive = Get.currentRoute == tab.path;
    
    return Obx(() {
      // 根据标签页样式渲染不同的UI
      switch (appController.tab) {
        case 'custom2':
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 4),
            child: Chip(
              label: Text(
                tab.meta?.title ?? '',
                style: TextStyle(
                  fontSize: 12,
                  color: isActive ? Colors.white : theme.textTheme.bodyMedium?.color,
                ),
              ),
              backgroundColor: isActive 
                  ? theme.primaryColor 
                  : theme.chipTheme.backgroundColor,
              deleteIcon: tab.meta?.affix != true 
                  ? Icon(
                      Icons.close,
                      size: 14,
                      color: isActive ? Colors.white : theme.iconTheme.color,
                    )
                  : null,
              onDeleted: tab.meta?.affix != true 
                  ? () => _handleTabClose(Get.find<TabsController>().tabList.indexOf(tab))
                  : null,
            ),
          );
        
        default:
          return Tab(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    tab.meta?.title ?? '',
                    style: TextStyle(
                      fontSize: 14,
                      color: isActive 
                          ? theme.primaryColor 
                          : theme.textTheme.bodyMedium?.color,
                    ),
                  ),
                  if (tab.meta?.affix != true) ...[
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: () => _handleTabClose(Get.find<TabsController>().tabList.indexOf(tab)),
                      child: Icon(
                        Icons.close,
                        size: 14,
                        color: theme.iconTheme.color?.withOpacity(0.6),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
      }
    });
  }

  /// 构建操作按钮区域
  Widget _buildActions() {
    final tabsController = Get.find<TabsController>();
    
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // 重载按钮
        const ReloadIcon(),
        
        const SizedBox(width: 8),
        
        // 更多操作下拉菜单
        PopupMenuButton<String>(
          icon: const MagicIcon(),
          onSelected: (value) {
            final currentRoute = Get.currentRoute;
            switch (value) {
              case 'close':
                tabsController.closeCurrent(currentRoute);
                break;
              case 'closeRight':
                tabsController.closeRight(currentRoute);
                break;
              case 'closeOther':
                tabsController.closeOther(currentRoute);
                break;
              case 'closeAll':
                tabsController.closeAll();
                break;
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'close',
              child: Row(
                children: [
                  Icon(Icons.close, size: 16),
                  SizedBox(width: 8),
                  Text('关闭当前'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'closeRight',
              child: Row(
                children: [
                  Icon(Icons.close, size: 16),
                  SizedBox(width: 8),
                  Text('关闭右侧'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'closeOther',
              child: Row(
                children: [
                  Icon(Icons.clear_all, size: 16),
                  SizedBox(width: 8),
                  Text('关闭其他'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'closeAll',
              child: Row(
                children: [
                  Icon(Icons.remove, size: 16),
                  SizedBox(width: 8),
                  Text('关闭全部'),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final tabsController = Get.find<TabsController>();
    final appController = Get.find<AppLayoutController>();
    final theme = Theme.of(context);
    
    return Obx(() {
      if (tabsController.tabList.isEmpty) {
        return const SizedBox.shrink();
      }

      return Container(
        decoration: BoxDecoration(
          color: theme.cardColor,
          border: Border(
            bottom: BorderSide(
              color: theme.dividerColor,
              width: 1,
            ),
          ),
        ),
        child: Column(
          children: [
            // 标签页头部
            Container(
              height: 40,
              child: Row(
                children: [
                  // 标签页列表
                  Expanded(
                    child: appController.tab == 'custom2'
                        ? SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              children: tabsController.tabList.map((tab) => 
                                  GestureDetector(
                                    onTap: () => _handleTabClick(tabsController.tabList.indexOf(tab)),
                                    onSecondaryTapUp: (_) => _buildContextMenu(tab),
                                    child: _buildTabItem(tab),
                                  )).toList(),
                            ),
                          )
                        : TabBar(
                            controller: _tabController,
                            isScrollable: true,
                            tabAlignment: TabAlignment.start,
                            labelPadding: EdgeInsets.zero,
                            indicatorSize: TabBarIndicatorSize.tab,
                            onTap: _handleTabClick,
                            tabs: tabsController.tabList.map((tab) => 
                                GestureDetector(
                                  onSecondaryTapUp: (_) => _buildContextMenu(tab),
                                  child: _buildTabItem(tab),
                                )).toList(),
                          ),
                  ),
                  
                  // 操作按钮区域
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildActions(),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    });
  }
}

/// Tabs组件的便捷构造函数
class Tabs extends StatelessWidget {
  const Tabs({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppTabs();
  }
}
