/// @file MagicIcon 组件
/// @description 标签页魔法图标组件，用于快捷操作
import 'package:flutter/material.dart';

/// 魔法图标组件
class MagicIcon extends StatefulWidget {
  const MagicIcon({super.key});

  @override
  State<MagicIcon> createState() => _MagicIconState();
}

class _MagicIconState extends State<MagicIcon>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _rotationAnimation;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    
    _rotationAnimation = Tween<double>(
      begin: 0,
      end: 0.5, // 180度旋转
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _handleHover(bool isHovered) {
    setState(() {
      _isHovered = isHovered;
    });
    
    if (isHovered) {
      _animationController.forward();
    } else {
      _animationController.reverse();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return MouseRegion(
      onEnter: (_) => _handleHover(true),
      onExit: (_) => _handleHover(false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: _isHovered 
              ? theme.colorScheme.secondary.withOpacity(0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(4),
        ),
        child: AnimatedBuilder(
          animation: _rotationAnimation,
          builder: (context, child) {
            return Transform.rotate(
              angle: _rotationAnimation.value * 3.14159, // 转换为弧度
              child: Icon(
                Icons.more_horiz,
                size: 16,
                color: _isHovered 
                    ? theme.primaryColor
                    : theme.iconTheme.color?.withOpacity(0.7),
              ),
            );
          },
        ),
      ),
    );
  }
}
