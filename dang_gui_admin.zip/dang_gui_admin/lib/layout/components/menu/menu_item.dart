/// @file MenuItem 组件
/// @description 菜单项组件，支持递归菜单结构和单/多层级菜单渲染
import 'package:flutter/material.dart';
import '../../models/route_record.dart';
import 'menu_icon.dart';

/// 菜单项组件属性
class MenuItemProps {
  /// 路由记录
  final RouteRecord item;
  /// 当前层级
  final int level;
  /// 是否折叠状态
  final bool collapsed;
  /// 当前激活的菜单路径
  final List<String> activeKeys;
  /// 菜单项点击回调
  final void Function(String)? onItemClick;

  const MenuItemProps({
    required this.item,
    this.level = 0,
    this.collapsed = false,
    this.activeKeys = const [],
    this.onItemClick,
  });
}

/// 菜单项组件
class MenuItem extends StatefulWidget {
  final MenuItemProps props;

  const MenuItem({
    super.key,
    required this.props,
  });

  /// 便捷构造函数
  MenuItem.item({
    super.key,
    required RouteRecord item,
    int level = 0,
    bool collapsed = false,
    List<String> activeKeys = const [],
    void Function(String)? onItemClick,
  }) : props = MenuItemProps(
         item: item,
         level: level,
         collapsed: collapsed,
         activeKeys: activeKeys,
         onItemClick: onItemClick,
       );

  @override
  State<MenuItem> createState() => _MenuItemState();
}

class _MenuItemState extends State<MenuItem> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _expandAnimation;
  bool _isExpanded = false;
  
  /// 缓存激活状态，避免重复计算
  bool? _cachedIsActive;
  List<String>? _lastActiveKeys;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );
    _expandAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );

    // 检查是否应该展开
    _checkShouldExpand();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(MenuItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    _checkShouldExpand();
  }

  /// 检查是否应该展开
  void _checkShouldExpand() {
    final shouldExpand = widget.props.activeKeys.any((key) => 
        key.startsWith(widget.props.item.path) && 
        key != widget.props.item.path);
    
    if (shouldExpand != _isExpanded) {
      setState(() {
        _isExpanded = shouldExpand;
        // 清理缓存，因为展开状态会影响激活状态计算
        _clearActiveCache();
      });
      
      if (_isExpanded) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
      
      // 展开状态改变后，需要重新计算选中状态
      setState(() {});
    }
  }

  /// 处理菜单项点击
  void _handleItemClick() {
    final item = widget.props.item;
    
    // 如果有子菜单，只切换展开状态，不更新路由
    if (item.hasChildren) {
      setState(() {
        _isExpanded = !_isExpanded;
        // 清理缓存，因为展开状态会影响激活状态计算
        _clearActiveCache();
      });
      
      if (_isExpanded) {
        _animationController.forward();
      } else {
        _animationController.reverse();
      }
      
      // 展开/收起后需要重新计算选中状态，触发UI更新
      setState(() {});
      
      // 有子菜单的父级菜单项不调用路由回调，只展开/收起
      return;
    }
    
    // 只有没有子菜单的菜单项才调用路由回调
    widget.props.onItemClick?.call(item.path);
  }
  
  /// 清理激活状态缓存
  void _clearActiveCache() {
    _cachedIsActive = null;
    _lastActiveKeys = null;
  }

  /// 判断是否为激活状态（带缓存优化）
  bool get _isActive {
    final item = widget.props.item;
    
    // 检查缓存是否有效
    if (_cachedIsActive != null && 
        _lastActiveKeys != null && 
        _listEquals(_lastActiveKeys!, widget.props.activeKeys)) {
      return _cachedIsActive!;
    }
    
    // 计算激活状态
    bool result;
    if (!item.hasChildren) {
      // 叶子节点：直接判断路径匹配
      result = widget.props.activeKeys.contains(item.path);
    } else {
      // 父级菜单：检查是否有子项被选中
      final hasActiveChild = item.showingChildren.any((child) => 
          widget.props.activeKeys.contains(child.path));
      result = !_isExpanded && hasActiveChild;
    }
    
    // 更新缓存
    _cachedIsActive = result;
    _lastActiveKeys = List.from(widget.props.activeKeys);
    
    return result;
  }
  
  /// 比较两个列表是否相等
  bool _listEquals<T>(List<T> list1, List<T> list2) {
    if (list1.length != list2.length) return false;
    for (int i = 0; i < list1.length; i++) {
      if (list1[i] != list2[i]) return false;
    }
    return true;
  }

  /// 构建菜单项内容
  Widget _buildMenuItemContent() {
    final item = widget.props.item;
    final theme = Theme.of(context);
    final isActive = _isActive;
    
    return Container(
      margin: EdgeInsets.only(left: widget.props.level * 16.0),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _handleItemClick,
          borderRadius: BorderRadius.circular(6),
          child: Container(
            height: 40,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: isActive 
                  ? theme.primaryColor.withValues(alpha: 0.1)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Row(
              children: [
                // 菜单图标
                if (!widget.props.collapsed || widget.props.level == 0)
                  MenuIcon(
                    props: MenuIconProps(
                      svgIcon: item.meta?.svgIcon,
                      icon: item.meta?.icon,
                      size: 32,
                      color: isActive 
                          ? theme.primaryColor 
                          : theme.iconTheme.color,
                    ),
                  ),
                
                // 菜单标题
                if (!widget.props.collapsed || widget.props.level > 0) ...[
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      item.meta?.title ?? '',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                        color: isActive 
                            ? theme.primaryColor 
                            : theme.textTheme.bodyMedium?.color,
                        overflow: TextOverflow.ellipsis,
                      ),
                      maxLines: 1,
                    ),
                  ),
                ],
                
                // 展开箭头
                if (item.hasChildren && !widget.props.collapsed) ...[
                  const SizedBox(width: 8),
                  AnimatedRotation(
                    turns: _isExpanded ? 0.25 : 0,
                    duration: const Duration(milliseconds: 200),
                    child: Icon(
                      Icons.chevron_right,
                      size: 16,
                      color: theme.iconTheme.color?.withOpacity(0.6),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// 构建子菜单
  Widget _buildSubMenu() {
    final item = widget.props.item;
    
    if (!item.hasChildren) return const SizedBox.shrink();
    
    return SizeTransition(
      sizeFactor: _expandAnimation,
      child: Column(
        children: item.showingChildren.map((child) => MenuItem(
          props: MenuItemProps(
            item: child,
            level: widget.props.level + 1,
            collapsed: widget.props.collapsed,
            activeKeys: widget.props.activeKeys,
            onItemClick: widget.props.onItemClick,
          ),
        )).toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.props.item;
    
    // 如果菜单项被隐藏，不渲染
    if (item.meta?.hidden == true) {
      return const SizedBox.shrink();
    }

    // 如果只有一个显示的子项且不强制显示父级
    if (item.hasOnlyOneShowingChild && 
        item.onlyOneChild?.meta?.noShowingChildren != true &&
        item.meta?.redirect != 'noRedirect') {
      final onlyChild = item.onlyOneChild!;
      return MenuItem(
        props: MenuItemProps(
          item: onlyChild.copyWith(
            meta: onlyChild.meta?.copyWith(
              svgIcon: onlyChild.meta?.svgIcon ?? item.meta?.svgIcon,
              icon: onlyChild.meta?.icon ?? item.meta?.icon,
            ),
          ),
          level: widget.props.level,
          collapsed: widget.props.collapsed,
          activeKeys: widget.props.activeKeys,
          onItemClick: widget.props.onItemClick,
        ),
      );
    }

    return Column(
      children: [
        _buildMenuItemContent(),
        if (!widget.props.collapsed) _buildSubMenu(),
      ],
    );
  }
}
