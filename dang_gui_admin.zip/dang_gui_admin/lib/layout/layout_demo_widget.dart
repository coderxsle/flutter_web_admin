/// @file LayoutDemoWidget 布局演示组件
/// @description 可以嵌入到现有页面中的布局演示组件
import 'package:dang_gui_admin/utils/message_utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'layout.dart';

/// 布局演示组件
class LayoutDemoWidget extends StatefulWidget {

  final double? height; /// 容器高度
  final bool showFullLayout; /// 是否显示完整布局（false时只显示控制面板）
  
  const LayoutDemoWidget({super.key, this.height, this.showFullLayout = true});

  @override
  State<LayoutDemoWidget> createState() => _LayoutDemoWidgetState();
}

class _LayoutDemoWidgetState extends State<LayoutDemoWidget> {
  /// 是否已初始化
  bool _isInitialized = false;
  
  /// 缓存的主题数据
  ThemeData? _cachedTheme;

  @override
  void initState() {
    super.initState();
    _initializeLayout();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 缓存主题数据以避免在 Obx 中访问已销毁的 context
    _cachedTheme = Theme.of(context);
  }

    @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }
    if (!widget.showFullLayout) {
      return _buildControlPanel();
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLayoutPreview(),
      ],
    );
  }

  /// 构建布局预览
  Widget _buildLayoutPreview() {
    final theme = _cachedTheme ?? Theme.of(context);
    return Column(
      children: [
        Container(
          height: widget.height ?? MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            border: Border.all(
              color: theme.focusColor,
              width: 1,
            ),
            borderRadius: BorderRadius.circular(8),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: const LayoutIndex(),
          ),
        ),
      ],
    );
  }
  
  /// 初始化布局系统
  void _initializeLayout() {
    try {
      // 检查是否已经注册了控制器
      Get.find<AppLayoutController>();
    } catch (e) {
      // 如果没有注册，则初始化
      LayoutInitializer.initialize();
    }
    
    setState(() {
      _isInitialized = true;
    });
  }

  /// 构建布局控制面板
  Widget _buildControlPanel() {
    final appController = Get.find<AppLayoutController>();
    final theme = _cachedTheme ?? Theme.of(context);
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: theme.dividerColor,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '布局系统演示',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          
          const SizedBox(height: 16),
          
          // 布局模式选择
          Text(
            '布局模式',
            style: theme.textTheme.titleMedium,
          ),
          
          const SizedBox(height: 8),
          
          Obx(() => Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _buildLayoutButton(
                '默认布局',
                LayoutType.defaultLayout,
                appController.layout == LayoutType.defaultLayout,
                () => appController.layout = LayoutType.defaultLayout,
              ),
              _buildLayoutButton(
                '混合布局',
                LayoutType.mix,
                appController.layout == LayoutType.mix,
                () => appController.layout = LayoutType.mix,
              ),
              _buildLayoutButton(
                '顶部布局',
                LayoutType.top,
                appController.layout == LayoutType.top,
                () => appController.layout = LayoutType.top,
              ),
            ],
          )),
          
          const SizedBox(height: 16),
          
          // 主题设置
          Text(
            '主题设置',
            style: theme.textTheme.titleMedium,
          ),
          
          const SizedBox(height: 8),
          
          Obx(() => Column(
            children: [
              SwitchListTile(
                title: const Text('暗黑菜单'),
                subtitle: const Text('菜单栏使用暗黑主题'),
                value: appController.menuDark,
                onChanged: (value) => appController.menuDark = value,
                contentPadding: EdgeInsets.zero,
              ),
              
              SwitchListTile(
                title: const Text('显示标签页'),
                subtitle: const Text('是否显示页面标签页'),
                value: appController.tabVisible,
                onChanged: (value) => appController.tabVisible = value,
                contentPadding: EdgeInsets.zero,
              ),
              
              SwitchListTile(
                title: const Text('手风琴菜单'),
                subtitle: const Text('只展开一个菜单项'),
                value: appController.menuAccordion,
                onChanged: (value) => appController.menuAccordion = value,
                contentPadding: EdgeInsets.zero,
              ),
            ],
          )),
          
          const SizedBox(height: 16),
          
          // 操作按钮
          Row(
            children: [
              ElevatedButton(
                onPressed: () {
                  Get.toNamed('/layout-demo');
                },
                child: const Text('查看完整演示'),
              ),
              
              const SizedBox(width: 12),
              
              OutlinedButton(
                onPressed: _resetSettings,
                child: const Text('重置设置'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// 构建布局按钮
  Widget _buildLayoutButton(
    String label,
    LayoutType layoutType,
    bool isSelected,
    VoidCallback onPressed,
  ) {
    final theme = _cachedTheme ?? Theme.of(context);
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected 
            ? theme.primaryColor 
            : theme.colorScheme.surface,
        foregroundColor: isSelected 
            ? Colors.white 
            : theme.textTheme.bodyMedium?.color,
        elevation: isSelected ? 2 : 0,
        side: BorderSide(
          color: isSelected 
              ? theme.primaryColor 
              : theme.dividerColor,
        ),
      ),
      child: Text(label),
    );
  }

  /// 重置设置
  void _resetSettings() {
    final appController = Get.find<AppLayoutController>();
    
    // appController.layout = LayoutType.mix;
    appController.layout = LayoutType.defaultLayout;
    appController.menuDark = false;
    appController.menuAccordion = true;
    appController.tabVisible = true;
    appController.tab = 'line';
    appController.menuCollapse = false;
    
    showSuccess('设置已重置到默认值');
  }




}

