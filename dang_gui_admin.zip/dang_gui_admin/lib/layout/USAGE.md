# 📖 路由系统使用指南

## 概述

本文档详细介绍如何使用本项目的路由管理系统，包括如何添加新路由、配置菜单、设置权限等。我们将以二级菜单为例，展示完整的使用流程。

## 🎯 使用场景示例

假设我们要添加一个"系统管理"模块，包含"用户管理"和"角色管理"两个子页面。

## 📁 文件结构

```
lib/
├── routes/
│   ├── app_pages.dart          # GetX 路由配置
│   └── app_routes.dart         # 路由常量定义
├── layout/
│   ├── controllers/
│   │   └── route_controller.dart  # 路由状态管理
│   └── models/
│       └── route_record.dart      # 路由数据模型
├── modules/
│   ├── system/
│   │   ├── user/
│   │   │   ├── bindings/
│   │   │   │   └── user_binding.dart
│   │   │   └── views/
│   │   │       └── user_view.dart
│   │   └── role/
│   │       ├── bindings/
│   │       │   └── role_binding.dart
│   │       └── views/
│   │           └── role_view.dart
```

## 🔧 详细实现步骤

### 1. 创建页面和绑定

#### 1.1 用户管理页面

```dart
// lib/modules/system/user/views/user_view.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/user_controller.dart';

class UserView extends StatelessWidget {
  const UserView({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<UserController>(
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('用户管理'),
            backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          ),
          body: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.people,
                  size: 64,
                  color: Colors.blue,
                ),
                SizedBox(height: 16),
                Text(
                  '用户管理页面',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  '这里可以管理系统的用户信息',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
```

#### 1.2 用户管理控制器

```dart
// lib/modules/system/user/controllers/user_controller.dart
import 'package:get/get.dart';

class UserController extends GetxController {
  final RxList<Map<String, dynamic>> users = <Map<String, dynamic>>[].obs;
  final RxBool isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    loadUsers();
  }

  void loadUsers() {
    isLoading.value = true;
    // 模拟加载用户数据
    Future.delayed(const Duration(seconds: 1), () {
      users.value = [
        {'id': 1, 'name': '张三', 'email': 'zhangsan@example.com'},
        {'id': 2, 'name': '李四', 'email': 'lisi@example.com'},
        {'id': 3, 'name': '王五', 'email': 'wangwu@example.com'},
      ];
      isLoading.value = false;
    });
  }

  void addUser(Map<String, dynamic> user) {
    users.add(user);
  }

  void deleteUser(int id) {
    users.removeWhere((user) => user['id'] == id);
  }
}
```

#### 1.3 用户管理绑定

```dart
// lib/modules/system/user/bindings/user_binding.dart
import 'package:get/get.dart';
import '../controllers/user_controller.dart';

class UserBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<UserController>(() => UserController());
  }
}
```

#### 1.4 角色管理页面

```dart
// lib/modules/system/role/views/role_view.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/role_controller.dart';

class RoleView extends StatelessWidget {
  const RoleView({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RoleController>(
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('角色管理'),
            backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          ),
          body: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.admin_panel_settings,
                  size: 64,
                  color: Colors.green,
                ),
                SizedBox(height: 16),
                Text(
                  '角色管理页面',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  '这里可以管理系统的角色权限',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
```

#### 1.5 角色管理控制器

```dart
// lib/modules/system/role/controllers/role_controller.dart
import 'package:get/get.dart';

class RoleController extends GetxController {
  final RxList<Map<String, dynamic>> roles = <Map<String, dynamic>>[].obs;
  final RxBool isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    loadRoles();
  }

  void loadRoles() {
    isLoading.value = true;
    // 模拟加载角色数据
    Future.delayed(const Duration(seconds: 1), () {
      roles.value = [
        {'id': 1, 'name': '管理员', 'permissions': ['all']},
        {'id': 2, 'name': '编辑者', 'permissions': ['read', 'write']},
        {'id': 3, 'name': '查看者', 'permissions': ['read']},
      ];
      isLoading.value = false;
    });
  }

  void addRole(Map<String, dynamic> role) {
    roles.add(role);
  }

  void deleteRole(int id) {
    roles.removeWhere((role) => role['id'] == id);
  }
}
```

#### 1.6 角色管理绑定

```dart
// lib/modules/system/role/bindings/role_binding.dart
import 'package:get/get.dart';
import '../controllers/role_controller.dart';

class RoleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<RoleController>(() => RoleController());
  }
}
```

### 2. 配置 GetX 路由

#### 2.1 添加路由常量

```dart
// lib/routes/app_routes.dart
part of 'app_pages.dart';

abstract class Routes {
  Routes._();
  static const ROOT = _Paths.ROOT;
  static const LAUNCH = _Paths.LAUNCH;
  static const AUTH = _Paths.AUTH;
  static const HOME = _Paths.HOME;
  
  // 系统管理路由
  static const SYSTEM_USER = _Paths.SYSTEM_USER;
  static const SYSTEM_ROLE = _Paths.SYSTEM_ROLE;
}

abstract class _Paths {
  _Paths._();
  static const ROOT = '/';
  static const LAUNCH = '/launch';
  static const AUTH = '/auth';
  static const HOME = '/home';
  
  // 系统管理路径
  static const SYSTEM_USER = '/system/user';
  static const SYSTEM_ROLE = '/system/role';
}
```

#### 2.2 配置 GetX 路由页面

```dart
// lib/routes/app_pages.dart
import 'package:get/get.dart';
import '../modules/system/user/bindings/user_binding.dart';
import '../modules/system/user/views/user_view.dart';
import '../modules/system/role/bindings/role_binding.dart';
import '../modules/system/role/views/role_view.dart';
// ... 其他导入

part 'app_routes.dart';

class AppPages {
  AppPages._();

  static const INITIAL = Routes.LAUNCH;
  static const ROOT = Routes.ROOT;

  static final routes = [
    // ... 现有路由
    
    // 系统管理路由
    GetPage(
      name: _Paths.SYSTEM_USER,
      page: () => const UserView(),
      binding: UserBinding(),
      transition: Transition.rightToLeft,
      transitionDuration: const Duration(milliseconds: 300),
    ),
    GetPage(
      name: _Paths.SYSTEM_ROLE,
      page: () => const RoleView(),
      binding: RoleBinding(),
      transition: Transition.rightToLeft,
      transitionDuration: const Duration(milliseconds: 300),
    ),
  ];
}
```

### 3. 配置自定义路由系统

#### 3.1 在 RouteController 中添加路由配置

```dart
// lib/layout/controllers/route_controller.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/route_record.dart';

class RouteController extends GetxController {
  // ... 现有代码

  /// 初始化路由数据
  void _initializeRoutes() {
    _routes.value = [
      // ... 现有路由
      
      // 系统管理模块
      RouteRecord(
        path: '/system',
        name: 'System',
        meta: const RouteMeta(
          title: '系统管理',
          svgIcon: 'settings',
          icon: Icons.settings,
          hidden: false,
          affix: false,
          breadcrumb: true,
        ),
        children: [
          RouteRecord(
            path: '/system/user',
            name: 'SystemUser',
            meta: const RouteMeta(
              title: '用户管理',
              svgIcon: 'user',
              icon: Icons.people,
              hidden: false,
              affix: false,
              breadcrumb: true,
            ),
          ),
          RouteRecord(
            path: '/system/role',
            name: 'SystemRole',
            meta: const RouteMeta(
              title: '角色管理',
              svgIcon: 'role',
              icon: Icons.admin_panel_settings,
              hidden: false,
              affix: false,
              breadcrumb: true,
            ),
          ),
        ],
      ),
    ];
  }

  // ... 其他方法
}
```

### 4. 添加图标资源

#### 4.1 在 assets 中添加 SVG 图标

```yaml
# pubspec.yaml
flutter:
  assets:
    - assets/icons/svg/
```

#### 4.2 创建 SVG 图标文件

```
assets/
└── icons/
    └── svg/
        ├── settings.svg
        ├── user.svg
        └── role.svg
```

### 5. 测试路由功能

#### 5.1 在现有页面中添加测试按钮

```dart
// 在任意现有页面中添加测试按钮
ElevatedButton(
  onPressed: () {
    Get.toNamed('/system/user');
  },
  child: const Text('跳转到用户管理'),
),

ElevatedButton(
  onPressed: () {
    Get.toNamed('/system/role');
  },
  child: const Text('跳转到角色管理'),
),
```

#### 5.2 验证菜单显示

启动应用后，您应该能在侧边栏菜单中看到：
- 系统管理（父菜单）
  - 用户管理（子菜单）
  - 角色管理（子菜单）

## 🎨 高级配置

### 1. 添加权限控制

```dart
// 在 RouteMeta 中添加权限字段
RouteRecord(
  path: '/system/user',
  name: 'SystemUser',
  meta: const RouteMeta(
    title: '用户管理',
    svgIcon: 'user',
    icon: Icons.people,
    hidden: false,
    affix: false,
    breadcrumb: true,
    // 添加权限控制
    roles: ['admin', 'user_manager'],
  ),
),
```

### 2. 添加路由守卫

```dart
// lib/middlewares/auth_middleware.dart
import 'package:get/get.dart';
import '../layout/controllers/route_controller.dart';

class AuthMiddleware extends GetMiddleware {
  @override
  RouteSettings? redirect(String? route) {
    // 检查用户权限
    if (route != null) {
      final routeController = Get.find<RouteController>();
      final routeRecord = routeController.findRouteByPath(route);
      
      if (routeRecord?.meta?.roles != null) {
        // 检查用户是否有权限访问
        final userRoles = ['admin']; // 从用户状态获取
        final hasPermission = routeRecord!.meta!.roles!
            .any((role) => userRoles.contains(role));
        
        if (!hasPermission) {
          return const RouteSettings(name: '/403');
        }
      }
    }
    
    return null;
  }
}
```

### 3. 动态路由加载

```dart
// 从后端加载路由配置
Future<void> loadRoutesFromServer() async {
  try {
    final response = await http.get(Uri.parse('/api/routes'));
    final data = json.decode(response.body);
    
    final routes = (data['routes'] as List)
        .map((route) => RouteRecord.fromMap(route))
        .toList();
    
    routeController.setRoutes(routes);
  } catch (e) {
    print('加载路由失败: $e');
  }
}
```

## 🔍 故障排除

### 常见问题

1. **菜单不显示**
   - 检查 `RouteMeta.hidden` 是否为 `false`
   - 确认路由路径配置正确

2. **页面跳转失败**
   - 检查 `app_pages.dart` 中的路由配置
   - 确认页面和绑定类已正确导入

3. **图标不显示**
   - 检查 SVG 文件路径是否正确
   - 确认 `pubspec.yaml` 中已添加资源路径

4. **权限控制不生效**
   - 检查中间件是否正确配置
   - 确认权限检查逻辑正确

## 📝 总结

通过以上步骤，您已经成功添加了一个完整的二级菜单系统。本路由管理系统的优势在于：

- **配置简单**：只需在几个关键文件中添加配置
- **功能完整**：支持菜单、面包屑、权限控制等
- **易于维护**：清晰的文件结构和代码组织
- **可扩展性强**：可以轻松添加更多功能

如果您需要添加更多模块或功能，只需按照相同的模式进行配置即可。