/// @file RouteController 路由状态管理器
/// @description 管理应用路由状态，对应Vue的useRouteStore
import 'package:dang_gui_admin/demo/pages/gi_arco_button_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_dot_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_icon_box_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_icon_selector_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_pagination_demo_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_tag_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_space_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_arrow_popup_demo_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_js_modal_page.dart';
import 'package:dang_gui_admin/demo/pages/api_test_page.dart';
import 'package:dang_gui_admin/modules/home2/home_view.dart';
import 'package:get/get.dart';
import '../../logger.dart';
import '../models/route_record.dart';

/// 路由状态管理器
class RouteController extends GetxController {
  /// 路由列表
  List<RouteRecord> get routes => _routes;
  final RxList<RouteRecord> _routes = <RouteRecord>[].obs;
  
  /// 路由查找缓存
  final Map<String, RouteRecord?> _routeCache = {};
  final Map<String, List<RouteRecord>> _hierarchyCache = {};
  
  /// 路由索引映射（路径 -> 路由记录）
  final Map<String, RouteRecord> _routeIndex = {};

  /// 当前激活的路由路径
  // final RxString _currentPath = '/dashboard'.obs;
  // String get currentPath => _currentPath.value;
  // set currentPath(String path) => _currentPath.value = path;

  /// 内部导航路由路径（用于二级路由系统）
  final RxString _internalPath = '/home'.obs;
  String get internalPath => _internalPath.value;
  set internalPath(String path) => _internalPath.value = path;
  
  /// 从当前路由获取子路由路径
  String get subRouteFromCurrentRoute {
    final currentRoute = Get.currentRoute;
    // 如果当前路由不是全屏路由（launch, auth），则直接使用当前路由
    if (!currentRoute.startsWith('/launch') && !currentRoute.startsWith('/auth')) {
      return currentRoute;
    }
    // 否则返回当前内部路径
    return internalPath;
  }
  
  /// 获取内部路径的响应式对象
  RxString get internalPathRx => _internalPath;

  /// 初始化路由
  @override
  void onInit() {
    super.onInit();
    _initializeRoutes();
    _buildRouteIndex();
  }

  /// 初始化路由数据
  void _initializeRoutes() {
    _routes.value = [
      // 根路由 - 重定向到首页
      RouteRecord(path: '/', name: 'Root', redirect: '/home', meta: const RouteMeta(title: '根路由', hidden: true)),
      // 首页
      RouteRecord(path: '/home', name: 'Home', redirect: '/home', component: HomeView2(), meta: const RouteMeta(title: '首页', svgIcon: 'menu_home')),
      // RouteRecord(path: '/home2', name: 'Home2', redirect: '/home2',component: HomeView2(), meta: const RouteMeta(title: '首页2', svgIcon: 'menu_home')),
      
      // 组件展示 - 一级菜单
      RouteRecord(path: '/components', name: 'Components', meta: const RouteMeta(title: '组件展示', svgIcon: 'menu_example'), children: [
        // 基础组件 - 二级菜单
        RouteRecord(path: '/components/basic', name: 'BasicComponents', meta: const RouteMeta(title: '基础组件', svgIcon: 'menu_form'), children: [
          // 三级菜单
          RouteRecord(path: '/components/basic/button', name: 'Button', component: const GiArcoButtonDemoPage(title: '按钮组件'), meta: const RouteMeta(title: '按钮', svgIcon: 'menu_form')),
          RouteRecord(path: '/components/basic/tag', name: 'Tag', component: const GiTagDemoPage(title: '标签组件'), meta: const RouteMeta(title: '标签', svgIcon: 'menu_form')),
          RouteRecord(path: '/components/basic/dot', name: 'Dot', component: const GiDotDemoPage(title: '圆点组件'), meta: const RouteMeta(title: '圆点', svgIcon: 'menu_form')),
        ]),
        
        // 布局组件 - 二级菜单
        RouteRecord(path: '/components/layout', name: 'LayoutComponents', meta: const RouteMeta(title: '布局组件', svgIcon: 'menu_layout'), children: [
          // 三级菜单
          RouteRecord(path: '/components/layout/space', name: 'Space', component: const GiSpaceDemoPage(title: '间距组件'), meta: const RouteMeta(title: '间距', svgIcon: 'menu_layout')),
          RouteRecord(path: '/components/layout/iconbox', name: 'IconBox', component: const GiIconBoxDemoPage(title: '图标盒子'), meta: const RouteMeta(title: '图标盒子', svgIcon: 'menu_layout')),
        ]),
        
        // 交互组件 - 二级菜单
        RouteRecord(path: '/components/interactive', name: 'InteractiveComponents', meta: const RouteMeta(title: '交互组件', svgIcon: 'menu_nav'), children: [
          // 三级菜单
          RouteRecord(path: '/components/interactive/selector', name: 'IconSelector', component: const GiIconSelectorDemoPage(title: '图标选择器'), meta: const RouteMeta(title: '图标选择器', svgIcon: 'menu_nav')),
          RouteRecord(path: '/components/interactive/pagination', name: 'Pagination', component: const GiPaginationDemoPage(title: '分页组件'), meta: const RouteMeta(title: '分页', svgIcon: 'menu_nav')),
          RouteRecord(path: '/components/interactive/popup', name: 'Popup', component: const GiArrowPopupDemoPage(title: '弹出组件'), meta: const RouteMeta(title: '弹出', svgIcon: 'menu_nav')),
        ]),
      ]),
      
      // 功能演示 - 一级菜单
      RouteRecord(path: '/features', name: 'Features', meta: const RouteMeta(title: '功能演示', svgIcon: 'menu_chart'), children: [
        // API 测试 - 二级菜单
        RouteRecord(path: '/features/api', name: 'ApiTest', component: const ApiTestPage(title: '接口测试'), meta: const RouteMeta(title: '接口测试', svgIcon: 'menu_data')),
        
        // 模态框演示 - 二级菜单
        RouteRecord(path: '/features/modal', name: 'ModalDemo', component: const GiJsModalPage(title: '模态框演示'), meta: const RouteMeta(title: '模态框', svgIcon: 'menu_result')),
      ]),
      
    ];
  }

  /// 创建路由
  RouteRecord createRoute(String path, String name, RouteMeta meta) {
    return RouteRecord(path: path, name: name, meta: meta);
  }

  /// 过滤路由树
  List<RouteRecord> filterTree(
    List<RouteRecord> tree,
    bool Function(RouteRecord) predicate,
  ) {
    final result = <RouteRecord>[];
    
    for (final item in tree) {
      if (predicate(item)) {
        final children = item.children != null 
            ? filterTree(item.children!, predicate)
            : null;
        
        result.add(item.copyWith(children: children));
      }
    }
    
    return result;
  }

  /// 搜索路由树
  List<RouteRecord> searchTree(
    List<RouteRecord> tree,
    bool Function(RouteRecord) predicate,
  ) {
    final stopwatch = Stopwatch()..start();
    final result = <RouteRecord>[];
    
    for (final item in tree) {
      if (predicate(item)) {
        result.add(item);
      }
      
      if (item.children != null) {
        result.addAll(searchTree(item.children!, predicate));
      }
    }
    
    logger.d('🏄🏽‍♂️ [PERF] searchTree completed: ${stopwatch.elapsedMilliseconds}ms, checked ${tree.length} items, found ${result.length} matches');
    return result;
  }

  /// 获取菜单路由（过滤隐藏项）
  List<RouteRecord> get menuRoutes {
    return filterTree(routes, (route) => route.meta?.hidden != true);
  }

  /// 根据路径查找路由
  RouteRecord? findRouteByPath(String path) {
    // 优先使用索引查找（O(1) 时间复杂度）
    if (_routeIndex.containsKey(path)) {
      logger.d('🏄🏽‍♂️ [PERF] findRouteByPath for $path: 0ms (index lookup)');
      return _routeIndex[path];
    }
    
    // 检查缓存
    if (_routeCache.containsKey(path)) {
      logger.d('🏄🏽‍♂️ [PERF] findRouteByPath for $path: 0ms (cached)');
      return _routeCache[path];
    }
    
    final stopwatch = Stopwatch()..start();
    final found = searchTree(routes, (route) => route.path == path);
    final result = found.isNotEmpty ? found.first : null;
    
    // 缓存结果
    _routeCache[path] = result;
    
    logger.d('🏄🏽‍♂️ [PERF] findRouteByPath for $path: ${stopwatch.elapsedMilliseconds}ms (tree search)');
    return result;
  }

  /// 获取路由层级
  List<RouteRecord> getRouteHierarchy(String path) {
    // 检查缓存
    if (_hierarchyCache.containsKey(path)) {
      logger.d('🏄🏽‍♂️ [PERF] getRouteHierarchy for $path: 0ms (cached: true)');
      return _hierarchyCache[path]!;
    }
    
    final stopwatch = Stopwatch()..start();
    logger.d('🏄🏽‍♂️ [PERF] getRouteHierarchy started for: $path');
    
    final hierarchy = <RouteRecord>[];
    final segments = path.split('/').where((s) => s.isNotEmpty).toList();
    
    String currentPath = '';
    for (final segment in segments) {
      currentPath += '/$segment';
      final route = findRouteByPath(currentPath);
      if (route != null) {
        hierarchy.add(route);
      }
    }
    
    // 缓存结果
    _hierarchyCache[path] = hierarchy;
    
    logger.d('🏄🏽‍♂️ [PERF] getRouteHierarchy completed: ${stopwatch.elapsedMilliseconds}ms, found ${hierarchy.length} routes (cached: false)');
    return hierarchy;
  }

  /// 设置路由
  void setRoutes(List<RouteRecord> newRoutes) {
    _routes.value = newRoutes;
    // 路由变化时清理缓存
    _clearCache();
  }
  
  /// 构建路由索引
  void _buildRouteIndex() {
    final stopwatch = Stopwatch()..start();
    _routeIndex.clear();
    
    void indexRoutes(List<RouteRecord> routes) {
      for (final route in routes) {
        _routeIndex[route.path] = route;
        if (route.children != null) {
          indexRoutes(route.children!);
        }
      }
    }
    
    indexRoutes(_routes);
    logger.d('🏄🏽‍♂️ [PERF] Route index built: ${stopwatch.elapsedMilliseconds}ms, indexed ${_routeIndex.length} routes');
  }
  
  /// 清理缓存
  void _clearCache() {
    _routeCache.clear();
    _hierarchyCache.clear();
    _buildRouteIndex(); // 重新构建索引
  }

  /// 添加路由
  void addRoute(RouteRecord route) {
    _routes.add(route);
  }

  /// 移除路由
  void removeRoute(String path) {
    _routes.removeWhere((route) => route.path == path);
  }
}
