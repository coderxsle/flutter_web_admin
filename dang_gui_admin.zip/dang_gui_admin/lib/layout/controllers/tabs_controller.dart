/// @file TabsController 标签页状态管理器
/// @description 管理标签页状态，对应Vue的useTabsStore
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/route_record.dart';

/// 标签页项
class TabItem {
  /// 路由路径
  final String path;
  /// 完整路径
  final String? fullPath;
  /// 路由名称
  final String? name;
  /// 路由元数据
  final RouteMeta? meta;
  /// 查询参数
  final Map<String, String>? query;

  const TabItem({
    required this.path,
    this.fullPath,
    this.name,
    this.meta,
    this.query,
  });

  /// 从路由记录创建标签页项
  factory TabItem.fromRoute(RouteRecord route) {
    return TabItem(
      path: route.path,
      fullPath: route.fullPath,
      name: route.name,
      meta: route.meta,
    );
  }

  /// 复制并修改
  TabItem copyWith({
    String? path,
    String? fullPath,
    String? name,
    RouteMeta? meta,
    Map<String, String>? query,
  }) {
    return TabItem(
      path: path ?? this.path,
      fullPath: fullPath ?? this.fullPath,
      name: name ?? this.name,
      meta: meta ?? this.meta,
      query: query ?? this.query,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is TabItem && other.path == path;
  }

  @override
  int get hashCode => path.hashCode;
}

/// 标签页状态管理器
class TabsController extends GetxController {
  /// 标签页列表
  final RxList<TabItem> _tabList = <TabItem>[].obs;
  List<TabItem> get tabList => _tabList;
  RxList<TabItem> get tabListObs => _tabList;

  /// 缓存列表
  final RxList<String> _cacheList = <String>[].obs;
  List<String> get cacheList => _cacheList;

  /// 重载标志
  final RxBool _reloadFlag = true.obs;
  bool get reloadFlag => _reloadFlag.value;

  /// 初始化标签页
  void init() {
    // 添加首页标签页
    final homeTab = TabItem(
      path: '/home',
      name: 'Home',
      meta: const RouteMeta(
        title: '首页',
        affix: true,
        svgIcon: 'home',
      ),
    );
    
    if (!_tabList.contains(homeTab)) {
      _tabList.add(homeTab);
      _cacheList.add(homeTab.name ?? homeTab.path);
    }
  }

  /// 添加标签页项
  void addTabItem(TabItem tab) {
    // 检查是否已存在
    final existingIndex = _tabList.indexWhere((item) => item.path == tab.path);
    
    if (existingIndex >= 0) {
      // 更新已存在的标签页
      _tabList[existingIndex] = tab;
    } else {
      // 添加新标签页
      _tabList.add(tab);
    }
  }

  /// 从路由记录添加标签页项
  void addTabItemFromRoute(RouteRecord route) {
    final tab = TabItem.fromRoute(route);
    addTabItem(tab);
  }

  /// 添加缓存项
  void addCacheItem(String routeName) {
    if (!_cacheList.contains(routeName)) {
      _cacheList.add(routeName);
    }
  }

  /// 从路由记录添加缓存项
  void addCacheItemFromRoute(RouteRecord route) {
    final routeName = route.name ?? route.path;
    addCacheItem(routeName);
  }

  /// 关闭当前标签页
  void closeCurrent([String? targetPath]) {
    final pathToClose = targetPath ?? Get.currentRoute;
    
    // 查找要关闭的标签页
    final targetTab = _tabList.firstWhereOrNull((tab) => tab.path == pathToClose);
    if (targetTab == null) return;
    
    // 不能关闭固定标签页
    if (targetTab.meta?.affix == true) {
      Get.snackbar('提示', '固定标签页不能关闭');
      return;
    }
    
    // 移除标签页和缓存
    _tabList.removeWhere((tab) => tab.path == pathToClose);
    _cacheList.removeWhere((cache) => cache == targetTab.name || cache == pathToClose);
    
    // 如果关闭的是当前标签页，需要导航到其他标签页
    if (pathToClose == Get.currentRoute && _tabList.isNotEmpty) {
      final nextTab = _tabList.last;
      Get.toNamed(nextTab.fullPath ?? nextTab.path);
    }
  }

  /// 关闭右侧标签页
  void closeRight(String targetPath) {
    final targetIndex = _tabList.indexWhere((tab) => tab.path == targetPath);
    if (targetIndex < 0) return;
    
    // 获取右侧可关闭的标签页
    final rightTabs = _tabList.skip(targetIndex + 1).where((tab) => 
        tab.meta?.affix != true).toList();
    
    // 移除标签页和缓存
    for (final tab in rightTabs) {
      _tabList.removeWhere((item) => item.path == tab.path);
      _cacheList.removeWhere((cache) => 
          cache == tab.name || cache == tab.path);
    }
  }

  /// 关闭其他标签页
  void closeOther(String targetPath) {
    final targetTab = _tabList.firstWhereOrNull((tab) => tab.path == targetPath);
    if (targetTab == null) return;
    
    // 保留固定标签页和目标标签页
    final tabsToKeep = _tabList.where((tab) => 
        tab.meta?.affix == true || tab.path == targetPath).toList();
    
    // 更新缓存列表
    final cachesToKeep = tabsToKeep.map((tab) => 
        tab.name ?? tab.path).toList();
    
    _tabList.value = tabsToKeep;
    _cacheList.value = cachesToKeep;
  }

  /// 关闭全部标签页
  void closeAll() {
    // 只保留固定标签页
    final fixedTabs = _tabList.where((tab) => tab.meta?.affix == true).toList();
    final fixedCaches = fixedTabs.map((tab) => tab.name ?? tab.path).toList();
    
    _tabList.value = fixedTabs;
    _cacheList.value = fixedCaches;
    
    // 导航到首页
    if (fixedTabs.isNotEmpty) {
      final homeTab = fixedTabs.first;
      Get.toNamed(homeTab.fullPath ?? homeTab.path);
    }
  }

  /// 重载页面
  void reloadPage() {
    _reloadFlag.value = false;
    Future.delayed(const Duration(milliseconds: 50), () {
      _reloadFlag.value = true;
    });
  }

  /// 移除缓存项
  void removeCacheItem(String routeName) {
    _cacheList.remove(routeName);
  }

  /// 清空标签页
  void clear() {
    _tabList.clear();
    _cacheList.clear();
  }

  /// 根据路径查找标签页
  TabItem? findTabByPath(String path) {
    return _tabList.firstWhereOrNull((tab) => tab.path == path);
  }

  /// 获取当前标签页索引
  int getCurrentTabIndex() {
    final currentPath = Get.currentRoute;
    return _tabList.indexWhere((tab) => tab.path == currentPath);
  }

  /// 设置标签页列表（用于拖拽排序）
  void setTabList(List<TabItem> newTabList) {
    _tabList.value = newTabList;
  }
}
