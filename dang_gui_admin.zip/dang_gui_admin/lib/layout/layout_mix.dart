/// @file LayoutMix 组件
/// @description 混合布局组件，支持顶部导航和左侧菜单组合的布局方式
import 'package:dang_gui_admin/layout/layout.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'components/app_logo.dart';
import 'components/app_main.dart';
import 'components/header_right_bar/header_right_bar.dart';
import 'components/menu/app_menu.dart';
import 'components/menu/menu_icon.dart';
import 'components/menu_fold_btn.dart';
import 'components/tabs/app_tabs.dart';
import 'controllers/route_controller.dart';
import 'layout_index.dart';
import 'models/route_record.dart';

/// 混合布局组件
class LayoutMix extends StatefulWidget {
  const LayoutMix({super.key});

  @override
  State<LayoutMix> createState() => _LayoutMixState();
}

class _LayoutMixState extends State<LayoutMix> {
  /// 顶部一级菜单
  List<RouteRecord> _topMenus = [];
  
  /// 当前激活的菜单
  List<String> _activeMenu = [];
  
  /// 左侧菜单
  List<RouteRecord> _leftMenus = [];

  @override
  void initState() {
    super.initState();
    _initializeMenus();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _handleRouteChange();
  }

  /// 初始化菜单
  void _initializeMenus() {
    final routeController = Get.find<RouteController>();
    
    // 获取菜单路由
    final menuRoutes = routeController.menuRoutes;
    
    // 设置顶部一级菜单
    _topMenus = List.from(menuRoutes);
    
    // 根据当前路由设置左侧菜单
    _handleRouteChange();
  }

  /// 处理路由变化
  void _handleRouteChange() {
    final currentRoute = Get.currentRoute;
    _getLeftMenus(currentRoute);
  }

  /// 获取左侧菜单
  void _getLeftMenus(String path) {
    final routeController = Get.find<RouteController>();
    
    // 搜索包含当前路径的路由
    final foundItems = routeController.searchTree(
      _topMenus,
      (item) => path.startsWith(item.path),
    );
    
    String rootPath = '';
    if (foundItems.isNotEmpty) {
      // 找到最匹配的根路径
      foundItems.sort((a, b) => b.path.length.compareTo(a.path.length));
      rootPath = foundItems.first.path;
    }
    
    // 查找目标菜单
    final targetMenu = _topMenus.firstWhereOrNull(
      (item) => item.path == rootPath,
    );
    
    setState(() {
      _activeMenu = targetMenu != null ? [targetMenu.path] : [];
      _leftMenus = targetMenu?.children ?? [];
    });
  }

  /// 获取菜单图标
  String? _getMenuIcon(RouteRecord item, String key) {
    if (key == 'svgIcon') {
      return item.meta?.svgIcon ?? item.children?.first.meta?.svgIcon;
    } else if (key == 'icon') {
      // 这里可以返回IconData，但由于类型限制，暂时返回null
      return null;
    }
    return null;
  }

  /// 判断是否为外部链接
  bool _isExternal(String url) {
    return url.startsWith('http://') || url.startsWith('https://');
  }

  /// 处理菜单项点击
  void _handleMenuItemClick(String key) {
    if (_isExternal(key)) {
      // 打开外部链接
      debugPrint('Open external link: $key');
      return;
    }

    // 延迟获取左侧菜单，模拟Vue的setTimeout
    Future.delayed(const Duration(milliseconds: 10), () {
      _getLeftMenus(key);
    });
    
    final targetMenu = _topMenus.firstWhereOrNull((item) => item.path == key);
    if (targetMenu?.redirect == 'noRedirect') return;

    Get.toNamed(key);
  }

  /// 构建顶部水平菜单
  Widget _buildTopMenu() {
    final theme = Theme.of(context);
    
    return Container(
      height: 48,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: _topMenus.map((item) {
            final isActive = _activeMenu.contains(item.path);
            final svgIcon = _getMenuIcon(item, 'svgIcon');
            
            return GestureDetector(
              onTap: () => _handleMenuItemClick(item.path),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                margin: const EdgeInsets.symmetric(horizontal: 2),
                decoration: BoxDecoration(
                  color: isActive 
                      ? theme.primaryColor.withOpacity(0.1)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // 菜单图标
                    if (svgIcon != null) ...[
                      MenuIcon(
                        props: MenuIconProps(
                          svgIcon: svgIcon,
                          size: 32,
                          color: isActive 
                              ? theme.primaryColor 
                              : theme.iconTheme.color,
                        ),
                      ),
                      const SizedBox(width: 8),
                    ],
                    
                    // 菜单标题
                    Text(
                      item.meta?.title ?? 
                      item.children?.first.meta?.title ?? 
                      '',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                        color: isActive 
                            ? theme.primaryColor 
                            : theme.textTheme.bodyMedium?.color,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final appController = Get.find<AppLayoutController>();
    final deviceController = Get.find<DeviceController>();
    final theme = Theme.of(context);
    
    return Scaffold(
      endDrawer: Drawer(
        child: const SettingDrawer(),
      ),
      body: Obx(() => Row(
        children: [
          // 左侧菜单区域（仅桌面端显示）
          if (deviceController.isDesktop)
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: appController.menuCollapse ? 64 : 200,
              decoration: BoxDecoration(
                color: appController.menuDark 
                    ? Colors.grey[900] 
                    : theme.cardColor,
                border: Border(
                  right: BorderSide(
                    color: theme.dividerColor,
                    width: 1,
                  ),
                ),
              ),
              child: Column(
                children: [
                  // Logo区域
                  Logo(collapsed: appController.menuCollapse),
                  
                  // 左侧菜单
                  Expanded(
                    child: AppMenu(
                      props: AppMenuProps(
                        menus: _leftMenus,
                        collapsed: appController.menuCollapse,
                        decoration: BoxDecoration(
                          color: appController.menuDark 
                              ? Colors.grey[900] 
                              : Colors.transparent,
                        ),
                      ),
                      onRouteChanged: (path) {
                        // 更新内部路由状态
                        final routeController = Get.find<RouteController>();
                        routeController.internalPath = path;
                      },
                    ),
                  ),
                ],
              ),
            ),
          
          // 右侧内容区域
          Expanded(
            child: Column(
              children: [
                // 头部区域
                Container(
                  height: 56,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: theme.appBarTheme.backgroundColor ?? theme.cardColor,
                    border: Border(
                      bottom: BorderSide(
                        color: theme.dividerColor,
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      // 菜单折叠按钮
                      const MenuFoldBtn(),
                      
                      // 顶部水平菜单（仅桌面端显示）
                      if (deviceController.isDesktop) ...[
                        const SizedBox(width: 16),
                        Expanded(child: _buildTopMenu()),
                      ] else
                        const Expanded(child: SizedBox.shrink()),
                      
                      // 右侧工具栏
                      const HeaderRightBar(),
                    ],
                  ),
                ),
                
                // 标签页
                Obx(() => appController.tabVisible 
                    ? const AppTabs() 
                    : const SizedBox.shrink()),
                
                // 主内容区
                const Main(),
              ],
            ),
          ),
        ],
      )),
    );
  }
}
