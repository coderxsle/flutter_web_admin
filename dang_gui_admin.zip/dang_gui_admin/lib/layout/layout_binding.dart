/// @file LayoutBinding 布局绑定
/// @description 布局系统的依赖注入绑定，初始化所有必要的控制器
import 'package:get/get.dart';
import 'components/header_right_bar/header_right_bar.dart';
import 'components/menu_fold_btn.dart';
import 'controllers/route_controller.dart';
import 'controllers/tabs_controller.dart';
import 'layout_index.dart';

/// 布局系统绑定
class LayoutBinding extends Bindings {
  @override
  void dependencies() {
    // 注册核心控制器
    Get.lazyPut<AppLayoutController>(() => AppLayoutController());
    Get.lazyPut<RouteController>(() => RouteController());
    Get.lazyPut<TabsController>(() => TabsController());
    Get.lazyPut<DeviceController>(() => DeviceController());
    Get.lazyPut<UserController>(() => UserController());
  }
}

/// 布局系统初始化
class LayoutInitializer {
  /// 初始化布局系统
  static void initialize() {
    // 确保所有控制器都已注册
    Get.put(AppLayoutController());
    Get.put(RouteController());
    Get.put(TabsController());
    Get.put(DeviceController());
    Get.put(UserController());
    
    // 初始化标签页
    final tabsController = Get.find<TabsController>();
    tabsController.init();
  }
}

/// 布局系统扩展方法
extension LayoutExtensions on GetInterface {
  /// 获取布局控制器
  AppLayoutController get layout => Get.find<AppLayoutController>();
  
  /// 获取路由控制器
  RouteController get routes => Get.find<RouteController>();
  
  /// 获取标签页控制器
  TabsController get tabs => Get.find<TabsController>();
  
  /// 获取设备控制器
  DeviceController get device => Get.find<DeviceController>();
  
  /// 获取用户控制器
  UserController get user => Get.find<UserController>();
}
