import 'package:get/get.dart';
import '../services/auth_service.dart';
import '../services/permission_service.dart';

/// 初始化绑定
class InitialBinding extends Bindings {
  @override
  void dependencies() {
    // 注册核心服务
    Get.put(AuthService(), permanent: true);
    Get.put(PermissionService(), permanent: true);
    
    // 注意：AdminLayoutController 需要在 GetMaterialApp 创建后初始化
    // 所以这里不注册 AdminLayoutController
  }
}
