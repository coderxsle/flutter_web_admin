import 'dart:io';
import 'dart:typed_data';

import 'package:record/record.dart';
import 'package:dang_gui_admin/logger.dart';

import 'recorder_service.dart';

/// 实时转写服务
/// 
/// 提供实时转写功能，支持音频流输入
/// TODO: 支持 自定义实时转写服务
/// TODO: 支持 科大讯飞实时转写服务
class RealtimeTranscriptionService {


  // 配置录音参数
  final RecordConfig config = RecordConfig(
    encoder: AudioEncoder.pcm16bits,  // PCM 16bit
    sampleRate: 16000,                // 16kHz 采样率
    numChannels: 1,                   // 单声道
  );
  
  // 录音机服务
  late final RecorderService _recorderService;

  // 转写文本
  String transcriptionText = '';



  
  // 开始实时语音转写
  // 实时转写需要录音，所以需要先检查录音权限
  // 如果已经在录音，则停止录音和转写
  // 如果未录音，则开始录音并获取音频流
  // 然后开始实时转写
  Future<void> start() async {
    // 开始录音并获取音频流
    _recorderService.startRecording(config, (stream) {
      _listenAudioStream(stream);
    });
    // 订阅转写结果
    _listenTranscriptionResult();

    // 开始实时转写
    // final connected = await _xunfeiRealtime.connect();
    // if (!connected) throw '实时转写服务连接失败';
  }


  // 停止实时转写
  Future<void> stopRealtimeTranscription() async {
    // 停止录音和转写
    final recordingPath = await _recorderService.stopRecording();
    if (recordingPath != null) {
      logger.i('录音文件已保存到: $recordingPath');
      
      // 保存转写文本
      final transcriptionFile = File('${recordingPath.replaceAll('.pcm', '')}_transcription.txt');
      await transcriptionFile.writeAsString(transcriptionText);
      logger.i('转写文本已保存到: ${transcriptionFile.path}');
    }
    
    // await _xunfeiRealtime.sendEndSignal();
    // _xunfeiRealtime.disconnect();
    return;
  }


  // 订阅录音机开始录音的音频流
  // 开始录音后，需要订阅录音机开始录音的音频流，并发送给实时转写服务
  void _listenAudioStream(Stream<Uint8List> stream) {
    // logger.i('开始订阅音频流');
    // stream.listen((data) async {
    //     if (isRealtimeTranscribing) {
    //       try {
    //         await _realtimeService.sendAudioData(Uint8List.fromList(data));
    //       } catch (e) {
    //         logger.e('发送音频数据失败', error: e);
    //         isRealtimeTranscribing = false;
    //       }
    //     }
    //   },
    //   onError: (error) {
    //     logger.e('音频流错误', error: error);
    //     isRealtimeTranscribing = false;
    //   },
    //   onDone: () {
    //     logger.i('音频流结束');
    //     isRealtimeTranscribing = false;
    //   },
    // );
  }



  // 订阅转写结果
  void _listenTranscriptionResult() {
    // _realtimeService.resultStream.listen((result) {
    //     transcriptionText += result;
    //   },
    //   onError: (error) {
    //     logger.e('转写出错', error: error);
    //     transcriptionText = '转写出错: $error';
    //     isRealtimeTranscribing = false;
    //   },
    // );
  }


}