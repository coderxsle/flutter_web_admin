import 'dart:async';
import 'dart:io';
import 'dart:developer';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:dang_gui_admin/utils/audio_utils.dart';
import 'package:dang_gui_admin/utils/permission_manager.dart';

// 音频流类型
typedef AudioStream = ValueChanged<Stream<Uint8List>>;

/// 音频录制服务
/// 提供实时录音功能，支持音频流输出
class RecorderService {
  final _audioRecorder = AudioRecorder();
  bool _isRecording = false;
  StreamController<List<int>>? _audioStreamController;
  final List<int> _audioBuffer = [];  // 用于存储录音数据
  
  final int bufferSize = 1280;  // 每次读取1280字节

  /// 当前是否正在录音
  bool get isRecording => _isRecording;
  
  /// 获取音频数据流
  Stream<List<int>>? get audioStream => _audioStreamController?.stream;

  
  /// 释放资源
  /// 
  /// 停止录音并关闭数据流
  Future<void> dispose() async {
    log('释放录音服务资源');
    await stopRecording();
    _audioStreamController?.close();
    _audioBuffer.clear();
  }
  
  
  /*
   * 开始录音
   * 
   * 会创建临时文件存储录音数据，并开启数据流 
   * 
   * 如果已经在录音，则不会重新开始
   * 
   * config: 录音配置
   * stream: 音频数据流回调函数，参数为音频流
   */
  startRecording(RecordConfig config, AudioStream stream) async {
    
    // 如果已经在录音中，忽略此次调用
    if (_isRecording) { log('已经在录音中，忽略此次调用'); return; }

    PermissionManager.recordingWithLocation(context: Get.context!, onResult: (record, location) async {

      if (!record) { log('未获得麦克风权限，无法开始录音'); return; }
      if (!location) { log('未获得定位权限，无法开始录音'); return; }

      log('开始录音，配置: 采样率=${config.sampleRate}Hz, 位深=${config.encoder}, 声道=${config.numChannels}');
      
      // 清空缓冲区
      _audioBuffer.clear();
      
      // 开始录音并获取音频流
      final audioStream = await _audioRecorder.startStream(config);
      _isRecording = true;

      // 将音频流传递给回调函数
      stream.call(audioStream);

      // 监听音频流并存储数据
      audioStream.listen((data) {
          if (!_isRecording) return;
          // 将数据添加到数据流
          _audioStreamController?.add(data);
          // 将数据添加到缓冲区
          _audioBuffer.addAll(data);
          // logger.i('监听到音频流...');
        },
        onError: (error) {
          log('音频流错误: $error');
          _audioStreamController?.addError(error);
        },
        onDone: () {
          log('音频流结束');
          _audioStreamController?.close();
        },
      );
    });
  }




  /*
   * 停止录音
   * 
   * 会保存录音文件，关闭数据流，然后删除临时文件
   * 
   * return: 保存的文件路径，如果保存失败返回null
   */
  Future<String?> stopRecording() async {
    if (!_isRecording) {
      log('当前没有录音在进行');
      return null;
    }
    
    log('准备停止录音');
    await _audioRecorder.stop();
    _isRecording = false;
    
    // 关闭数据流
    await _audioStreamController?.close();
    _audioStreamController = null;
    
    // 如果有录音数据，保存到文件
    if (_audioBuffer.isNotEmpty) {
      // 生成保存文件的路径
      final saveDir = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final savePath = '${saveDir.path}/recording_$timestamp.pcm';
      
      // 保存数据到文件
      log('正在保存录音文件到: $savePath');
      final file = File(savePath);
      await file.writeAsBytes(_audioBuffer);
      log('录音文件保存成功');
      
      // 检查保存的文件属性
      AudioUtils.logProperties(savePath);
      
      // 清空缓冲区
      _audioBuffer.clear();
      
      // 返回保存的文件路径
      return savePath;
    }
    
    log('录音已完全停止');
    return null;
  }


} 