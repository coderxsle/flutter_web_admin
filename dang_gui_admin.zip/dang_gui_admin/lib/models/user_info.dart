class UserInfo {
  final String id;               // 用户ID
  final int? userId;             // 原用户ID（兼容）
  final int? deptId;             // 部门ID
  final String username;         // 用户名
  final String? userName;        // 用户名（兼容）
  final String nickname;         // 昵称
  final String? nickName;        // 昵称（兼容）
  final String? userType;        // 用户类型
  final String? email;           // 邮箱
  final String? phonenumber;     // 手机号
  final String? sex;             // 性别
  final String? avatar;          // 头像
  final String? password;        // 密码
  String? accessToken;           // 访问令牌
  final String? status;          // 状态
  final String? delFlag;         // 删除标志
  final String? loginIp;         // 最后登录IP
  final String? loginDate;       // 最后登录时间
  final String? createBy;        // 创建者
  final String? createTime;      // 创建时间
  final DateTime? createdAt;     // 创建时间
  final String? updateBy;        // 更新者
  final String? updateTime;      // 更新时间
  final DateTime? updatedAt;     // 更新时间
  final String? remark;          // 备注
  final bool? admin;             // 是否管理员
  final String? postIds;         // 岗位ID集合
  final String? roleIds;         // 角色ID集合
  final String role;             // 角色
  final List<String> permissions; // 权限列表
  final DeptInfo? dept;          // 所属部门
  final List<RoleInfo>? roles;   // 角色列表（兼容）

  UserInfo({
    required this.id,
    required this.username,
    required this.nickname,
    required this.role,
    this.permissions = const [],
    this.userId,
    this.deptId,
    this.userName,
    this.nickName,
    this.userType,
    this.email,
    this.phonenumber,
    this.sex,
    this.avatar,
    this.password,
    this.accessToken,
    this.status,
    this.delFlag,
    this.loginIp,
    this.loginDate,
    this.createBy,
    this.createTime,
    this.createdAt,
    this.updateBy,
    this.updateTime,
    this.updatedAt,
    this.remark,
    this.admin,
    this.postIds,
    this.roleIds,
    this.dept,
    this.roles,
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) {
    return UserInfo(
      id: json['id']?.toString() ?? json['userId']?.toString() ?? '',
      username: json['username'] ?? json['userName'] ?? '',
      nickname: json['nickname'] ?? json['nickName'] ?? '',
      role: json['role']?.toString() ?? 'user',
      permissions: json['permissions'] is List 
          ? List<String>.from(json['permissions']) 
          : <String>[],
      userId: json['userId'],
      deptId: json['deptId'],
      userName: json['userName'],
      nickName: json['nickName'],
      userType: json['userType'],
      email: json['email'],
      phonenumber: json['phonenumber'],
      sex: json['sex'],
      avatar: json['avatar'],
      password: json['password'],
      accessToken: json['accessToken'],
      status: json['status'],
      delFlag: json['delFlag'],
      loginIp: json['loginIp'],
      loginDate: json['loginDate'],
      createBy: json['createBy'],
      createTime: json['createTime'],
      createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : null,
      updateBy: json['updateBy'],
      updateTime: json['updateTime'],
      updatedAt: json['updatedAt'] != null ? DateTime.parse(json['updatedAt']) : null,
      remark: json['remark'],
      admin: json['admin'],
      postIds: json['postIds'],
      roleIds: json['roleIds'],
      dept: json['dept'] is Map<String, dynamic> ? DeptInfo.fromJson(json['dept']) : null,
      roles: json['roles'] is List
          ? (json['roles'] as List)
              .whereType<Map<String, dynamic>>()
              .map((e) => RoleInfo.fromJson(e))
              .toList()
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'nickname': nickname,
      'role': role,
      'permissions': permissions,
      'userId': userId,
      'deptId': deptId,
      'userName': userName,
      'nickName': nickName,
      'userType': userType,
      'email': email,
      'phonenumber': phonenumber,
      'sex': sex,
      'avatar': avatar,
      'password': password,
      'accessToken': accessToken,
      'status': status,
      'delFlag': delFlag,
      'loginIp': loginIp,
      'loginDate': loginDate,
      'createBy': createBy,
      'createTime': createTime,
      'createdAt': createdAt?.toIso8601String(),
      'updateBy': updateBy,
      'updateTime': updateTime,
      'updatedAt': updatedAt?.toIso8601String(),
      'remark': remark,
      'admin': admin,
      'postIds': postIds,
      'roleIds': roleIds,
      'dept': dept?.toJson(),
      'roles': roles?.map((e) => e.toJson()).toList(),
    };
  }

  
}



class DeptInfo {
  final int? deptId;             // 部门ID
  final int? parentId;           // 上级部门ID
  final String? ancestors;       // 部门祖级列表
  final String? deptName;        // 部门名称
  final int? orderNum;           // 排序编号
  final String? leader;          // 部门负责人
  final String? phone;           // 联系电话
  final String? email;           // 邮箱
  final String? status;          // 状态
  final String? delFlag;         // 删除标志
  final String? createBy;        // 创建者
  final String? createTime;      // 创建时间
  final String? updateBy;        // 更新者
  final String? updateTime;      // 更新时间

  DeptInfo({
    this.deptId,
    this.parentId,
    this.ancestors,
    this.deptName,
    this.orderNum,
    this.leader,
    this.phone,
    this.email,
    this.status,
    this.delFlag,
    this.createBy,
    this.createTime,
    this.updateBy,
    this.updateTime,
  });

  factory DeptInfo.fromJson(Map<String, dynamic> json) {
    return DeptInfo(
      deptId: json['deptId'],
      parentId: json['parentId'],
      ancestors: json['ancestors'],
      deptName: json['deptName'],
      orderNum: json['orderNum'],
      leader: json['leader'],
      phone: json['phone'],
      email: json['email'],
      status: json['status'],
      delFlag: json['delFlag'],
      createBy: json['createBy'],
      createTime: json['createTime'],
      updateBy: json['updateBy'],
      updateTime: json['updateTime'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'deptId': deptId,
      'parentId': parentId,
      'ancestors': ancestors,
      'deptName': deptName,
      'orderNum': orderNum,
      'leader': leader,
      'phone': phone,
      'email': email,
      'status': status,
      'delFlag': delFlag,
      'createBy': createBy,
      'createTime': createTime,
      'updateBy': updateBy,
      'updateTime': updateTime,
    };
  }
}

class RoleInfo {
  final int? roleId;             // 角色ID
  final String? roleName;        // 角色名称
  final String? roleKey;         // 角色权限字符串
  final int? roleSort;           // 角色顺序
  final String? dataScope;       // 数据权限范围
  final bool? menuCheckStrictly; // 菜单严格控制
  final bool? deptCheckStrictly; // 部门严格控制
  final String? status;          // 状态
  final String? delFlag;         // 删除标志
  final String? createBy;        // 创建者
  final String? createTime;      // 创建时间
  final String? updateBy;        // 更新者
  final String? updateTime;      // 更新时间
  final String? remark;          // 备注
  final bool? admin;             // 是否管理员

  RoleInfo({
    this.roleId,
    this.roleName,
    this.roleKey,
    this.roleSort,
    this.dataScope,
    this.menuCheckStrictly,
    this.deptCheckStrictly,
    this.status,
    this.delFlag,
    this.createBy,
    this.createTime,
    this.updateBy,
    this.updateTime,
    this.remark,
    this.admin,
  });

  factory RoleInfo.fromJson(Map<String, dynamic> json) {
    return RoleInfo(
      roleId: json['roleId'],
      roleName: json['roleName'],
      roleKey: json['roleKey'],
      roleSort: json['roleSort'],
      dataScope: json['dataScope'],
      menuCheckStrictly: json['menuCheckStrictly'],
      deptCheckStrictly: json['deptCheckStrictly'],
      status: json['status'],
      delFlag: json['delFlag'],
      createBy: json['createBy'],
      createTime: json['createTime'],
      updateBy: json['updateBy'],
      updateTime: json['updateTime'],
      remark: json['remark'],
      admin: json['admin'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'roleId': roleId,
      'roleName': roleName,
      'roleKey': roleKey,
      'roleSort': roleSort,
      'dataScope': dataScope,
      'menuCheckStrictly': menuCheckStrictly,
      'deptCheckStrictly': deptCheckStrictly,
      'status': status,
      'delFlag': delFlag,
      'createBy': createBy,
      'createTime': createTime,
      'updateBy': updateBy,
      'updateTime': updateTime,
      'remark': remark,
      'admin': admin,
    };
  }
}