import 'user_info.dart';

class Login {
  final List<String>? permissions;  // 权限列表
  final List<String>? roles;        // 角色列表
  final UserInfo? user;             // 用户信息

  Login({this.permissions, this.roles, this.user});

  factory Login.fromJson(Map<String, dynamic> json) {
    return Login(
      permissions: json['permissions'] is List
          ? (json['permissions'] as List).map((e) => e.toString()).toList()
          : null,
      roles: json['roles'] is List
          ? (json['roles'] as List).map((e) => e.toString()).toList()
          : null,
      user: json['user'] is Map<String, dynamic>
          ? UserInfo.fromJson(json['user'])
          : null,
    );
  }
}


