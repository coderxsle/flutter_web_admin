part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();

  static const LAUNCH = _Paths.LAUNCH;
  static const AUTH = _Paths.AUTH;
  static const DASHBOARD = _Paths.DASHBOARD;
  static const AUTH2 = _Paths.AUTH2;
  static const AUTH3 = _Paths.AUTH3;
  static const HOME = _Paths.HOME;
  static const HOME2 = _Paths.HOME2;
  static const SECOND = _Paths.SECOND;
  static const THREE = _Paths.THREE;
  static const THEME_SETTINGS = _Paths.THEME_SETTINGS;
  static const RECORDING = _Paths.RECORDING;
  static const REALTIME = _Paths.REALTIME;
  static const FUNASR = _Paths.FUNASR;
  static const DEMO = _Paths.DEMO;
  
  // 3级菜单路由
  // static const COMPONENTS = _Paths.COMPONENTS;
  // static const COMPONENTS_BASIC = _Paths.COMPONENTS_BASIC;
  // static const COMPONENTS_BASIC_BUTTON = _Paths.COMPONENTS_BASIC_BUTTON;
  // static const COMPONENTS_BASIC_TAG = _Paths.COMPONENTS_BASIC_TAG;
  // static const COMPONENTS_BASIC_DOT = _Paths.COMPONENTS_BASIC_DOT;
  // static const COMPONENTS_LAYOUT = _Paths.COMPONENTS_LAYOUT;
  // static const COMPONENTS_LAYOUT_SPACE = _Paths.COMPONENTS_LAYOUT_SPACE;
  // static const COMPONENTS_LAYOUT_ICONBOX = _Paths.COMPONENTS_LAYOUT_ICONBOX;
  // static const COMPONENTS_INTERACTIVE = _Paths.COMPONENTS_INTERACTIVE;
  // static const COMPONENTS_INTERACTIVE_SELECTOR = _Paths.COMPONENTS_INTERACTIVE_SELECTOR;
  // static const COMPONENTS_INTERACTIVE_PAGINATION = _Paths.COMPONENTS_INTERACTIVE_PAGINATION;
  // static const COMPONENTS_INTERACTIVE_POPUP = _Paths.COMPONENTS_INTERACTIVE_POPUP;
  // static const FEATURES = _Paths.FEATURES;
  // static const FEATURES_API = _Paths.FEATURES_API;
  // static const FEATURES_MODAL = _Paths.FEATURES_MODAL;
}

abstract class _Paths {
  _Paths._();

  static const LAUNCH = '/launch';
  static const AUTH = '/auth';
  static const DASHBOARD = '/dashboard';
  static const AUTH2 = '/auth2';
  static const AUTH3 = '/auth3';
  static const HOME = '/home';
  static const HOME2 = '/home2';
  static const SECOND = '/second';
  static const THREE = '/three';
  static const THEME_SETTINGS = '/theme-settings';
  static const RECORDING = '/recording';
  static const REALTIME = '/realtime';
  static const FUNASR = '/funasr';
  static const DEMO = '/demo';
  
  // // 3级菜单路径
  // static const COMPONENTS = '/components';
  // static const COMPONENTS_BASIC = '/components/basic';
  // static const COMPONENTS_BASIC_BUTTON = '/components/basic/button';
  // static const COMPONENTS_BASIC_TAG = '/components/basic/tag';
  // static const COMPONENTS_BASIC_DOT = '/components/basic/dot';
  // static const COMPONENTS_LAYOUT = '/components/layout';
  // static const COMPONENTS_LAYOUT_SPACE = '/components/layout/space';
  // static const COMPONENTS_LAYOUT_ICONBOX = '/components/layout/iconbox';
  // static const COMPONENTS_INTERACTIVE = '/components/interactive';
  // static const COMPONENTS_INTERACTIVE_SELECTOR = '/components/interactive/selector';
  // static const COMPONENTS_INTERACTIVE_PAGINATION = '/components/interactive/pagination';
  // static const COMPONENTS_INTERACTIVE_POPUP = '/components/interactive/popup';
  // static const FEATURES = '/features';
  // static const FEATURES_API = '/features/api';
  // static const FEATURES_MODAL = '/features/modal';
}
