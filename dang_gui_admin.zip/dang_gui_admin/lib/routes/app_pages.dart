import 'package:dang_gui_admin/demo/pages/demo_page.dart';
import 'package:dang_gui_admin/layout/layout_demo_widget.dart';
import 'package:get/get.dart';
import 'package:dang_gui_admin/modules/auth/login_view.dart';
import 'package:dang_gui_admin/layout/example/layout_example.dart';
import 'package:dang_gui_admin/layout/layout.dart';
import 'package:dang_gui_admin/modules/funasr/bingding.dart';
import 'package:dang_gui_admin/modules/funasr/realtime_page.dart';
import 'package:dang_gui_admin/modules/home2/binding.dart';
import 'package:dang_gui_admin/modules/home2/home_view.dart';
import 'package:dang_gui_admin/modules/realtime/bingding.dart';
import 'package:dang_gui_admin/modules/realtime/realtime_page.dart';
import '../modules/auth/binding.dart';
import '../modules/dashboard/binding.dart';
import '../modules/dashboard/dashboard.dart';
import '../modules/home/binding.dart';
import '../modules/home/home_view.dart';
import '../modules/launching/binding.dart';
import '../modules/launching/launching_view.dart';
import '../modules/recording/bingding.dart';
import '../modules/recording/recording_page.dart';
import '../modules/second/bindings/second_binding.dart';
import '../modules/second/views/second_view.dart';
import '../modules/theme_settings/bindings/theme_settings_binding.dart';
import '../modules/theme_settings/views/theme_settings_view.dart';
import '../modules/three/bindings/three_binding.dart';
import '../modules/three/views/three_view.dart';

part 'app_routes.dart';

class AppPages {
  AppPages._();
  
  static final routes = [
    // 全屏路由（覆盖整个屏幕）
    // GetPage(name: _Paths.INITIAL, page: () => const LaunchingView(), binding: LaunchingBinding()),
    GetPage(name: _Paths.AUTH, page: () => const LoginView(), binding: LoginBinding()),
    
    // 统一的主布局路由 - 支持所有子路由，URL 会正确更新
    // 这个路由会匹配 /dashboard 和 /dashboard/xxx 等所有布局路由
    GetPage(name: '/', page: () => const LayoutDemoWidget(), binding: LayoutBinding()),
    GetPage(name: '/:routePath*', page: () => const LayoutDemoWidget(), binding: LayoutBinding()),
    
    // 以下路由都应该在布局内显示，不单独配置 GetPage
    // 它们的内容会在 AppMain 组件中根据路由路径动态显示
    // GetPage(name: _Paths.DASHBOARD, page: () => const DashboardView(), binding: DashboardBinding()),
    // GetPage(name: _Paths.HOME, page: () => const HomeView(), binding: HomeBinding()),
    // GetPage(name: _Paths.SECOND, page: () => const SecondView(), binding: SecondBinding()),
    // GetPage(name: _Paths.FUNASR, page: () => const FunasrPage(), binding: FunasrBinding()),
    // GetPage(name: _Paths.DEMO, page: () => const DemoPage()),
    
    // 如果需要特殊的全屏页面，可以单独配置：
    // GetPage(name: _Paths.SPECIAL_FULLSCREEN, page: () => const SpecialPage()),
  ];
}
