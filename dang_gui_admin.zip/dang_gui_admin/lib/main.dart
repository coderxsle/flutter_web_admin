
import 'package:dang_gui_admin/modules/launching/launching_view_native.dart';

import 'app_launching.dart';
import 'package:get/get.dart';
import 'routes/app_pages.dart';
import 'theme/theme_controller.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'bindings/initial_binding.dart';
import 'package:flutter/foundation.dart';
import 'middlewares/launch_middleware.dart';
import 'package:dang_gui_admin/config/app_config.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 移动端/桌面端设置系统 UI；Web 不支持，需跳过
  if (!kIsWeb) {
    // 设置全屏模式（隐藏状态栏和导航栏）
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent, // 状态栏透明
        statusBarIconBrightness: Brightness.light, // 状态栏图标亮色
        systemNavigationBarColor: Colors.transparent, // 导航栏透明
        systemNavigationBarIconBrightness: Brightness.light, // 导航栏图标亮色
      ),
    );
    
    // 设置全屏模式（可选择隐藏状态栏和导航栏）
    await SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.edgeToEdge, // 边到边全屏，状态栏和导航栏半透明
      // 如果想完全隐藏状态栏和导航栏，可以使用：
      // SystemUiMode.immersiveSticky,
    );
  }
  
  await AppLaunching.launching();
  
  // 初始化依赖
  InitialBinding().dependencies();
  
  runApp(const MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return GetBuilder<ThemeController>(
      builder: (controller) {
        return GetMaterialApp(
          title: appName,
          theme: controller.themeData,
          getPages: AppPages.routes,
          initialRoute: "/",
          debugShowCheckedModeBanner: false,
          defaultTransition: Transition.zoom,
          transitionDuration: const Duration(milliseconds: 100),
          builder: FlutterSmartDialog.init(),
          navigatorObservers: [FlutterSmartDialog.observer],
          routingCallback: (routing) {
            final middleware = LaunchMiddleware();
            final redirect = middleware.redirect(routing?.current);
            if (redirect != null) {
              Future.microtask(() {
                Get.offAllNamed(redirect.name!);
              });
            }
          },
        );
      },
    );
  }
}