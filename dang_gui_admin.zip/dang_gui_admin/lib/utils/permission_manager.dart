import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

/// 权限回调函数类型定义
typedef PermissionCallback = void Function(bool granted);

/// 权限管理器
/// 统一处理应用所需的各种权限请求和检查
class PermissionManager {
  /// 检查权限状态
  static Future<PermissionStatus> _checkPermissionStatus(Permission permission) async {
    return await permission.status;
  }

  /// 请求权限
  static Future<bool> _requestPermission(Permission permission) async {
    return await permission.request().isGranted;
  }

  /// 检查并请求权限
  /// [context] - BuildContext用于显示对话框
  /// [permission] - 需要请求的权限
  /// [permissionName] - 权限的中文名称
  /// [onResult] - 权限请求结果的回调函数
  static Future<void> checkAndRequestPermission({
    required BuildContext context,
    required Permission permission,
    required String permissionName,
    required PermissionCallback onResult,
  }) async {
    // 获取当前权限状态
    final status = await _checkPermissionStatus(permission);

    // 如果已经授权，直接返回
    if (status.isGranted) {
      onResult(true);
      return;
    }

    // 如果权限被永久拒绝
    if (status.isPermanentlyDenied) {
      final bool? openSettings = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('需要权限'),
          content: Text('需要$permissionName权限才能继续。\n请在设置中开启权限。'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('取消'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('去设置'),
            ),
          ],
        ),
      );

      if (openSettings == true) {
        await openAppSettings();
        // 等待用户从设置页面返回后重新检查权限
        final newStatus = await _checkPermissionStatus(permission);
        onResult(newStatus.isGranted);
        return;
      }
      onResult(false);
      return;
    }

    // 先请求权限
    final granted = await _requestPermission(permission);
    if (!granted && context.mounted) {
      // 如果用户拒绝权限，显示说明对话框并提供重试选项
      final bool? retry = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('需要权限'),
          content: Text('需要$permissionName权限才能继续使用该功能。'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('暂不授权'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(
                foregroundColor: Theme.of(context).primaryColor,
              ),
              child: const Text('授权'),
            ),
          ],
        ),
      );

      if (retry == true && context.mounted) {
        // 用户选择重试，递归调用本方法
        await checkAndRequestPermission(
          context: context,
          permission: permission,
          permissionName: permissionName,
          onResult: onResult,
        );
        return;
      }
    }
    onResult(granted);
  }

  /// 检查麦克风权限
  static Future<void> microphone(
    BuildContext context,
    {PermissionCallback? onResult}
  ) async {
    await checkAndRequestPermission(
      context: context,
      permission: Permission.microphone,
      permissionName: '麦克风',
      onResult: onResult ?? (granted) {},
    );
  }

  /// 检查存储权限
  static Future<void> storage({
    required BuildContext context,
    required PermissionCallback onResult,
  }) async {
    await checkAndRequestPermission(
      context: context,
      permission: Permission.storage,
      permissionName: '存储',
      onResult: onResult,
    );
  }

  /// 检查定位权限（使用时定位）
  static Future<void> location({
    required BuildContext context,
    required PermissionCallback onResult,
  }) async {
    await checkAndRequestPermission(
      context: context,
      permission: Permission.locationWhenInUse,
      permissionName: '定位',
      onResult: onResult,
    );
  }

  /// 检查定位权限（始终定位）
  static Future<void> locationAlways({
    required BuildContext context,
    required PermissionCallback onResult,
  }) async {
    await checkAndRequestPermission(
      context: context,
      permission: Permission.locationAlways,
      permissionName: '后台定位',
      onResult: onResult,
    );
  }

  /// 一次性检查多个权限（录音+定位）
  static Future<void> recordingWithLocation({
    required BuildContext context,
    required Function(bool micGranted, bool locationGranted) onResult,
  }) async {
    bool micGranted = false;
    bool locationGranted = false;

    // 先请求麦克风权限
    await microphone(context, onResult: (granted) {
      micGranted = granted;
    });

    // 如果麦克风权限获得，再请求定位权限
    if (micGranted) {
      await location(
        context: context,
        onResult: (granted) {
          locationGranted = granted;
        },
      );
    }

    onResult(micGranted, locationGranted);
  }
} 