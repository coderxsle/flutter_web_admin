import 'dart:io';
import 'package:dang_gui_admin/logger.dart';


class AudioUtils {
  
  /// 检查音频文件属性
  static Future<void> logProperties(String filePath) async {
    try {
      final file = File(filePath);
      final fileSize = await file.length();
      final durationInSeconds = fileSize / (16000 * 2); // 16000Hz * 2字节(16bit)
      
      logger.i('音频文件属性:');
      logger.i('文件路径: $filePath');
      logger.i('文件大小: $fileSize 字节');
      logger.i('采样率: 16000Hz');
      logger.i('声道数: 1');
      logger.i('编码格式: PCM 16bit');
      logger.i('预计时长: ${durationInSeconds.toStringAsFixed(2)}秒');
      logger.i('比特率: ${(fileSize * 8 / durationInSeconds).round()}bps');
    } catch (e) {
      logger.e('检查音频文件属性时出错: $e');
    }
  }

}