
import 'package:flutter/material.dart';


// 页面底部添加一个长按钮
Widget pageBottomButton({required String title, bool topLine = true, required VoidCallback onPressed}) {
  return Container(
    height: 80,
    margin: const EdgeInsets.fromLTRB(0, 0, 0, 0),
    child: Column(children: [
      if (topLine) const Divider(thickness: 0.5),
      Padding(
        padding: const EdgeInsets.fromLTRB(30, 0, 30, 0),
        child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(22),
              ),
            ),
            onPressed: onPressed,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title, style: TextStyle(color: Colors.white)),
              ],
            )
            // child: Text(title, style: whiteStyle()),·
            ),
      ),
    ]),
  );
}
