import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'controller.dart';

class FunasrPage extends GetView<FunasrController> {
  const FunasrPage({super.key});

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) async {
        if (!didPop) {
          await _handleBackPressed();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            '盛邦会议记录',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          elevation: 0,
          shadowColor: Colors.black54,
          surfaceTintColor: Colors.transparent,
          leading: IconButton(
            onPressed: () async {
              await _handleBackPressed();
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Color(0xFFFFFFFF),
              size: 20,
            ),
          ),
        ),
        body: Column(
          children: [
            // 录音状态和时长显示区域
            buildRecordingStatusCard(),
            
            // 转写文本显示区域
            Expanded(
              child: buildTranscriptionArea(),
            ),
          ],
        ),
        bottomNavigationBar: buildRecordingButton(),
      ),
    );
  }

  /// 构建录音状态卡片
  Widget buildRecordingStatusCard() {
    return Container(
      margin: const EdgeInsets.all(10),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 24),
      decoration: BoxDecoration(
        color: Theme.of(Get.context!).cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // 录音状态指示器
          GetBuilder<FunasrController>(
            id: 'isRealtimeTranscribing',
            builder: (_) {
              return Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: controller.isRealtimeTranscribing 
                      ? const Color.fromARGB(255, 207, 2, 19) 
                      : Theme.of(Get.context!).disabledColor,
                  shape: BoxShape.circle,
                ),
                child: controller.isRealtimeTranscribing
                    ? const _PulsingWidget()
                    : null,
              );
            },
          ),
          
          const SizedBox(width: 8),
          
          // 状态文字
          GetBuilder<FunasrController>(
            id: 'isRealtimeTranscribing',
            builder: (_) {
              return Text(
                controller.isRealtimeTranscribing ? '盛邦议录识别中...' : '等待识别',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Theme.of(Get.context!).textTheme.bodyLarge?.color,
                ),
              );
            },
          ),
          
          const Spacer(),
          
          // 录音时长
          GetBuilder<FunasrController>(
            id: 'recordingDuration',
            builder: (_) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Theme.of(Get.context!).colorScheme.surface,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  controller.formattedDuration,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Color.fromARGB(255, 2, 199, 28), // 保持绿色显示时长
                    fontFeatures: [FontFeature.tabularFigures()],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  /// 构建转写文本显示区域
  Widget buildTranscriptionArea() {
    return Container(
      margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
      decoration: BoxDecoration(
        color: Theme.of(Get.context!).cardColor,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题栏
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: Theme.of(Get.context!).dividerColor.withOpacity(0.5),
                  width: 0.5,
                ),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Theme.of(Get.context!).primaryColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.article_outlined,
                    color: Theme.of(Get.context!).primaryColor,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  '识别结果',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Theme.of(Get.context!).textTheme.bodyLarge?.color,
                  ),
                ),
                const Spacer(),
                // 说话人区分按钮
                GestureDetector(
                  onTap: controller.showSpeakerIdentificationDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Theme.of(Get.context!).colorScheme.secondary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: Theme.of(Get.context!).colorScheme.secondary.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.people_alt_outlined,
                          size: 16,
                          color: Theme.of(Get.context!).colorScheme.secondary,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '区分说话人',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: Theme.of(Get.context!).colorScheme.secondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // 文本内容区域
          Expanded(
            child: GetBuilder<FunasrController>(
              id: 'transcriptionText',
              builder: (_) {
                return SingleChildScrollView(
                  controller: controller.scrollController,
                  padding: const EdgeInsets.all(20),
                  child: controller.transcriptionText.isEmpty
                      ? buildEmptyState()
                      : buildTranscriptionText(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  /// 构建空状态
  Widget buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Theme.of(Get.context!).colorScheme.surface,
              borderRadius: BorderRadius.circular(40),
            ),
            child: Icon(
              Icons.mic_none,
              color: Theme.of(Get.context!).disabledColor,
              size: 40,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            '等待开始识别',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Theme.of(Get.context!).textTheme.bodyMedium?.color,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '点击下方按钮开始语音识别',
            style: TextStyle(
              fontSize: 14,
              color: Theme.of(Get.context!).textTheme.bodySmall?.color,
            ),
          ),
        ],
      ),
    );
  }

  /// 构建转写文本
  Widget buildTranscriptionText() {
    return SelectableText(
      controller.transcriptionText,
      style: TextStyle(
        fontSize: 16,
        height: 1.6,
        color: Theme.of(Get.context!).textTheme.bodyLarge?.color,
        letterSpacing: 0.3,
      ),
    );
  }

  /// 构建录音按钮
  Widget buildRecordingButton() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(Get.context!).bottomNavigationBarTheme.backgroundColor ?? Theme.of(Get.context!).scaffoldBackgroundColor,
        border: Border(
          top: BorderSide(
            color: Theme.of(Get.context!).dividerColor.withOpacity(0.5),
            width: 0.5,
          ),
        ),
      ),
      child: GetBuilder<FunasrController>(
        id: 'isRealtimeTranscribing',
        builder: (_) {
          final isRecording = controller.isRealtimeTranscribing;
          
          return Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isRecording
                    ? [const Color(0xFFFF4757), const Color(0xFFFF3742)]
                    : [Theme.of(Get.context!).primaryColor, Theme.of(Get.context!).primaryColor.withOpacity(0.8)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: (isRecording 
                      ? const Color(0xFFFF4757) 
                      : Theme.of(Get.context!).primaryColor
                  ).withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: controller.startRealtimeTranscription,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      isRecording ? Icons.stop_rounded : Icons.mic_rounded,
                      color: Colors.white,
                      size: 24,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      isRecording ? '结束识别' : '开始识别',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  /// 处理返回操作
  Future<bool> _handleBackPressed() async {
    // 如果正在录音，显示确认对话框
    if (controller.isRealtimeTranscribing) {
      final result = await Get.dialog<bool>(
        AlertDialog(
          backgroundColor: Theme.of(Get.context!).dialogBackgroundColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            '确认退出',
            style: TextStyle(
              color: Theme.of(Get.context!).textTheme.titleLarge?.color,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          content: Text(
            '当前正在进行语音识别，退出将会中断录音和转写。\n\n确定要退出吗？',
            style: TextStyle(
              color: Theme.of(Get.context!).textTheme.bodyMedium?.color,
              fontSize: 16,
              height: 1.5,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(result: false),
              child: Text(
                '取消',
                style: TextStyle(
                  color: Theme.of(Get.context!).primaryColor,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            TextButton(
              onPressed: () async {
                controller.startRealtimeTranscription();
                Get.back(result: true);
              },
              child: const Text(
                '停止并退出',
                style: TextStyle(
                  color: Color(0xFFFF4757), // 保持红色表示危险操作
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        barrierDismissible: false,
      );
      
      if (result == true) {
        Get.back();
        return true;
      }
      return false;
    } else {
      // 未录音时直接显示简单确认
      final result = await Get.dialog<bool>(
        AlertDialog(
          backgroundColor: Theme.of(Get.context!).dialogBackgroundColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            '确认退出',
            style: TextStyle(
              color: Theme.of(Get.context!).textTheme.titleLarge?.color,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          content: Text(
            '确定要退出语音识别页面吗？',
            style: TextStyle(
              color: Theme.of(Get.context!).textTheme.bodyMedium?.color,
              fontSize: 16,
              height: 1.5,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Get.back(result: false),
              child: Text(
                '取消',
                style: TextStyle(
                  color: Theme.of(Get.context!).primaryColor,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            TextButton(
              onPressed: () => Get.back(result: true),
              child: const Text(
                '确定',
                style: TextStyle(
                  color: Color(0xFFFF4757), // 保持红色表示确认退出
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        barrierDismissible: false,
      );
      
      if (result == true) {
        Get.back();
        return true;
      }
      return false;
    }
  }

}

/// 脉冲动画组件
class _PulsingWidget extends StatefulWidget {
  const _PulsingWidget();

  @override
  State<_PulsingWidget> createState() => _PulsingWidgetState();
}

class _PulsingWidgetState extends State<_PulsingWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    _animationController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(_animation.value * 0.8),
            shape: BoxShape.circle,
          ),
        );
      },
    );
  }
}
