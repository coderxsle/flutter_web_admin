import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:collection';
import 'package:crypto/crypto.dart';
import 'package:dang_gui_admin/logger.dart';
import 'package:dang_gui_admin/api/websocket_manager.dart';

/// 讯飞实时语音转写服务
class XunfeiRealtimeService {
  static const String _appId = 'a85ec85f';
  static const String _apiKey = '0a775c1c9965b467fa43f1c84c01ae70';
  // static const String _appId = '1ac578af';
  // static const String _apiKey = 'df6727bc1c2e41eab722fe23d1e17fe5';
  static const String _baseUrl = 'wss://rtasr.xfyun.cn/v1/ws';
  
  // 配置常量
  static const int _maxQueueSize = 1000;       // 最大队列长度
  static const int _sendIntervalMs = 40;      // 发送间隔（毫秒）
  static const int _chunkSize = 1280;          // 每次发送的数据大小（字节）
  
  late final WebSocketManager _channel;
  final _resultController = StreamController<String>.broadcast();
  
  Stream<String> get resultStream => _resultController.stream;
  bool get isConnected => _channel.isConnected;

  int _totalFramesSent = 0;
  int _totalBytesSent = 0;
  final _audioDataQueue = Queue<Uint8List>();
  Timer? _sendTimer;

  XunfeiRealtimeService() {
    _channel = WebSocketManager(
      onConnectionStatusChanged: _handleConnectionStatus,
      onMessageReceived: _message,
      onError: _error,
    );
  }


  /// 生成讯飞服务签名
  static String generateSignature(String appId, String apiKey, int timestamp) {
    // 1. 获取 baseString: appid + ts
    final baseString = '$appId$timestamp';
    logger.d('第1步 - baseString: $baseString');

    // 2. 对 baseString 进行 MD5
    final md5String = md5.convert(utf8.encode(baseString)).toString();
    logger.d('第2步 - MD5后: $md5String');

    // 3. 以 apiKey 为 key 对 MD5 后的结果进行 HmacSHA1 加密，然后 base64 编码
    final hmacSha1 = Hmac(sha1, utf8.encode(apiKey));
    final digest = hmacSha1.convert(utf8.encode(md5String));
    final signa = base64.encode(digest.bytes);
    logger.d('第3步 - 最终签名: $signa');
    return signa;
  }


  /// 处理连接状态变化
  void _handleConnectionStatus(bool isConnected) {
    // logger.i('WebSocket连接状态: ${isConnected ? '已连接' : '已断开'}');
  }

  /// 处理收到的消息
  void _message(String message) {
    try {
      final response = json.decode(message);
      
      final action = response['action'];
      final code = response['code'];
      
      if (code == '0') {
        switch (action) {
          case 'started':
            logger.i('转写服务启动成功，sid: ${response['sid']}');
            break;
          case 'result':
            final result = response['data'] ?? '';
            if (result.isNotEmpty) {
              logger.i('收到WebSocket消息，解析到转写结果: $result');
              final transcription = parseTranscription(result);
              _resultController.add(transcription);
            }
            break;
          default:
            logger.d('收到未知action: $action, 消息: $message');
        }
      } else {
        logger.w('服务端返回错误: $code, 消息: ${response['message']}');
      }
    } catch (e, stack) {
      logger.e('解析消息失败', error: e, stackTrace: stack);
    }
  }


  /// 解析单段JSON转写数据
  String parseTranscription(String jsonString) {
    try {
      // 解析JSON数据
      final Map<String, dynamic> parsedJson = jsonDecode(jsonString);

      // 获取转写结果中的 `rt` 列表
      final List<dynamic> rtList = parsedJson['cn']['st']['rt'];

      // 提取所有的 `cw.w` 并拼接成完整文本
      final StringBuffer transcription = StringBuffer();
      for (final rtItem in rtList) {
        final List<dynamic> wsList = rtItem['ws'];
        for (final wsItem in wsList) {
          final List<dynamic> cwList = wsItem['cw'];
          for (final cwItem in cwList) {
            transcription.write(cwItem['w']);
          }
        }
      }

      return transcription.toString(); // 返回完整转写文本
    } catch (e) {
      return '解析失败：$e';
    }
  }

  /// 处理错误
  void _error(dynamic error) {
    logger.e('WebSocket错误: $error');
  }

  /// 建立连接
  Future<bool> connect({Map<String, String>? additionalParams}) async {
    final ts = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final signa = generateSignature(_appId, _apiKey, ts);
    
    final wsUrl = '$_baseUrl?appid=${Uri.encodeComponent(_appId)}'
        '&ts=${Uri.encodeComponent(ts.toString())}'
        '&signa=${Uri.encodeComponent(signa)}';
    
    return await _channel.connect(wsUrl);
  }

  /// 发送音频数据
  Future<void> sendAudioData(Uint8List audioData) async {
    if (!isConnected) {
      logger.w('WebSocket未连接，无法发送数据');
      return;
    }

    // 检查队列大小
    if (_audioDataQueue.length >= _maxQueueSize) {
      logger.w('队列已满，丢弃旧数据');
      _audioDataQueue.removeFirst();
    }

    // 将数据转换为 Uint8List 并加入队列
    final uint8Data = Uint8List.fromList(audioData);
    _audioDataQueue.add(uint8Data);
    
    // 如果定时器未启动，则启动定时器
    _sendTimer ??= Timer.periodic(const Duration(milliseconds: _sendIntervalMs), (timer) {
      if (_audioDataQueue.isNotEmpty) {
        _sendQueuedData();
      }
    });
  }

  /// 发送队列中的数据
  void _sendQueuedData() {
    if (_audioDataQueue.isEmpty) return;

    try {
      // 从队列中获取数据
      var audioData = _audioDataQueue.removeFirst();
      
      // 如果数据大小超过指定大小，只发送指定大小的数据，剩余部分重新入队
      if (audioData.length > _chunkSize) {
        var remainingData = Uint8List.fromList(audioData.sublist(_chunkSize));
        audioData = Uint8List.fromList(audioData.sublist(0, _chunkSize));
        _audioDataQueue.addFirst(remainingData);
      }
      // 如果数据大小小于指定大小，等待更多数据累积
      else if (audioData.length < _chunkSize && _audioDataQueue.isNotEmpty) {
        var nextData = _audioDataQueue.removeFirst();
        var combinedData = Uint8List(audioData.length + nextData.length);
        combinedData.setAll(0, audioData);
        combinedData.setAll(audioData.length, nextData);
        
        if (combinedData.length > _chunkSize) {
          var remainingData = Uint8List.fromList(combinedData.sublist(_chunkSize));
          audioData = Uint8List.fromList(combinedData.sublist(0, _chunkSize));
          _audioDataQueue.addFirst(remainingData);
        } else {
          audioData = combinedData;
        }
      }

      // final data = {
      //   'data': {
      //     'status': 1,
      //     'format': 'audio/L16;rate=16000',
      //     'encoding': 'pcm',
      //     'audio': audioData,
      //   }
      // };
      
      // _channel.send(json.encode(data));
      _channel.send(audioData);

      _totalFramesSent++;
      _totalBytesSent += audioData.length;
      
      logger.d('【第 $_totalFramesSent 帧】发送音频数据，大小: ${audioData.length} 字节，累计: $_totalBytesSent 字节');
      
    } catch (e, stack) {
      logger.e('发送音频数据失败', error: e, stackTrace: stack);
    }
  }

  /// 发送结束标识
  Future<void> sendEndSignal() async {
    logger.i('准备发送结束标识，等待队列中的数据发送完成...');
    
    // 先取消定时器
    _sendTimer?.cancel();
    _sendTimer = null;

    // 清空队列中的剩余数据
    try {
      int remainingFrames = _audioDataQueue.length;
      logger.i('剩余 $remainingFrames 帧数据待发送');
      
      while (_audioDataQueue.isNotEmpty) {
        if (!isConnected) {
          logger.w('WebSocket连接已断开，停止发送数据');
          break;
        }

        await Future.delayed(const Duration(milliseconds: _sendIntervalMs));
        _sendQueuedData();
        
        // 检查进度
        final currentRemaining = _audioDataQueue.length;
        if (currentRemaining == remainingFrames) {
          logger.w('数据发送停滞，强制结束发送');
          break;
        }
        remainingFrames = currentRemaining;
      }

      // 如果还有剩余数据，记录日志并清空队列
      if (_audioDataQueue.isNotEmpty) {
        logger.w('清空剩余 ${_audioDataQueue.length} 帧未发送数据');
        _audioDataQueue.clear();
      }

      if (!isConnected) {
        logger.w('WebSocket未连接，无法发送结束标识');
        return;
      }

      logger.i('所有数据发送完成，发送结束标识');
      logger.i('共发送 $_totalFramesSent 帧数据，总计 $_totalBytesSent 字节');
      
      // 发送结束标识
      final endSignal = json.encode({"end": true});
      await _channel.send(endSignal);
      
      // 等待服务器处理完最后的数据
      await Future.delayed(const Duration(seconds: 2));
      
      // 清理状态
      _totalFramesSent = 0;
      _totalBytesSent = 0;
      _audioDataQueue.clear();
      
      // 主动断开连接
      disconnect();

    } catch (e, stack) {
      logger.e('发送结束标识失败', error: e, stackTrace: stack);
      disconnect();  // 确保连接被关闭
    }
  }

  /// 关闭连接
  void disconnect() {
    _sendTimer?.cancel();
    _sendTimer = null;
    _audioDataQueue.clear();
    _channel.disconnect();
  }

  /// 释放资源
  void dispose() {
    _sendTimer?.cancel();
    _sendTimer = null;
    _audioDataQueue.clear();
    logger.i('正在释放实时转写服务资源');
    _channel.dispose();
    _resultController.close();
    logger.i('实时转写服务资源已释放');
  }
} 