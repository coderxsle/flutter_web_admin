import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'controller.dart';

class RecordingPage extends GetView<RecordingController> {
  const RecordingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        title: const Text(
          '实时语音转写',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Color(0xFFFFFFFF),
          ),
        ),
        backgroundColor: const Color(0xFF1C1C1E),
        elevation: 0,
        shadowColor: Colors.black54,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          onPressed: () => Get.back(),
          icon: const Icon(
            Icons.arrow_back_ios,
            color: Color(0xFFFFFFFF),
            size: 20,
          ),
        ),
      ),
      body: Column(
        children: [
          // 录音状态和时长显示区域
          buildRecordingStatusCard(),
          
          // 转写文本显示区域
          Expanded(
            child: buildTranscriptionArea(),
          ),
        ],
      ),
      bottomNavigationBar: buildRecordingButton(),
    );
  }

  /// 构建录音状态卡片
  Widget buildRecordingStatusCard() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
      decoration: BoxDecoration(
        color: const Color(0xFF1C1C1E),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // 录音状态指示器
          GetBuilder<RecordingController>(
            id: 'isRealtimeTranscribing',
            builder: (_) {
              return Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: controller.isRealtimeTranscribing 
                      ? const Color(0xFFFF4757) 
                      : const Color(0xFF8E8E93),
                  shape: BoxShape.circle,
                ),
                child: controller.isRealtimeTranscribing
                    ? const _PulsingWidget()
                    : null,
              );
            },
          ),
          
          const SizedBox(width: 12),
          
          // 状态文字
          GetBuilder<RecordingController>(
            id: 'isRealtimeTranscribing',
            builder: (_) {
              return Text(
                controller.isRealtimeTranscribing ? '正在录音' : '等待录音',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFFFFFFFF),
                ),
              );
            },
          ),
          
          const Spacer(),
          
          // 录音时长
          GetBuilder<RecordingController>(
            id: 'recordingDuration',
            builder: (_) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFF2C2C2E),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  controller.formattedDuration,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF00D4AA),
                    fontFeatures: [FontFeature.tabularFigures()],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  /// 构建转写文本显示区域
  Widget buildTranscriptionArea() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      decoration: BoxDecoration(
        color: const Color(0xFF1C1C1E),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 标题栏
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: Color(0xFF2C2C2E),
                  width: 1,
                ),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF007AFF).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.article_outlined,
                    color: Color(0xFF007AFF),
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                const Text(
                  '转写结果',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFFFFFFFF),
                  ),
                ),
                const Spacer(),
                // 说话人区分按钮
                GestureDetector(
                  onTap: controller.showSpeakerIdentificationDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFF007AFF).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFF007AFF).withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.people_alt_outlined,
                          size: 16,
                          color: Color(0xFF007AFF),
                        ),
                        SizedBox(width: 4),
                        Text(
                          '区分说话人',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF007AFF),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          // 文本内容区域
          Expanded(
            child: GetBuilder<RecordingController>(
              id: 'transcriptionText',
              builder: (_) {
                return SingleChildScrollView(
                  controller: controller.scrollController,
                  padding: const EdgeInsets.all(20),
                  child: controller.transcriptionText.isEmpty
                      ? buildEmptyState()
                      : buildTranscriptionText(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  /// 构建空状态
  Widget buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: const Color(0xFF2C2C2E),
              borderRadius: BorderRadius.circular(40),
            ),
            child: const Icon(
              Icons.mic_none,
              color: Color(0xFF8E8E93),
              size: 40,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            '等待录音开始',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Color(0xFFAAAAAA),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            '点击下方按钮开始语音转写',
            style: TextStyle(
              fontSize: 14,
              color: Color(0xFF666666),
            ),
          ),
        ],
      ),
    );
  }

  /// 构建转写文本
  Widget buildTranscriptionText() {
    return SelectableText(
      controller.transcriptionText,
      style: const TextStyle(
        fontSize: 16,
        height: 1.6,
        color: Color(0xFFFFFFFF),
        letterSpacing: 0.3,
      ),
    );
  }

  /// 构建录音按钮
  Widget buildRecordingButton() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Color(0xFF1C1C1E),
        border: Border(
          top: BorderSide(
            color: Color(0xFF2C2C2E),
            width: 1,
          ),
        ),
      ),
      child: GetBuilder<RecordingController>(
        id: 'isRealtimeTranscribing',
        builder: (_) {
          final isRecording = controller.isRealtimeTranscribing;
          
          return Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isRecording
                    ? [const Color(0xFFFF4757), const Color(0xFFFF3742)]
                    : [const Color(0xFF007AFF), const Color(0xFF0056CC)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: (isRecording 
                      ? const Color(0xFFFF4757) 
                      : const Color(0xFF007AFF)
                  ).withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: controller.startRealtimeTranscription,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      isRecording ? Icons.stop_rounded : Icons.mic_rounded,
                      color: Colors.white,
                      size: 24,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      isRecording ? '结束转写' : '开始转写',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// 脉冲动画组件
class _PulsingWidget extends StatefulWidget {
  const _PulsingWidget();

  @override
  State<_PulsingWidget> createState() => _PulsingWidgetState();
}

class _PulsingWidgetState extends State<_PulsingWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _animation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    _animationController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        return Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(_animation.value * 0.8),
            shape: BoxShape.circle,
          ),
        );
      },
    );
  }
}
