
import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:record/record.dart';
import 'package:dang_gui_admin/logger.dart';
import 'package:dang_gui_admin/services/recorder_service.dart';

import 'xunfei_realtime_service.dart';


class RecordingController extends GetxController {

  // 录音机服务
  late final RecorderService _recorderService;
  
  // 讯飞实时转写服务
  late final XunfeiRealtimeService _realtimeService;

  // 滚动控制器，用于自动滚动到底部
  ScrollController? scrollController;

  // 录音时长计时器
  Timer? _recordingTimer;
  int _recordingDuration = 0; // 录音时长（秒）
  
  int get recordingDuration => _recordingDuration;
  set recordingDuration(int value) {
    if (_recordingDuration != value) {
      _recordingDuration = value;
      update(['recordingDuration']);
    }
  }

  // 格式化录音时长为 MM:SS 格式
  String get formattedDuration {
    final minutes = (_recordingDuration ~/ 60).toString().padLeft(2, '0');
    final seconds = (_recordingDuration % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }
  
  // 实时转写状态
  bool _isRealtimeTranscribing = false;
  bool get isRealtimeTranscribing => _isRealtimeTranscribing;
  set isRealtimeTranscribing(bool value) {
    if (_isRealtimeTranscribing != value) {
      _isRealtimeTranscribing = value;
      update(['isRealtimeTranscribing']);
    }
  }

  // 实时转写转写文本
  String _transcriptionText = '';
  String get transcriptionText => _transcriptionText;
  set transcriptionText(String value) {
    if (_transcriptionText != value) {
      _transcriptionText = value;
      update(['transcriptionText']);
      // 文本更新后自动滚动到底部
      _scrollToBottom();
    }
  }

  // 自动滚动到底部
  void _scrollToBottom() {
    if (scrollController != null && scrollController!.hasClients) {
      // 延迟一点时间确保UI已更新
      WidgetsBinding.instance.addPostFrameCallback((_) {
        scrollController!.animateTo(
          scrollController!.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      });
    }
  }



  @override
  void onInit() {
    super.onInit();
    _recorderService = RecorderService();
    _realtimeService = XunfeiRealtimeService();

    // ScrollController 用于控制滚动
    scrollController = ScrollController();
  }

  @override
  void onClose() {
    _recordingTimer?.cancel();
    scrollController = null;
    _realtimeService.dispose();
    _recorderService.dispose();
    super.onClose();
  }

  // 开始录音计时
  void _startRecordingTimer() {
    recordingDuration = 0;
    _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      recordingDuration = recordingDuration + 1;
    });
  }

  // 停止录音计时
  void _stopRecordingTimer() {
    _recordingTimer?.cancel();
    _recordingTimer = null;
  }



  // 开始实时语音转写
  // 实时转写需要录音，所以需要先检查录音权限
  // 如果已经在录音，则停止录音和转写
  // 如果未录音，则开始录音并获取音频流
  // 然后开始实时转写
  Future<void> startRealtimeTranscription() async {
    if (isRealtimeTranscribing) {
      isRealtimeTranscribing = false;

      // 停止录音计时
      _stopRecordingTimer();

      // 停止录音和转写
      final recordingPath = await _recorderService.stopRecording();
      if (recordingPath != null) {
        logger.i('录音文件已保存到: $recordingPath');
        
        // 保存转写文本
        final transcriptionFile = File('${recordingPath.replaceAll('.pcm', '')}_transcription.txt');
        await transcriptionFile.writeAsString(transcriptionText);
        logger.i('转写文本已保存到: ${transcriptionFile.path}');
      }
      
      await _realtimeService.sendEndSignal();
      _realtimeService.disconnect();
      return;
    }

    isRealtimeTranscribing = true;
    transcriptionText = '';

    try {
      // 开始录音计时
      _startRecordingTimer();

      // 配置录音参数
      const config = RecordConfig(
        encoder: AudioEncoder.pcm16bits,  // PCM 16bit
        sampleRate: 16000,               // 16kHz 采样率
        numChannels: 1,                  // 单声道
      );
      
      // 开始录音并获取音频流
      _recorderService.startRecording(config, (stream) {
        _listenAudioStream(stream);
      });

      // 订阅转写结果
      _listenTranscriptionResult();

      // 开始实时转写
      final connected = await _realtimeService.connect();
      if (!connected) throw '实时转写服务连接失败';
      
    } catch (e) {
      logger.e('实时转写出错', error: e);
      await _recorderService.stopRecording();
      _realtimeService.disconnect();
      transcriptionText = '实时转写出错: $e';
      isRealtimeTranscribing = false;
    }
  }


  // 订阅录音机开始录音的音频流
  // 开始录音后，需要订阅录音机开始录音的音频流，并发送给实时转写服务
  void _listenAudioStream(Stream<Uint8List> stream) {
    logger.i('开始订阅音频流');
    stream.listen((data) async {
        if (isRealtimeTranscribing) {
          try {
            await _realtimeService.sendAudioData(Uint8List.fromList(data));
          } catch (e) {
            logger.e('发送音频数据失败', error: e);
            isRealtimeTranscribing = false;
          }
        }
      },
      onError: (error) {
        logger.e('音频流错误', error: error);
        isRealtimeTranscribing = false;
      },
      onDone: () {
        logger.i('音频流结束');
        isRealtimeTranscribing = false;
      },
    );
  }



  // 订阅转写结果
  void _listenTranscriptionResult() {
    _realtimeService.resultStream.listen((result) {
        transcriptionText += result;
      },
      onError: (error) {
        logger.e('转写出错', error: error);
        transcriptionText = '转写出错: $error';
        isRealtimeTranscribing = false;
      },
    );
  }

  /// 显示说话人区分功能提示弹窗
  void showSpeakerIdentificationDialog() {
    Get.dialog(
      AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.people_alt_outlined,
              color: Theme.of(Get.context!).primaryColor,
              size: 24,
            ),
            const SizedBox(width: 12),
            const Text(
              '区分说话人',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '受当前服务器性能，和算法架构的限制，暂不支持实时区分说话人。',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Color.fromARGB(255, 224, 18, 4),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '说话人识别需要分析完整音频中的声纹特征进行聚类分析，因此需要在录音结束后进行处理。',
              style: TextStyle(
                fontSize: 14,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              '录音结束后会自动进行说话人区分，并标注到对应文本中。',
              style: TextStyle(
                fontSize: 16,
                height: 1.5,
                color: Colors.green[600],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Get.close(),
            child: Text(
              '我知道了',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        contentPadding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
        actionsPadding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
      ),
    );
  }

}

