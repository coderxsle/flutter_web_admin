import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:dang_gui_admin/config/app_config.dart';
import 'package:dang_gui_admin/routes/app_pages.dart';
import 'package:dang_gui_admin/logger.dart';
import 'package:dang_gui_admin/app_manager.dart';

class LaunchingController extends GetxController with GetSingleTickerProviderStateMixin {
  late final AnimationController animationController;
  late final Animation<double> fadeAnimation;

  var isFontLoaded = false.obs;
  var statusText = "loading...".obs;

  @override
  Future<void> onInit() async {
    super.onInit();
    _initializeAnimations();
    await _loadFonts();
    await _startNavigationTimer();
  }

  void _initializeAnimations() {
    // 初始化动画控制器
    animationController = AnimationController(
      duration: const Duration(milliseconds: animationDuration),
      vsync: this,
    );
    // 创建淡入动画
    fadeAnimation = Tween<double>(begin: 0.0, end: 1).animate(animationController);
    // 开始动画
    animationController.forward();
  }

  Future<void> _loadFonts() async {
    statusText.value = "Loading...";
    try {
      if (kIsWeb) {
        await _loadWebFonts();
      } else {
        await _loadNativeFonts();
      }
      logger.i("字体加载完成");
      isFontLoaded.value = true;
      statusText.value = appNameIntro;
    } catch (e) {
      logger.e("字体加载失败: $e");
      // statusText.value = "字体加载异常，将使用系统默认字体";
      statusText.value = appNameIntro;
      isFontLoaded.value = true;
    }
  }


  // 加载Web字体
  Future<void> _loadWebFonts() async {
    // 等待2秒
    await Future.delayed(const Duration(milliseconds: waitLoadingFontsDuration));
  }

  // 加载本地字体
  Future<void> _loadNativeFonts() async {
    final fontLoader = FontLoader('Noto Sans SC');
    fontLoader.addFont(rootBundle.load('assets/fonts/NotoSansSC-Regular.otf'));
    fontLoader.addFont(rootBundle.load('assets/fonts/NotoSansSC-Medium.otf'));
    fontLoader.addFont(rootBundle.load('assets/fonts/NotoSansSC-Bold.otf'));
    await fontLoader.load();
    await Future.delayed(const Duration(milliseconds: waitLoadingFontsDuration));
  }

  // 启动导航计时器
  Future<void> _startNavigationTimer() async {
    // 等待字体加载完成
    while (!isFontLoaded.value) {
      await Future.delayed(const Duration(milliseconds: 500));
    }
    
    // 等待动画完成
    if (!animationController.isCompleted) {
      await animationController.forward().orCancel.catchError((_) {
        // 处理可能的动画取消错误
        logger.w("动画被取消");
      });
    }
    
    // 额外等待一小段时间，确保视觉效果完整
    await Future.delayed(const Duration(milliseconds: animationIntroWaitDuration));
    
    // 根据登录状态决定导航目标
    _navigateBasedOnAuthStatus();
  }
  
  // 根据登录状态决定导航目标
  void _navigateBasedOnAuthStatus() {
    if (!Get.isRegistered<LaunchingController>()) return;
    
    // 检查用户是否已登录
    if (AppManager.userInfo == null || AppManager.userInfo?.accessToken == null) {
      logger.i("用户未登录，将显示登录页面");
      Get.offAllNamed(Routes.AUTH);
    } else {
      logger.i("启动完成：用户已登录，导航到仪表盘");
      Get.offAllNamed('/'); // 使用具体的路由路径
    }
  }

  @override
  void onClose() {
    animationController.dispose();
    super.onClose();
  }
}