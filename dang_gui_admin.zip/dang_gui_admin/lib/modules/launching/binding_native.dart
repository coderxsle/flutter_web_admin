import 'package:flutter/material.dart';
import 'launching_view_native.dart';

class LaunchingBindingNative {
  static Widget create() {
    return const LaunchingViewNative();
  }
}
