import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../controllers/second_controller.dart';

class SecondView extends GetView<SecondController> {
  const SecondView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('第二页'),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              '这是第二页',
              style: TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Get.toNamed('/three'),
              child: const Text('跳转到第三页'),
            ),
          ],
        ),
      ),
    );
  }
}
