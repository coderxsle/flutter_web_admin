import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:dang_gui_admin/api/api_result_code.dart';
import 'package:dang_gui_admin/components/base_controller.dart';
import 'package:dang_gui_admin/models/voice_record.dart';
import 'package:dang_gui_admin/my_dialog.dart';
import 'package:dang_gui_admin/loacal_storage.dart';
import 'package:dang_gui_admin/utils/message_utils.dart';

class HomeController extends BaseController {

  // 数据列表
  final List<VoiceRecord> dataList = [];
  
  // 可选服务器列表
  static const List<String> serverList = [
    'ws://192.168.100.7:10096',
    'ws://192.168.0.57:10096',
  ];
  
  // 当前选中的服务器
  final selectedServer = 'ws://192.168.0.57:10096'.obs;
  
  // 自定义服务器输入控制器
  final customServerController = TextEditingController();
  
  // 是否显示自定义输入框
  final showCustomInput = false.obs;

  @override
  void onInit() {
    super.onInit();
    // 从本地存储读取服务器设置
    loadSelectedServer();
    recode.value = ResultCode.success;
    onRefresh();
  }
  
  /// 加载已选择的服务器
  void loadSelectedServer() {
    final savedServer = localStorageRead<String>('funasrBaseURL');
    if (savedServer != null && serverList.contains(savedServer)) {
      selectedServer.value = savedServer;
    } else {
      // 如果没有保存过或保存的值不在列表中，使用默认值并保存
      selectedServer.value = serverList.first;
      localStorageWrite('funasrBaseURL', selectedServer.value);
    }
  }
  
  /// 保存选中的服务器
  void saveSelectedServer(String server) {
    selectedServer.value = server;
    localStorageWrite('funasrBaseURL', server);
  }
  
  /// 添加自定义服务器
  void addCustomServer() {
    final customUrl = customServerController.text.trim();
    if (customUrl.isEmpty) {
      showInfo('请输入服务器地址');
      return;
    }
    
    // 简单的URL格式验证
    if (!customUrl.startsWith('ws://') && !customUrl.startsWith('wss://')) {
      showError('服务器地址必须以 ws:// 或 wss:// 开头');
      return;
    }
    
    // 保存自定义服务器并选中
    saveSelectedServer(customUrl);
    customServerController.text = 'ws://192.168.'; // 重置为默认值
    showCustomInput.value = false;
    showSuccess('自定义服务器已添加并设置为当前服务器');
  }

  @override
  Future<void> onRefresh() async {
    await loadData();
    super.onRefresh();
  }

  @override
  Future<void> onLoad() async {
    // 模拟加载更多数据
    await Future.delayed(const Duration(milliseconds: 500));
    final moreData = _generateMockData(5); // 每次加载5条
    dataList.addAll(moreData);
    super.onLoad();
  }

  Future<void> loadData() async {
    recode.value = ResultCode.loading;
    // 模拟网络请求延迟
    await Future.delayed(const Duration(milliseconds: 800));
    
    // 生成模拟数据
    final mockData = _generateMockData(10);
    dataList.addAll(mockData);
    recode.value = ResultCode.success;
  }

  /// 生成模拟数据
  List<VoiceRecord> _generateMockData(int count) {
    final now = DateTime.now();
    return List.generate(count, (index) {
      final id = DateTime.now().millisecondsSinceEpoch.toString() + index.toString();
      final recordTime = now.subtract(Duration(
        days: (index / 3).floor(),
        hours: index % 24,
        minutes: index * 7 % 60,
      ));
      
      final titles = [
        '团队周例会纪要',
        '项目评审会议',
        '客户需求讨论',
        '产品规划会议',
        '技术分享交流',
        '季度总结汇报',
        '培训学习笔记',
        '面试候选人交流',
        '部门工作安排',
        '重要电话记录',
        '创意头脑风暴',
        '用户调研反馈',
        'Bug修复讨论',
        '新功能设计评审',
        '合作伙伴洽谈',
      ];
      
      final duration = Duration(
        minutes: 2 + (index * 3) % 45,
        seconds: index * 13 % 60,
      );
      
      return VoiceRecord(
        id: id,
        title: titles[index % titles.length],
        duration: duration,
        recordTime: recordTime,
        transcription: index % 4 == 0 ? '这是一段示例转文字内容...' : null, // 25%的录音已转文字
        isTranscribing: index % 7 == 0, // 部分正在转换中
        filePath: '/storage/recordings/record_$id.m4a',
      );
    });
  }

  /// 处理转文字按钮点击
  void onTranscriptionTap(VoiceRecord record) {
    if (record.transcription != null) {
      // 查看已转换的文字内容
      _showTranscriptionDialog(record);
    } else if (!record.isTranscribing) {
      // 开始转换
      _startTranscription(record);
    }
  }

  /// 开始转文字
  void _startTranscription(VoiceRecord record) {
    // 更新状态为转换中
    final index = dataList.indexWhere((item) => item.id == record.id);
    if (index != -1) {
      dataList[index] = record.copyWith(isTranscribing: true);
      
      // 模拟转换过程
      Future.delayed(const Duration(seconds: 3), () {
        if (index < dataList.length) {
          dataList[index] = record.copyWith(
            isTranscribing: false,
            transcription: '这是模拟转换的文字内容：会议主要讨论了项目进度、资源分配和下一步计划。大家积极发言，提出了很多建设性意见...',
          );
        }
      });
    }
  }

  /// 显示转文字内容对话框
  void _showTranscriptionDialog(VoiceRecord record) {
    Get.dialog(
      AlertDialog(
        title: Text(record.title),
        content: SingleChildScrollView(
          child: Text(record.transcription ?? ''),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.close(),
            child: const Text('关闭'),
          ),
          ElevatedButton(
            onPressed: () {
              // TODO: 实现复制功能
              Get.close();
              Get.snackbar('提示', '文字内容已复制');
            },
            child: const Text('复制'),
          ),
        ],
      ),
    );
  }

  /// 删除录音
  void deleteRecord(VoiceRecord record) {
    Get.dialog(
      AlertDialog(
        title: const Text('确认删除'),
        content: Text('确定要删除录音"${record.title}"吗？'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('取消'),
          ),
          ElevatedButton(
            onPressed: () {
              dataList.removeWhere((item) => item.id == record.id);
              Get.back();
              Get.snackbar('提示', '录音已删除');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('删除'),
          ),
        ],
      ),
    );
  }

  /// 显示服务器设置对话框
  void showServerSettingDialog() {
    showAlertDialog(
      title: '请选择服务器',
      margin: EdgeInsets.all(20),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.only(bottom: 16),
            child: Text(
              '选择语音识别服务器：',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
          ),
                     ...serverList.map((server) {
             return Obx(() => GestureDetector(
               onTap: () => saveSelectedServer(server),
               child: Container(
                 margin: const EdgeInsets.only(bottom: 12),
                 padding: const EdgeInsets.all(16),
                 decoration: BoxDecoration(
                   color: selectedServer.value == server 
                       ? Theme.of(Get.context!).primaryColor.withOpacity(0.1)
                       : Colors.grey.shade50,
                   border: Border.all(
                     color: selectedServer.value == server 
                         ? Theme.of(Get.context!).primaryColor
                         : Colors.grey.shade300,
                     width: selectedServer.value == server ? 2 : 1,
                   ),
                   borderRadius: BorderRadius.circular(12),
                 ),
                 child: Row(
                   children: [
                     Container(
                       width: 20,
                       height: 20,
                       decoration: BoxDecoration(
                         shape: BoxShape.circle,
                         border: Border.all(
                           color: selectedServer.value == server 
                               ? Theme.of(Get.context!).primaryColor
                               : Colors.grey.shade400,
                           width: 2,
                         ),
                         color: selectedServer.value == server 
                             ? Theme.of(Get.context!).primaryColor
                             : Colors.transparent,
                       ),
                       child: selectedServer.value == server
                           ? const Icon(
                               Icons.check,
                               color: Colors.white,
                               size: 14,
                             )
                           : null,
                     ),
                     const SizedBox(width: 12),
                     Expanded(
                       child: Column(
                         crossAxisAlignment: CrossAxisAlignment.start,
                         children: [
                           Text(
                             _getServerDisplayName(server),
                             style: TextStyle(
                               fontSize: 16,
                               fontWeight: selectedServer.value == server 
                                   ? FontWeight.w600 
                                   : FontWeight.normal,
                               color: selectedServer.value == server 
                                   ? Theme.of(Get.context!).primaryColor
                                   : Colors.black87,
                             ),
                           ),
                           const SizedBox(height: 4),
                           Text(
                             server,
                             style: TextStyle(
                               fontSize: 12,
                               color: Colors.grey.shade600,
                             ),
                           ),
                         ],
                       ),
                     ),
                   ],
                 ),
               ),
             ));
           }),
          const SizedBox(height: 16),
          
          // 自定义服务器输入区域
          Obx(() => Column(
            children: [
              // 添加自定义服务器按钮
              if (!showCustomInput.value)
                GestureDetector(
                  onTap: () {
                    customServerController.text = 'ws://192.168.';
                    showCustomInput.value = true;
                  },
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.orange.shade50,
                      border: Border.all(color: Colors.orange.shade300, width: 1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_circle_outline, 
                             color: Colors.orange.shade600, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          '添加自定义服务器',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                            color: Colors.orange.shade700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              
              // 自定义输入框
              if (showCustomInput.value) ...[
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '自定义服务器地址：',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: customServerController,
                        decoration: InputDecoration(
                          hintText: '例如：ws://192.168.1.100:10096',
                          hintStyle: TextStyle(color: Colors.grey.shade500),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(color: Colors.grey.shade300),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(
                              color: Theme.of(Get.context!).primaryColor,
                              width: 2,
                            ),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12, 
                            vertical: 10,
                          ),
                        ),
                        style: const TextStyle(fontSize: 14),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                                                     Expanded(
                             child: TextButton(
                               onPressed: () {
                                 customServerController.text = 'ws://192.168.';
                                 showCustomInput.value = false;
                               },
                              style: TextButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 8),
                              ),
                              child: const Text(
                                '取消',
                                style: TextStyle(color: Colors.grey),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: addCustomServer,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Theme.of(Get.context!).primaryColor,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 8),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                              child: const Text(
                                '确认添加',
                                style: TextStyle(fontSize: 14),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
              
              const SizedBox(height: 16),
            ],
          )),
          
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.blue.shade200),
            ),
            child: Row(
              children: [
                Icon(Icons.verified, color: Colors.green, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '当前${_getServerDisplayName(selectedServer.value)}',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.blue.shade700,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      confirm: () {
        dismissAlertDialog();
        showInfo('设置成功：\n${selectedServer.value}');
      },
      cancelText: '取消',
      confirmText: '确定',
      cancel: () {
        dismissAlertDialog();
      },
    );
  }
  
  /// 获取服务器显示名称
  String _getServerDisplayName(String serverUrl) {
    if (serverUrl.contains('192.168.100.7')) {
      return 'Mac mini (192.168.100.7)';
    } else if (serverUrl.contains('192.168.0.57')) {
      return 'Mac Book Pro (192.168.0.57)';
    }
    return '自定义服务器';
  }
  
  @override
  void onClose() {
    customServerController.dispose();
    super.onClose();
  }
}
