import 'package:dang_gui_admin/layout/layout_index.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'controller.dart';

class DashboardView extends GetView<DashboardController> {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.home, size: 64, color: Theme.of(context).primaryColor),
          const SizedBox(height: 16),
          Text(
            '欢迎使用 Flutter 布局系统',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            '这是一个完全基于 Flutter 实现的管理后台布局系统',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 32),
          Wrap(
            spacing: 16,
            children: [
              ElevatedButton(
                onPressed: () => Get.find<AppLayoutController>().layout = LayoutType.defaultLayout,
                child: const Text('默认布局'),
              ),
              ElevatedButton(
                onPressed: () => Get.find<AppLayoutController>().layout = LayoutType.mix,
                child: const Text('混合布局'),
              ),
              ElevatedButton(
                onPressed: () => Get.find<AppLayoutController>().layout = LayoutType.top,
                child: const Text('顶部布局'),
              ),
            ],
          ),
        ],
      ),  
    );
  }
}
