import 'package:get/get.dart';

class HomeController2 extends GetxController {
  //TODO: Implement HomeController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }



  void increment() => count.value++;
}
