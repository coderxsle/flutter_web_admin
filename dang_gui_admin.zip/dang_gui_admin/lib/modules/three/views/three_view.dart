import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/three_controller.dart';

class ThreeView extends GetView<ThreeController> {
  const ThreeView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('第三页'),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              '这是第三页',
              style: TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Get.offAllNamed('/home'),
              child: const Text('直接返回首页'),
            ),
          ],
        ),
      ),
    );
  }
}
