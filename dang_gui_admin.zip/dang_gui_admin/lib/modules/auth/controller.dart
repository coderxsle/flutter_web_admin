import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http_manager/http_manager.dart';
import 'package:dang_gui_admin/api/login_api.dart';
import 'package:dang_gui_admin/app_manager.dart';
import 'package:dang_gui_admin/api/api_result_code.dart';
import 'package:dang_gui_admin/models/login_res.dart';
import 'package:dang_gui_admin/models/captcha_res.dart';
import 'package:dang_gui_admin/utils/param_check.dart';
import '../../routes/app_pages.dart';
import '../../utils/message_utils.dart';

class LoginController extends GetxController {
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();
  final captchaController = TextEditingController();
  final isLoading = false.obs;
  
  // 验证码相关状态
  final captchaEnabled = false.obs;
  final captchaImage = Rx<Uint8List?>(null);
  final captchaUuid = ''.obs;
  final isCaptchaLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    if (kDebugMode) {
      usernameController.text = "admin";
      passwordController.text = "admin123";
    }
    // 页面初始化时获取验证码
    // getCaptcha();
  }

  /// 获取验证码
  Future<void> getCaptcha() async {
    isCaptchaLoading.value = true;
    try {
      final result = await UserApi.getCaptcha();
      if (result.success && result.data != null) {
        final captchaResponse = CaptchaRes.fromJson(result.data!);
        captchaEnabled.value = captchaResponse.captchaEnabled;
        captchaUuid.value = captchaResponse.uuid;
        
        // 解码base64图片
        if (captchaResponse.img.isNotEmpty) {
          try {
            captchaImage.value = base64Decode(captchaResponse.img);
          } catch (e) {
            showError('验证码图片解析失败');
          }
        }
      } else {
        showError(result.message ?? '获取验证码失败');
      }
    } catch (e) {
      showError('获取验证码失败: ${e.toString()}');
    } finally {
      isCaptchaLoading.value = false;
    }
  }

  /// 刷新验证码
  Future<void> refreshCaptcha() async {
    captchaController.clear();
    await getCaptcha();
  }

  Future<void> login() async {
    final username = usernameController.text.trim();
    final password = passwordController.text.trim();
    final code = captchaEnabled.value ? captchaController.text.trim() : null;
    final uuid = captchaEnabled.value ? captchaUuid.value : null;

    if (validate(username, "用户名不能为空")) return;
    if (validate(password, "密码不能为空")) return;
    // if (validate(uuid, "UUID不能为空")) return;
    // 如果启用了验证码，检查验证码是否输入
    if (captchaEnabled.value) {
      if (validate(code, "验证码不能为空")) return;
    }
    
    isLoading.value = true;
    final param = { "userName": username, "password": password, "code": code, "uuid": uuid };
    final result = await UserApi.login(param);
    if (result.success) {   
      // 设置登录状态
      final userToken = result.data["accessToken"];
      httpManager.setHeaders({"Authorization": "Bearer $userToken"});
      AppManager.userToken = userToken;
      // 获取用户信息
      await getUserInfo(password);
    } else {
      showError(result.message ?? '登录失败');
      // 登录失败时刷新验证码
      if (captchaEnabled.value) {
        await refreshCaptcha();
      }
    }
    isLoading.value = false;
  }

  @override
  void onClose() {
    usernameController.dispose();
    passwordController.dispose();
    captchaController.dispose();
    super.onClose();
  }
  
  /// 获取用户信息
  Future<void> getUserInfo(String password) async {
    final result = await UserApi.getUserInfo();
    if (result.success) {
      final loginData = Login.fromJson(result.data);
      AppManager.login(loginData.user!, password: password);
      Get.offAllNamed(Routes.HOME2);
    } else {
      showError(result.message ?? '获取用户信息失败');
    }
    isLoading.value = false;
  }
}