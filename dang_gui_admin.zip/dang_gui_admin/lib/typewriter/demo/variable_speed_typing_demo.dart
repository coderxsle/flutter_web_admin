import 'package:flutter/material.dart';
import '../typewriter_text.dart';

class VariableSpeedTypingDemo extends StatefulWidget {
  const VariableSpeedTypingDemo({super.key});

  @override
  State<VariableSpeedTypingDemo> createState() => _VariableSpeedTypingDemoState();
}

class _VariableSpeedTypingDemoState extends State<VariableSpeedTypingDemo> {
  final GlobalKey<TypewriterTextState> _typewriterKey = GlobalKey();
  double _speedMultiplier = 1.0;
  bool _isStarted = false;
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('可变速打字效果'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 使用Container包裹，设置约束确保文本能够换行
            Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width - 40,
              ),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 5,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(16),
              child: TypewriterText(
                key: _typewriterKey,
                text: '这是一个可变速打字效果演示，模拟真实的打字节奏。\n\n您可以使用下面的滑块调整打字速度，从慢速逐渐加快，或者从快速逐渐减慢。\n\n标点符号会自动减速，空格会加速，相同字符连续出现也会加速。\n\n有时会有随机的停顿，就像真人打字时思考一样。',
                baseSpeed: 50, // 设置基础打字速度
                speedVariation: 0.3, // 设置打字速度的变异范围
                randomPauses: true, // 设置是否随机停顿
                pauseProbability: 0.08, // 设置停顿概率
                naturalTyping: true, // 设置是否自然打字
                autoStart: false, // 设置是否自动启动
                style: const TextStyle(
                  fontSize: 18,
                  height: 1.5,
                  color: Colors.black87,
                ),
                cursor: const BlinkingCursor(
                  color: Colors.blue,
                  blinkDuration: Duration(milliseconds: 600),
                ),
              ),
            ),
            
            const SizedBox(height: 30),
            
            Text('打字速度: ${_speedMultiplier.toStringAsFixed(1)}x'),
            
            Slider(
              value: _speedMultiplier,
              min: 0.5,
              max: 3.0,
              divisions: 15, // 设置刻度数量
              label: '${_speedMultiplier.toStringAsFixed(1)}x',
              onChanged: (value) {
                setState(() {
                  _speedMultiplier = value;
                  
                  // 获取TypewriterText的状态，并设置速度
                  final state = _typewriterKey.currentState;
                  if (state != null) {
                    state.setSpeedMultiplier(_speedMultiplier);
                  }
                });
              },
            ),
            
            const SizedBox(height: 20),
            
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _isStarted = true;
                    });
                    final state = _typewriterKey.currentState;
                    if (state != null) {
                      state.startTyping();
                    }
                  },
                  child: const Text('开始'),
                ),
                
                const SizedBox(width: 10),
                
                ElevatedButton(
                  onPressed: _isStarted ? () {
                    final state = _typewriterKey.currentState;
                    if (state != null && state.isPlaying) {
                      state.pauseTyping();
                      setState(() {}); // 触发界面刷新
                    } else if (state != null && !state.isPlaying) {
                      state.resumeTyping();
                      setState(() {}); // 触发界面刷新
                    }
                  } : null,
                  child: Builder(
                    builder: (context) {
                      final state = _typewriterKey.currentState;
                      return Text(state != null && state.isPlaying ? '暂停' : '继续');
                    }
                  ),
                ),
                
                const SizedBox(width: 10),
                
                ElevatedButton(
                  onPressed: _isStarted ? () {
                    final state = _typewriterKey.currentState;
                    if (state != null) {
                      state.showFullText();
                      setState(() {});
                    }
                  } : null,
                  child: const Text('完成'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// 闪烁光标组件
class BlinkingCursor extends StatefulWidget {
  final Color color;
  final Duration blinkDuration;
  
  const BlinkingCursor({
    super.key, 
    this.color = Colors.black,
    this.blinkDuration = const Duration(milliseconds: 500),
  });

  @override
  State<BlinkingCursor> createState() => _BlinkingCursorState();
}

class _BlinkingCursorState extends State<BlinkingCursor> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  
  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: widget.blinkDuration,
    )..repeat(reverse: true);
    
    _animation = Tween<double>(begin: 0.0, end: 1.0).animate(_controller);
  }
  
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animation,
      child: Text(
        '⚫',
        style: TextStyle(
          color: widget.color,
          fontWeight: FontWeight.bold,
          fontSize: 18,
          height: 1.5, // 匹配文本的行高
        ),
      ),
    );
  }
}