import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_highlight/flutter_highlight.dart';

class AnimatedCodeTyping extends StatefulWidget {
  /// 初始代码文本
  final String initialCode;
  
  /// 目标代码文本
  final String targetCode;
  
  /// 编程语言（用于高亮）
  final String language;
  
  /// 打字速度，每个字符的毫秒数
  final int typingSpeed;
  
  /// 高亮主题
  final Map<String, TextStyle>? theme;
  
  /// 高亮的行（从1开始）
  final List<int>? highlightedLines;
  
  /// 是否显示行号
  final bool showLineNumbers;
  
  /// 打字完成后的回调
  final VoidCallback? onComplete;
  
  /// 打字开始前的延迟（毫秒）
  final int startDelay;
  
  const AnimatedCodeTyping({
    super.key,
    required this.initialCode,
    required this.targetCode,
    this.language = 'dart',
    this.typingSpeed = 20,
    this.theme,
    this.highlightedLines,
    this.showLineNumbers = false,
    this.onComplete,
    this.startDelay = 0,
  });

  @override
  State<AnimatedCodeTyping> createState() => _AnimatedCodeTypingState();
}

class _AnimatedCodeTypingState extends State<AnimatedCodeTyping> {
  String _currentCode = '';
  Timer? _timer;
  int _targetPosition = 0;
  
  // 更全面的高亮主题定义
  final Map<String, TextStyle> _defaultTheme = const {
    'root': TextStyle(backgroundColor: Color(0xFF282c34), color: Color(0xFFabb2bf)), // 根节点
    'keyword': TextStyle(color: Color(0xFFc678dd)), // 关键字
    'built_in': TextStyle(color: Color(0xFF61afef)), // 内置类型
    'type': TextStyle(color: Color(0xFF61afef)),  // 类型（如String, int等）
    'string': TextStyle(color: Color(0xFF98c379)), // 字符串
    'comment': TextStyle(color: Color(0xFF5c6370), fontStyle: FontStyle.italic), // 注释
    'number': TextStyle(color: Color(0xFFd19a66)), // 数字
    'class': TextStyle(color: Color(0xFFe5c07b)), // 类
    'literal': TextStyle(color: Color(0xFF56b6c2)), // 字面量
    'function': TextStyle(color: Color(0xFF61afef)), // 函数
    'method': TextStyle(color: Color(0xFF61afef)),  // 方法名称
    'title': TextStyle(color: Color(0xFF61afef)),  // 函数和方法标题
    'title.class': TextStyle(color: Color(0xFFe5c07b)),  // 类名
    'title.function': TextStyle(color: Color(0xFF61afef)),  // 函数名
    'title.function.invoke': TextStyle(color: Color(0xFF61afef)),  // 函数调用
    'entity.name.function': TextStyle(color: Color(0xFF61afef)),  // 实体函数名
    'operator': TextStyle(color: Color(0xFFc678dd)), // 运算符
    'variable': TextStyle(color: Color(0xFFd19a66)), // 变量
    'variable.language': TextStyle(color: Color(0xFFe5c07b)), // 语言变量
    'variable.parameter': TextStyle(color: Color(0xFFd19a66)), // 参数变量
    'parameter': TextStyle(color: Color(0xFFe06c75)),  // 参数
    'property': TextStyle(color: Color(0xFF61afef)), // 属性
    'punctuation': TextStyle(color: Color(0xFFabb2bf)), // 标点符号
    'attr-name': TextStyle(color: Color(0xFFd19a66)), // 属性名
    'tag': TextStyle(color: Color(0xFFe06c75)), // 标签
    'attribute': TextStyle(color: Color(0xFFd19a66)), // 属性值
    'meta': TextStyle(color: Color(0xFF61afef)), // 元数据
    'params': TextStyle(color: Color(0xFFd19a66)),  // 参数列表
    'regexp': TextStyle(color: Color(0xFF98c379)), // 正则表达式
    'selector-tag': TextStyle(color: Color(0xFFe5c07b)), // 选择器标签
    'selector-id': TextStyle(color: Color(0xFFe06c75)), // 选择器ID
    'name': TextStyle(color: Color(0xFF61afef)),  // 名称
    'entity': TextStyle(color: Color(0xFF61afef)),  // 实体
    'entity.name': TextStyle(color: Color(0xFF61afef)),  // 实体名称
    'subst': TextStyle(color: Color(0xFFd19a66)),  // 替代
    'symbol': TextStyle(color: Color(0xFF56b6c2)),  // 符号
    'identifier': TextStyle(color: Color(0xFF61afef)),  // 标识符
  };
  
  @override
  void initState() {
    super.initState();
    _currentCode = ''; // 从空字符串开始
    
    // 给动画开始前留出延迟
    Future.delayed(Duration(milliseconds: widget.startDelay), () {
      _animateInitialCode(); // 先对初始代码执行打字动画
    });
  }
  
  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
  
  Future<void> _animateInitialCode() async {
    _targetPosition = 0;
    
    await Future.delayed(Duration(milliseconds: 1000));
    
    // 逐字显示初始代码
    _timer = Timer.periodic(Duration(milliseconds: widget.typingSpeed), (timer) {
      if (_targetPosition < widget.initialCode.length) {
        setState(() {
          _currentCode = widget.initialCode.substring(0, _targetPosition + 1);
          _targetPosition++;
        });
      } else {
        timer.cancel();
        // 显示完初始代码后稍等片刻，然后开始目标代码动画
        Future.delayed(Duration(milliseconds: 500), () {
          _startAnimation();
        });
      }
    });
  }
  
  void _startAnimation() {
    // 重置目标位置
    _targetPosition = 0;
    
    // 从初始代码到目标代码的动画效果
    _timer = Timer.periodic(Duration(milliseconds: widget.typingSpeed), (timer) {
      if (_targetPosition < widget.targetCode.length) {
        setState(() {
          _currentCode = widget.targetCode.substring(0, _targetPosition + 1);
          _targetPosition++;
        });
      } else {
        timer.cancel();
        if (widget.onComplete != null) {
          widget.onComplete!();
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 600,
      height: 300,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: const Color(0xFF282c34),
      ),
      child: _buildHighlightedCode(_currentCode),
    );
  }

  Widget _buildHighlightedCode(String code) {
    return HighlightView(
      code,
      language: widget.language,
      theme: widget.theme ?? _defaultTheme,
      padding: const EdgeInsets.all(12),
      textStyle: const TextStyle(
        fontFamily: 'JetBrainsMono',
        fontSize: 18,
      ),
    );
  }
}