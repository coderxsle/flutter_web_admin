enum TypewriterSpeedCurve {
  constant,    // 恒定速度
  accelerate,  // 逐渐加速
  decelerate,  // 逐渐减速
  random,      // 完全随机
  natural,     // 自然模拟（开始慢，中间快，结尾慢）
}