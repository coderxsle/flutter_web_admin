# 通用 Overlay 弹出组件需求说明

## 背景
在 Flutter 项目中，经常需要使用 `OverlayEntry` 实现悬浮弹出框。但直接使用 `OverlayEntry` 比较繁琐，因此需要将其封装成一个 **通用的弹出组件**，方便在项目中快速复用。

---

## 使用方式

方案：组件包裹方式

将目标按钮用组件包裹，点击时自动显示弹框：

ArrowPopupWrapper(
  direction: PopupDirection.bottom,
  size: Size(200, 100),
  popupBuilder: (context) => MyCustomWidget(),
  child: ElevatedButton(
    onPressed: () {},
    child: Text("点我"),
  ),
);

参数说明：
direction：弹出方向
size：弹框宽高
popupBuilder：构建弹框内容的函数
child：需要包裹的按钮或 widget

功能清单
    方向选择：支持 top / bottom / left / right 四个方向
    尺寸控制：可自定义宽度和高度
    箭头：弹出框带一个小尖尖，指向目标按钮
    自定义内容：支持传入任意 widget
    自动关闭：点击外部区域时，自动关闭弹框
    多次使用：支持多个地方独立使用，不相互影响
    动画（可选）：弹出时有淡入/缩放动画效果

输出要求
    封装为独立的 Dart 组件文件
    提供完整的使用示例，能够直接运行
    代码结构清晰，便于复用和扩展
    尽量避免使用 GlobalKey ，提高使用的便捷性