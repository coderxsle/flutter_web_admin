# 🚀 路由管理系统

## 概述

本项目采用了一套功能完整、设计精良的路由管理系统，结合了 GetX 的轻量级路由和自定义的路由元数据系统，实现了类似 Vue Router 的 `meta` 字段功能，为大型管理后台提供了强大的路由管理能力。

## 🎯 核心特性

### 1. **双重路由架构**
- **GetX 标准路由**：负责页面导航和组件加载
- **自定义路由系统**：管理路由元数据和业务逻辑
- **完美结合**：既保持了 GetX 的简洁性，又提供了企业级功能

### 2. **完整的路由树结构**
```dart
RouteRecord(
  path: '/system',
  name: 'System',
  meta: const RouteMeta(
    title: '系统管理',
    svgIcon: 'settings',
    hidden: false,
  ),
  children: [
    RouteRecord(
      path: '/system/user',
      name: 'SystemUser',
      meta: const RouteMeta(
        title: '用户管理',
        svgIcon: 'user',
        hidden: false,
      ),
    ),
    // ... 更多子路由
  ],
)
```

### 3. **智能子路由处理**
- 自动检测单子路由情况
- 智能菜单折叠逻辑
- 动态路由层级计算

### 4. **丰富的元数据支持**
```dart
class RouteMeta {
  final String? title;           // 路由标题
  final bool hidden;             // 是否隐藏
  final String? svgIcon;         // SVG 图标
  final IconData? icon;          // 图标数据
  final bool affix;              // 是否固定标签页
  final bool breadcrumb;         // 面包屑显示
  final String? activeMenu;      // 激活菜单
  final bool noShowingChildren;  // 不显示子菜单
  final String? redirect;        // 重定向路径
}
```

## 🏗️ 架构设计

### 核心组件

#### 1. **RouteRecord 模型**
- 完整的路由数据结构
- 支持嵌套子路由
- 提供丰富的工具方法

#### 2. **RouteMeta 元数据**
- 类型安全的元数据定义
- 支持序列化/反序列化
- 可扩展的字段设计

#### 3. **RouteController 控制器**
- 路由状态管理
- 智能过滤和搜索
- 动态路由操作

### 数据流

```mermaid
graph TD
    A[GetX 路由配置] --> B[RouteController]
    B --> C[RouteRecord 树]
    C --> D[UI 组件]
    D --> E[菜单生成]
    D --> F[面包屑导航]
    D --> G[标签页管理]
    
    H[后端数据] --> I[序列化]
    I --> C
    C --> J[反序列化]
    J --> K[动态更新]
```

## ✨ 功能优势

### 1. **企业级特性**
- ✅ **完整 CRUD 操作**：支持路由的增删改查
- ✅ **序列化支持**：可从后端动态加载路由配置
- ✅ **类型安全**：编译时检查，避免运行时错误
- ✅ **可扩展性**：易于添加新功能和字段

### 2. **开发体验**
- ✅ **智能默认行为**：自动处理常见场景
- ✅ **丰富的工具方法**：过滤、搜索、层级计算
- ✅ **清晰的 API 设计**：直观易用的接口
- ✅ **完整的文档支持**：详细的代码注释

### 3. **性能优化**
- ✅ **高效查找**：O(1) 路径查找
- ✅ **智能缓存**：避免重复计算
- ✅ **懒加载**：按需加载路由数据
- ✅ **内存优化**：合理的数据结构设计

### 4. **UI 集成**
- ✅ **菜单自动生成**：基于路由树自动生成侧边栏
- ✅ **面包屑导航**：智能计算导航路径
- ✅ **标签页管理**：支持固定和动态标签页
- ✅ **权限控制**：基于角色的路由访问控制

## 🔧 使用示例

### 基础路由配置
```dart
// 在 RouteController 中配置路由
void _initializeRoutes() {
  _routes.value = [
    RouteRecord(
      path: '/home',
      name: 'Home',
      meta: const RouteMeta(
        title: '首页',
        svgIcon: 'home',
        affix: true,
        keepAlive: true,
      ),
    ),
    // ... 更多路由
  ];
}
```

### 动态路由操作
```dart
// 添加路由
routeController.addRoute(newRoute);

// 移除路由
routeController.removeRoute('/old-path');

// 更新路由
routeController.setRoutes(newRoutes);
```

### UI 组件使用
```dart
// 菜单生成
final menuRoutes = routeController.menuRoutes;

// 面包屑导航
final hierarchy = routeController.getRouteHierarchy(currentPath);

// 权限检查
final hasPermission = routeController.hasPermission(route, userRoles);
```

## 📊 技术对比

| 特性 | 本项目 | 标准 GetX | go_router | Vue Router |
|------|--------|-----------|-----------|------------|
| 路由树结构 | ✅ 完整支持 | ❌ 扁平结构 | ✅ 完整支持 | ✅ 完整支持 |
| 元数据管理 | ✅ 类型安全 | ❌ 无支持 | ⚠️ 基础支持 | ✅ 类型安全 |
| 动态路由 | ✅ 完整支持 | ⚠️ 基础支持 | ✅ 完整支持 | ✅ 完整支持 |
| 序列化 | ✅ 完整支持 | ❌ 无支持 | ❌ 无支持 | ✅ 完整支持 |
| 智能处理 | ✅ 自动处理 | ❌ 手动处理 | ⚠️ 部分支持 | ✅ 自动处理 |
| 嵌套路由 | ✅ 完整支持 | ❌ 无支持 | ✅ 完整支持 | ✅ 完整支持 |
| 路由守卫 | ✅ 中间件支持 | ✅ 中间件支持 | ✅ 路由守卫 | ✅ 路由守卫 |
| 状态管理 | ✅ GetX 集成 | ✅ 原生支持 | ❌ 需额外集成 | ❌ 需额外集成 |
| 性能 | ✅ 优化 | ✅ 优秀 | ✅ 优秀 | ✅ 优秀 |
| 学习成本 | ⚠️ 中等 | ✅ 简单 | ⚠️ 中等 | ⚠️ 中等 |
| 生态支持 | ⚠️ 自定义 | ✅ 丰富 | ✅ 丰富 | ✅ 丰富 |

## 🎉 总结

本路由管理系统成功地将 GetX 的简洁性与企业级功能需求完美结合，提供了：

- **功能完整性**：支持复杂的路由场景
- **开发效率**：智能的默认行为和丰富的工具方法
- **维护性**：清晰的架构和完整的文档
- **扩展性**：易于添加新功能和适配新需求

这套系统特别适合大型管理后台项目，能够显著提升开发效率和代码质量，是 Flutter 项目中路由管理的最佳实践之一。

---

*本文档详细介绍了项目的路由管理系统，如需了解更多技术细节，请参考源代码中的详细注释。*
