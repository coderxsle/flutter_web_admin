

import 'package:flutter/material.dart';

/// 快速创建菜单项 - 向后兼容的版本
/// 构建带有构建器的菜单项 - 可直接用于路由配置
MenuItem menu(String title, String route, IconData icon, {List<MenuItem>? children, }) {
  return MenuItem(title: title, route: route, icon: icon, children: children, id: id);
}


/// 获取应用程序的所有菜单项 - 同时包含路由配置
List<MenuItem> getSideMenuItems() {
  return [
    menu('首页', '/home', Icons.home, children: [
      menu('首页6 - 简约风格', '/home6', Icons.home,),
      menu('首页7 - 简约风格', '/home7', Icons.home_outlined,),
      menu('首页8 - 深色主题风格', '/home8', Icons.home_work),
      menu('首页9 - 极简风格', '/home9', Icons.home_max),
    ]),
    menu('仪表盘', '/dashboard', Icons.dashboard, children: [
      menu('控制台', '/dashboard', Icons.dashboard,),
      menu('数据统计', '/analytics', Icons.bar_chart,),
    ]),
    menu('组件', '/components', Icons.widgets, children: [
      menu('主题', '/theme', Icons.palette,),
      menu('按钮', '/buttons', Icons.smart_button,),
      menu('基本表单', '/form_basic', Icons.article,),
      menu('基础表单', '/forms', Icons.article,),
      menu('表格', '/tables', Icons.table_chart,),
      menu('卡片', '/cards', Icons.credit_card,),
      menu('标签页', '/tabs', Icons.tab,),
    ]),
    menu('页面', '/pages', Icons.pages, children: [
      menu('登录', '/login', Icons.login,),
      menu('注册', '/register', Icons.app_registration,),
      menu('错误页面', '/error', Icons.error, children: [
        menu('403', '/403', Icons.error,),
        menu('404', '/404', Icons.error,),
        menu('500', '/500', Icons.error,),
      ]),
    ]),
  ];
}



/// 菜单项类型
enum MenuItemType {
  /// 分组
  group,
  /// 菜单项
  item,
}


/// 菜单项数据模型
class MenuItem {
  final String title;               /// 菜单标题
  final String? route;              /// 路由路径
  final IconData? icon;             /// 菜单图标
  final String? image;              /// 菜单图片
  final List<MenuItem>? children;   /// 子菜单列表
  final bool visible;               /// 是否显示
  final MenuItemType type;          /// 菜单类型 (group: 分组, item: 菜单项)
  final String? permission;         /// 权限标识
  final int sort;                   /// 排序
  final String? externalUrl;        /// 外部链接

  const MenuItem({
    required this.title,
    this.icon,
    this.image,
    this.route,
    this.children,
    this.visible = true,
    this.type = MenuItemType.item,
    this.permission,
    this.sort = 0,
    this.externalUrl,
  });

  /// 从JSON创建菜单项
  factory MenuItem.fromJson(Map<String, dynamic> json) {
    return MenuItem(
      title: json['title'] ?? '',
      icon: json['icon'],
      image: json['image'],
      route: json['route'],
      children: json['children'] != null
          ? (json['children'] as List)
              .map((child) => MenuItem.fromJson(child))
              .toList()
          : null,
      visible: json['visible'] ?? true,
      type: MenuItemType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => MenuItemType.item,
      ),
      permission: json['permission'],
      sort: json['sort'] ?? 0,
      externalUrl: json['externalUrl'],
    );
  }

  /// 是否有子菜单
  bool get hasChildren => children != null && children!.isNotEmpty;

  /// 获取可见的子菜单
  List<MenuItem> get visibleChildren => children?.where((child) => child.visible).toList() ?? [];


  @override
  String toString() {
    return 'MenuItem(title: $title, route: $route, hasChildren: $hasChildren)';
  }
}
