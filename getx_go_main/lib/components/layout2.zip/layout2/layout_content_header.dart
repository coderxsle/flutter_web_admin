import 'package:dang_gui_admin/app_manager.dart';
import 'package:dang_gui_admin/components/layout/layout_menu_item.dart';
import 'package:dang_gui_admin/components/feedback/gi_acro_message.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../models/menu_item.dart';
import 'layout_controller.dart';
import 'package:dang_gui_admin/components/popup/gi_arrow_popup_wrapper.dart';

/// 头部导航组件
class LayoutContentHeader extends GetView<LayoutController> implements PreferredSizeWidget {
  const LayoutContentHeader({super.key});

  @override
  Size get preferredSize => const Size.fromHeight(64);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Theme.of(context).colorScheme.surface,
      elevation: 1,
      shadowColor: Theme.of(context).shadowColor.withOpacity(0.1),
      leading: _buildLeading(context),
      title: _buildTitle(context),
      actions: _buildActions(context),
      automaticallyImplyLeading: false,
    );
  }

  /// 构建左侧按钮
  Widget? _buildLeading(BuildContext context) {
    if (controller.isMobile) {
      return IconButton(
        onPressed: controller.toggleSidebarVisibility,
        icon: const Icon(Icons.menu),
        tooltip: '显示菜单',
      );
    }
    return const SizedBox.shrink();
  }

  /// 构建标题区域
  Widget _buildTitle(BuildContext context) {
    return Obx(() {
      return Row(
        children: [
          Expanded(
            child: _buildBreadcrumb(context),
          ),
        ],
      );
    });
  }

  /// 构建面包屑导航
  Widget _buildBreadcrumb(BuildContext context) {
    final breadcrumbs = controller.breadcrumbsRx;
    
    if (breadcrumbs.isEmpty) {
      return const SizedBox.shrink();
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          // 首页图标
          Icon(
            Icons.home,
            size: 16,
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
          ),
          
          // 面包屑项
          ...breadcrumbs.asMap().entries.map((entry) {
            final index = entry.key;
            final breadcrumb = entry.value;
            final isLast = index == breadcrumbs.length - 1;
            
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 分隔符
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Icon(
                    Icons.chevron_right,
                    size: 16,
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
                  ),
                ),
                
                // 面包屑项
                InkWell(
                  onTap: isLast || breadcrumb.route == null
                      ? null
                      : () => Get.toNamed(breadcrumb.route!),
                  child: Text(
                    breadcrumb.title,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: isLast
                          ? Theme.of(context).primaryColor
                          : Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                      fontWeight: isLast ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                ),
              ],
            );
          }).toList(),
        ],
      ),
    );
  }

  /// 构建右侧操作按钮
  List<Widget> _buildActions(BuildContext context) {
    return [
      // 设置按钮
      IconButton(
        onPressed: () {
          _showSettingDialog(context);
        },
        icon: const Icon(Icons.settings),
        tooltip: '设置',
      ),
      
      // 通知按钮
      _buildNotificationButton(context),
      
      // 全屏按钮
      IconButton(
        onPressed: _toggleFullScreen,
        icon: const Icon(Icons.fullscreen),
        tooltip: '全屏',
      ),
      
      // 主题切换按钮（不使用 Obx，基于当前主题亮度）
      IconButton(
        onPressed: () {
          final isDark = Theme.of(context).brightness == Brightness.dark;
          Get.changeThemeMode(isDark ? ThemeMode.light : ThemeMode.dark);
        },
        icon: Icon(
          Theme.of(context).brightness == Brightness.dark
              ? Icons.light_mode
              : Icons.dark_mode,
        ),
        tooltip: Theme.of(context).brightness == Brightness.dark
            ? '浅色模式'
            : '深色模式',
      ),
      
      // 用户菜单
      _buildUserMenu(context),
      
      const SizedBox(width: 8),
    ];
  }

  /// 构建通知按钮
  Widget _buildNotificationButton(BuildContext context) {
    return Stack(
      children: [
        IconButton(
          onPressed: () {
            _showNotificationPanel(context);
          },
          icon: const Icon(Icons.notifications_outlined),
          tooltip: '通知',
        ),
        // 通知小红点
        Positioned(
          right: 8,
          top: 8,
          child: Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
      ],
    );
  }

  /// 构建用户菜单
  Widget _buildUserMenu(BuildContext context) {
    return GiArrowPopupWrapper(
      direction: PopupDirection.bottom,
      size: const Size(120, 140),
      popupBuilder: (context) => Column(
        children: [
          _buildMenuItem(Icons.person, '个人资料'),
          _buildMenuItem(Icons.settings, '系统设置'),
          _buildMenuItem(Icons.logout, '退出登录'),
        ],
      ),
      onTrigger: (showPopup) {
        showPopup();
      },
      child: const Icon(Icons.more_vert),
    );
  }

  Widget _buildMenuItem(IconData icon, String label) {
    return InkWell(
      onTap: () {
        _handleUserMenuAction(label);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            Icon(icon, size: 16),
            const SizedBox(width: 8),
            Text(label),
          ],
        ),
      ),
    );
  }

  /// 处理用户菜单操作
  void _handleUserMenuAction(String action) {
    switch (action) {
      case 'profile':
        // 跳转到个人资料页面
        GiArcoMessage.info('跳转到个人资料页面');
        break;
      case 'settings':
        // 跳转到系统设置页面
        GiArcoMessage.info('跳转到系统设置页面');
        break;
      case 'logout':
        // 退出登录
        _showLogoutDialog();
        break;
    }
  }
  
  /// 显示通知面板
  void _showNotificationPanel(BuildContext context) {
    GiArcoMessage.info('通知功能暂未实现');
  }

  /// 切换全屏
  void _toggleFullScreen() {
    // 这里可以实现全屏切换逻辑
    GiArcoMessage.info('全屏功能暂未实现');
  }

  /// 显示设置对话框
  void _showSettingDialog(BuildContext context) {
    GiArcoMessage.info('设置功能暂未实现');
  }

  /// 显示退出登录确认对话框
  void _showLogoutDialog() {
    Get.dialog(
      AlertDialog(
        title: const Text('确认退出'),
        content: const Text('您确定要退出登录吗？'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              AppManager.signOut();
            },
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }
}