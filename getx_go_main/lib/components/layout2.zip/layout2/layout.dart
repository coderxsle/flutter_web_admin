import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'layout_content_header.dart';
import 'layout_controller.dart';
import 'layout_drawer.dart';
import 'layout_sidebar.dart';

/// Layout 主组件
class Layout extends StatelessWidget {
  
  final Widget child; /// 主内容区域
  final bool showHeader; /// 是否显示头部导航
  final bool showSidebar; /// 是否显示侧边栏
  final PreferredSizeWidget? customHeader; /// 自定义头部组件

  const Layout({super.key, required this.child, this.showHeader = true, this.showSidebar = true, this.customHeader});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<LayoutController>(
      builder: (controller) {
        return Scaffold(
          appBar: showHeader ? (customHeader ?? const LayoutContentHeader()) : null,
          body: _buildBody(context, controller),
          drawer: controller.isMobile && showSidebar
              ? const LayoutDrawer()
              : null,
          drawerScrimColor: Colors.black.withValues(alpha: 0.3),
        );
      },
    );
  }

  /// 构建主体内容
  Widget _buildBody(BuildContext context, LayoutController controller) {
    // 这里不使用 Obx，因为未直接依赖任何 Rx 变量
    if (controller.isMobile) {
      return _buildMobileLayout(context, controller);
    } else {
      return _buildDesktopLayout(context, controller);
    }
  }

  /// 构建移动端布局
  Widget _buildMobileLayout(BuildContext context, LayoutController controller) {
    return child;
  }

  /// 构建桌面端布局
  Widget _buildDesktopLayout(BuildContext context, LayoutController controller) {
    return Row(
      children: [
        // 侧边栏
        if (showSidebar) ...[
          const LayoutSidebar(),
          const LayoutSidebarResize(),
        ],
        
        // 主内容区域
        Expanded(
          child: Container(
            color: Theme.of(context).colorScheme.surface,
            child: child,
          ),
        ),
      ],
    );
  }
}
