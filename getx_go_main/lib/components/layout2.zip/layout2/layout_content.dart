
import 'package:flutter/material.dart';

import 'layout_content_header.dart';

/// 内容容器组件
class LayoutContent extends StatelessWidget {
  /// 子组件
  final Widget child;
  
  /// 内边距
  final EdgeInsetsGeometry? padding;
  
  /// 是否显示滚动条
  final bool scrollable;

  const LayoutContent({
    super.key,
    required this.child,
    this.padding,
    this.scrollable = true,
  });

  @override
  Widget build(BuildContext context) {
    Widget content = Container(
      padding: padding ?? const EdgeInsets.all(24),
      child: Column(
        children: [
          const LayoutContentHeader(),
          child,
        ],
      ),
    );

    if (scrollable) {
      content = SingleChildScrollView(
        child: content,
      );
    }

    return content;
  }
}