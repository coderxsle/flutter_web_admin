import 'dart:async';
import 'dart:io';

import 'package:flutter/services.dart';

import '../utils/common_widget/logger.dart';

class UmengHelper {
  static MethodChannel _channel = const MethodChannel('u-push-helper');

  static Future<void> agree() async {
    if (Platform.isAndroid) {
      //Logger.logMy("首次安装同意-友盟平台的 隐私政策");
      return await _channel.invokeMethod("agree");
    } else {
      return;
    }
  }

  static Future<bool?> isAgreed() async {
    if (Platform.isAndroid) {
      return await _channel.invokeMethod("isAgreed");
    } else {
      return false;
    }
  }

}
