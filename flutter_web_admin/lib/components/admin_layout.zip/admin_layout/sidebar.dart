import 'package:dang_gui_admin/components/layout/layout_menu_item.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'admin_layout_controller.dart';

/// 侧边栏组件
class AdminSidebar extends GetView<AdminLayoutController> {
  const AdminSidebar({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (!controller.isVisible) {
        return const SizedBox.shrink();
      }

      return AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: controller.currentSidebarWidth,
        child: Material(
          elevation: 2,
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              border: Border(
                right: BorderSide(
                  color: Theme.of(context).dividerColor,
                  width: 1,
                ),
              ),
            ),
            child: Column(
              children: [
                _buildHeader(context),
                Expanded(
                  child: _buildMenuList(context),
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  /// 构建头部
  Widget _buildHeader(BuildContext context) {
    return Container(
      height: 64,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Theme.of(context).dividerColor,
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          // Logo
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.admin_panel_settings,
              color: Colors.white,
              size: 20,
            ),
          ),
          if (controller.isExpanded) ...[
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Admin Panel',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
          // 收缩按钮
          IconButton(
            onPressed: controller.toggleSidebar,
            icon: Icon(
              controller.isExpanded ? Icons.menu_open : Icons.menu,
              size: 20,
            ),
            tooltip: controller.isExpanded ? '收缩菜单' : '展开菜单',
          ),
        ],
      ),
    );
  }

  /// 构建菜单列表
  Widget _buildMenuList(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: controller.menuItems.length,
      itemBuilder: (context, index) {
        final menuItem = controller.menuItems[index];
        return _buildMenuItem(context, menuItem);
      },
    );
  }

  /// 构建菜单项
  Widget _buildMenuItem(BuildContext context, MenuItem menuItem, {int level = 0}) {
    if (!menuItem.visible) {
      return const SizedBox.shrink();
    }

    if (menuItem.type == MenuItemType.group) {
      return _buildMenuGroup(context, menuItem, level);
    }

    return _buildMenuItemTile(context, menuItem, level);
  }

  /// 构建菜单分组
  Widget _buildMenuGroup(BuildContext context, MenuItem menuItem, int level) {
    final isExpanded = controller.expandedMenuIds.contains(menuItem.id);
    
    return Column(
      children: [
        // 分组标题
        if (controller.isExpanded && level == 0) ...[
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(16 + (level * 16), 16, 16, 8),
            child: Text(
              menuItem.title,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ),
        ] else if (controller.isExpanded) ...[
          // 子分组展开/收缩按钮
          _buildExpandableHeader(context, menuItem, level),
        ],
        
        // 子菜单列表
        if (controller.isExpanded || level > 0) ...[
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: isExpanded ? null : 0,
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 200),
              opacity: isExpanded ? 1.0 : 0.0,
              child: Column(
                children: menuItem.visibleChildren
                    .map((child) => _buildMenuItem(context, child, level: level + 1))
                    .toList(),
              ),
            ),
          ),
        ],
      ],
    );
  }

  /// 构建可展开的分组头部
  Widget _buildExpandableHeader(BuildContext context, MenuItem menuItem, int level) {
    final isExpanded = controller.expandedMenuIds.contains(menuItem.id);
    
    return InkWell(
      onTap: () => controller.toggleMenuExpanded(menuItem.id),
      child: Container(
        padding: EdgeInsets.fromLTRB(16 + (level * 16), 12, 16, 12),
        child: Row(
          children: [
            // 图标
            if (menuItem.icon != null) ...[
              _buildMenuIcon(context, menuItem),
              const SizedBox(width: 12),
            ],
            // 标题
            Expanded(
              child: Text(
                menuItem.title,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            // 展开图标
            Icon(
              isExpanded ? Icons.expand_less : Icons.expand_more,
              size: 20,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
            ),
          ],
        ),
      ),
    );
  }

  /// 构建菜单项瓦片
  Widget _buildMenuItemTile(BuildContext context, MenuItem menuItem, int level) {
    final isActive = controller.activeMenuId == menuItem.id;
    final hasChildren = menuItem.hasChildren;
    final isExpanded = controller.expandedMenuIds.contains(menuItem.id);

    return Column(
      children: [
        InkWell(
          onTap: () {
            if (hasChildren) {
              controller.toggleMenuExpanded(menuItem.id);
            } else {
              controller.navigateToMenu(menuItem);
            }
          },
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: isActive
                  ? Theme.of(context).primaryColor.withOpacity(0.1)
                  : null,
              borderRadius: BorderRadius.circular(8),
              border: isActive
                  ? Border.all(
                      color: Theme.of(context).primaryColor.withOpacity(0.3),
                      width: 1,
                    )
                  : null,
            ),
            child: Padding(
              padding: EdgeInsets.fromLTRB(
                8 + (level * 16),
                12,
                8,
                12,
              ),
              child: Row(
                children: [
                  // 图标
                  if (menuItem.icon != null) ...[
                    _buildMenuIcon(
                      context,
                      menuItem,
                      isActive: isActive,
                    ),
                    if (controller.isExpanded) const SizedBox(width: 12),
                  ],
                  
                  // 标题
                  if (controller.isExpanded) ...[
                    Expanded(
                      child: Text(
                        menuItem.title,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: isActive
                              ? Theme.of(context).primaryColor
                              : null,
                          fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    
                    // 展开图标
                    if (hasChildren) ...[
                      Icon(
                        isExpanded ? Icons.expand_less : Icons.expand_more,
                        size: 20,
                        color: isActive
                            ? Theme.of(context).primaryColor
                            : Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ],
                  ],
                ],
              ),
            ),
          ),
        ),
        
        // 子菜单
        if (hasChildren && controller.isExpanded) ...[
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: isExpanded ? null : 0,
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 200),
              opacity: isExpanded ? 1.0 : 0.0,
              child: Column(
                children: menuItem.visibleChildren
                    .map((child) => _buildMenuItem(context, child, level: level + 1))
                    .toList(),
              ),
            ),
          ),
        ],
      ],
    );
  }

  /// 构建菜单图标
  Widget _buildMenuIcon(
    BuildContext context,
    MenuItem menuItem, {
    bool isActive = false,
  }) {
    final color = isActive
        ? Theme.of(context).primaryColor
        : Theme.of(context).colorScheme.onSurface.withOpacity(0.7);

    // 如果是SVG图标
    if (menuItem.icon!.endsWith('.svg')) {
      return SvgPicture.asset(
        'assets/icons/${menuItem.icon}',
        width: 20,
        height: 20,
        // ignore: deprecated_member_use
        color: color,
      );
    }

    // Material图标
    return Icon(
      _getIconData(menuItem.icon!),
      size: 20,
      color: color,
    );
  }

  /// 根据字符串获取图标数据
  IconData _getIconData(String iconName) {
    switch (iconName) {
      case 'dashboard':
        return Icons.dashboard;
      case 'settings':
        return Icons.settings;
      case 'person':
        return Icons.person;
      case 'admin_panel_settings':
        return Icons.admin_panel_settings;
      case 'menu':
        return Icons.menu;
      case 'build':
        return Icons.build;
      case 'mic':
        return Icons.mic;
      case 'transcribe':
        return Icons.transcribe;
      case 'voice_chat':
        return Icons.voice_chat;
      case 'code':
        return Icons.code;
      default:
        return Icons.circle;
    }
  }

}

/// 侧边栏拖拽调整宽度组件
class SidebarResizeHandle extends GetView<AdminLayoutController> {
  const SidebarResizeHandle({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (!controller.isVisible || !controller.isExpanded) {
        return const SizedBox.shrink();
      }

      return MouseRegion(
        cursor: SystemMouseCursors.resizeColumn,
        child: GestureDetector(
          onPanUpdate: (details) {
            final newWidth = controller.sidebarWidth + details.delta.dx;
            controller.setSidebarWidth(newWidth);
          },
          child: Container(
            width: 4,
            height: double.infinity,
            color: Colors.transparent,
            child: Center(
              child: Container(
                width: 2,
                height: double.infinity,
                color: Theme.of(context).dividerColor.withOpacity(0.5),
              ),
            ),
          ),
        ),
      );
    });
  }
}
