一、背景
现状：每个页面在 app_pages.dart 显式配置中间件（登录/权限），动态页面接入成本高，容易遗漏。
目标：采用“壳路由（Layout 作为根外壳）+ 动态路由注册器”集中处理守卫，页面无需逐一声明中间件，同时兼容动态菜单/路由。
二、目标与范围
目标
使用 AdminLayout 作为统一壳路由承载业务页面。
将登录/权限校验收敛到“集中路由守卫 + 动态注册期统一注入”。
支持后端返回的动态菜单/路由无侵入接入。
范围内
路由结构重构为：受保护的父路由（/admin 或等价路径）+ 子路由（业务页）。
新增统一的“路由注册器”把后端 JSON 菜单→GetPage，自动注入权限元数据（或默认守卫）。
菜单渲染与权限过滤解耦：渲染时本地先过滤；路由层再兜底拦截。
范围外
具体业务页面的 UI/逻辑不变。
菜单数据结构的后端接口大改（仅补充必要字段）。
三、总体方案（架构）
壳路由（Shell）
定义一个受保护父路由（如 /admin），组件为 AdminLayout，所有业务页作为其 children（静态+动态）挂载。
登录/权限守卫优先挂在父路由（一次生效，子路由共享保护）。
动态路由注册器
暴露 registerPages(List<MenuRoute>)：把后端菜单 JSON 转为 GetPage 并 Get.addPages() 或替换路由表。
统一注入守卫/权限元数据（例如 meta.requiredPermissions / requiredRoles）。
维护白名单（如 /auth、/public/**）与外链（route.externalUrl）。
路由守卫（集中）
登录守卫：检查 token/登录态，未登录跳登录页，带 redirect。
权限守卫：根据 meta.requiredPermissions / requiredRoles 校验。
只在“壳路由 + 注册器注入阶段”处理，不需要每个页面写中间件。
全局兜底（可选）
routingCallback 只做异常兜底（防越权直达/非法路由），避免重复判定和循环跳转。
导航方式
菜单/按钮直接 Get.toNamed('/admin/xxx') 即可；无需强制统一封装 navigateTo。
仅当需要统一埋点/节流/外链等增强时再提供 navigateTo 包装（可选）。
四、权限与路由模型
权限模型
支持角色（role）与权限字符串（permission）。
权限元数据：挂在路由 meta 或注册器内部映射表。
路由结构
父：/admin（AdminLayout）
子：/admin/home、/admin/system/user、/admin/system/role…
外链：externalUrl 直接打开，不进入路由守卫。
白名单
/auth、/login、/403、/404 等。
五、动态路由来源
支持两种来源：
后端接口返回菜单/路由树（优先）
本地 JSON 兜底（开发/离线）
六、兼容与迁移
第一阶段（兼容期）
保留现有 AppPages.routes；新增壳路由 /admin。
已有页面逐步迁移为 /admin 的 children。
原页面中间件配置不删除，作为过渡；完成迁移后统一移除。
第二阶段（切换期）
启用动态注册器；将静态 pages 中对业务页的声明清理到 children。
保留 routingCallback 兜底，但仅做异常处理。
第三阶段（收尾）
移除散落的页面级中间件；以集中守卫为唯一口径。
七、数据契约（草案）
菜单/路由节点 MenuRoute
id: string
title: string
icon?: string | svg
route?: string（如 /admin/system/user）
externalUrl?: string
type: 'group' | 'item'
children?: MenuRoute[]
permissions?: string[]（访问所需权限）
roles?: string[]（访问所需角色）
sort?: number
约定：注册器以 permissions/roles → 路由 meta.requiredPermissions/requiredRoles。
八、验收标准
未登录访问 /admin/** 统一跳转登录，登录后按 redirect 回到原目标。
角色/权限不足时访问 /admin/** 跳转 403 页（或首页并提示）。
动态路由从后端返回后，一次性注册，刷新后可恢复。
菜单展示与可访问性一致：不可访问的路由不展示；直达拦截有效。
页面无需显式中间件；新增页面仅需注册到动态菜单即可生效。
九、风险与对策
风险：循环重定向
对策：兜底前判断目标是否已在登录/403，且 redirect 仅使用一次。
风险：动态路由注册时机
对策：首个受保护访问触发注册；注册后标记已生成。
风险：权限配置不一致（菜单 vs 路由）
对策：以注册器为唯一真源，菜单与路由使用同一数据对象/映射。
风险：外链/深链
对策：externalUrl 走浏览器，深链进入 /admin/** 走集中守卫。
十、测试用例（要点）
登录态：未登录访问 /admin/home、登录访问 /admin/home。
权限：有/无 user:view 访问用户页；有/无 role:view 访问角色页。
动态性：后台修改权限后刷新重载生效。
白名单：/login 可直达。
外链：菜单外链不受守卫约束。
十一、实施步骤与工期（建议）
第1天：注册器 & 模型定义；壳路由建立；集中守卫实现（登录/权限/白名单）
第2天：将现有路由迁移为 /admin children；接入注册器；处理外链
第3天：菜单渲染与权限过滤对齐；移除页面级中间件；兜底优化
第4天：联调后端菜单接口；完善测试用例；文档沉淀
是否确认按此文档推进？确认后我会：
按步骤改造路由结构与注册器；
保持你现有页面与 AdminLayout 兼容；
不改变现有页面 UI 与业务逻辑。