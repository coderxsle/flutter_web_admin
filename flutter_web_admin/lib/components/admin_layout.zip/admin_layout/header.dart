import 'package:dang_gui_admin/components/layout/layout_menu_item.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../models/menu_item.dart';
import 'admin_layout_controller.dart';

/// 头部导航组件
class AdminHeader extends GetView<AdminLayoutController> implements PreferredSizeWidget {
  const AdminHeader({super.key});

  @override
  Size get preferredSize => const Size.fromHeight(64);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Theme.of(context).colorScheme.surface,
      elevation: 1,
      shadowColor: Theme.of(context).shadowColor.withOpacity(0.1),
      leading: _buildLeading(context),
      title: _buildTitle(context),
      actions: _buildActions(context),
      automaticallyImplyLeading: false,
    );
  }

  /// 构建左侧按钮
  Widget? _buildLeading(BuildContext context) {
    if (controller.isMobile) {
      return IconButton(
        onPressed: controller.toggleSidebarVisibility,
        icon: const Icon(Icons.menu),
        tooltip: '显示菜单',
      );
    }
    return const SizedBox.shrink();
  }

  /// 构建标题区域
  Widget _buildTitle(BuildContext context) {
    return Obx(() {
      return Row(
        children: [
          Expanded(
            child: _buildBreadcrumb(context),
          ),
        ],
      );
    });
  }

  /// 构建面包屑导航
  Widget _buildBreadcrumb(BuildContext context) {
    final breadcrumbs = controller.breadcrumbsRx;
    
    if (breadcrumbs.isEmpty) {
      return const SizedBox.shrink();
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          // 首页图标
          Icon(
            Icons.home,
            size: 16,
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
          ),
          
          // 面包屑项
          ...breadcrumbs.asMap().entries.map((entry) {
            final index = entry.key;
            final breadcrumb = entry.value;
            final isLast = index == breadcrumbs.length - 1;
            
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 分隔符
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Icon(
                    Icons.chevron_right,
                    size: 16,
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
                  ),
                ),
                
                // 面包屑项
                InkWell(
                  onTap: isLast || breadcrumb.route == null
                      ? null
                      : () => Get.toNamed(breadcrumb.route!),
                  child: Text(
                    breadcrumb.title,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: isLast
                          ? Theme.of(context).primaryColor
                          : Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                      fontWeight: isLast ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                ),
              ],
            );
          }).toList(),
        ],
      ),
    );
  }

  /// 构建右侧操作按钮
  List<Widget> _buildActions(BuildContext context) {
    return [
      // 搜索按钮
      IconButton(
        onPressed: () {
          _showSearchDialog(context);
        },
        icon: const Icon(Icons.search),
        tooltip: '搜索菜单',
      ),
      
      // 通知按钮
      _buildNotificationButton(context),
      
      // 全屏按钮
      IconButton(
        onPressed: _toggleFullScreen,
        icon: const Icon(Icons.fullscreen),
        tooltip: '全屏',
      ),
      
      // 主题切换按钮（不使用 Obx，基于当前主题亮度）
      IconButton(
        onPressed: () {
          final isDark = Theme.of(context).brightness == Brightness.dark;
          Get.changeThemeMode(isDark ? ThemeMode.light : ThemeMode.dark);
        },
        icon: Icon(
          Theme.of(context).brightness == Brightness.dark
              ? Icons.light_mode
              : Icons.dark_mode,
        ),
        tooltip: Theme.of(context).brightness == Brightness.dark
            ? '浅色模式'
            : '深色模式',
      ),
      
      // 用户菜单
      _buildUserMenu(context),
      
      const SizedBox(width: 8),
    ];
  }

  /// 构建通知按钮
  Widget _buildNotificationButton(BuildContext context) {
    return Stack(
      children: [
        IconButton(
          onPressed: () {
            _showNotificationPanel(context);
          },
          icon: const Icon(Icons.notifications_outlined),
          tooltip: '通知',
        ),
        // 通知小红点
        Positioned(
          right: 8,
          top: 8,
          child: Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
      ],
    );
  }

  /// 构建用户菜单
  Widget _buildUserMenu(BuildContext context) {
    return PopupMenuButton<String>(
      onSelected: _handleUserMenuAction,
      itemBuilder: (context) => [
        const PopupMenuItem(
          value: 'profile',
          child: ListTile(
            leading: Icon(Icons.person),
            title: Text('个人资料'),
            dense: true,
            contentPadding: EdgeInsets.zero,
          ),
        ),
        const PopupMenuItem(
          value: 'settings',
          child: ListTile(
            leading: Icon(Icons.settings),
            title: Text('系统设置'),
            dense: true,
            contentPadding: EdgeInsets.zero,
          ),
        ),
        const PopupMenuDivider(),
        const PopupMenuItem(
          value: 'logout',
          child: ListTile(
            leading: Icon(Icons.logout, color: Colors.red),
            title: Text('退出登录', style: TextStyle(color: Colors.red)),
            dense: true,
            contentPadding: EdgeInsets.zero,
          ),
        ),
      ],
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 用户头像
            CircleAvatar(
              radius: 16,
              backgroundColor: Theme.of(context).primaryColor,
              child: const Text(
                'A',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 8),
            
            // 用户名（在较宽的屏幕上显示）
            if (Get.width > 600) ...[
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Admin',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    '管理员',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 4),
            ],
            
            const Icon(Icons.keyboard_arrow_down, size: 16),
          ],
        ),
      ),
    );
  }

  /// 处理用户菜单操作
  void _handleUserMenuAction(String action) {
    switch (action) {
      case 'profile':
        // 跳转到个人资料页面
        Get.snackbar('提示', '跳转到个人资料页面');
        break;
      case 'settings':
        // 跳转到系统设置页面
        Get.toNamed('/theme-settings');
        break;
      case 'logout':
        // 退出登录
        _showLogoutDialog();
        break;
    }
  }

  /// 显示搜索对话框
  void _showSearchDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => _SearchDialog(controller: controller),
    );
  }

  /// 显示通知面板
  void _showNotificationPanel(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => const _NotificationPanel(),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
    );
  }

  /// 切换全屏
  void _toggleFullScreen() {
    // 这里可以实现全屏切换逻辑
    Get.snackbar('提示', '全屏功能暂未实现');
  }

  /// 显示退出登录确认对话框
  void _showLogoutDialog() {
    Get.dialog(
      AlertDialog(
        title: const Text('确认退出'),
        content: const Text('您确定要退出登录吗？'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () {
              Get.back();
              // 执行退出登录逻辑
              Get.offAllNamed('/auth');
            },
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }
}

/// 搜索对话框
class _SearchDialog extends StatefulWidget {
  final AdminLayoutController controller;

  const _SearchDialog({required this.controller});

  @override
  State<_SearchDialog> createState() => _SearchDialogState();
}

class _SearchDialogState extends State<_SearchDialog> {
  final _searchController = TextEditingController();
  List<MenuItem> _searchResults = [];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    if (query.isEmpty) {
      setState(() {
        _searchResults = [];
      });
      return;
    }

    final results = <MenuItem>[];
    _searchMenuItems(widget.controller.menuItems, query, results);
    
    setState(() {
      _searchResults = results;
    });
  }

  void _searchMenuItems(List<MenuItem> items, String query, List<MenuItem> results) {
    for (var item in items) {
      if (item.title.toLowerCase().contains(query) && item.route != null) {
        results.add(item);
      }
      if (item.hasChildren) {
        _searchMenuItems(item.children!, query, results);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 500,
        height: 400,
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // 搜索框
            TextField(
              controller: _searchController,
              autofocus: true,
              decoration: InputDecoration(
                hintText: '搜索菜单...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // 搜索结果
            Expanded(
              child: _searchResults.isEmpty
                  ? Center(
                      child: Text(
                        _searchController.text.isEmpty
                            ? '输入关键词搜索菜单'
                            : '未找到相关菜单',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _searchResults.length,
                      itemBuilder: (context, index) {
                        final item = _searchResults[index];
                        return ListTile(
                          leading: Icon(Icons.menu),
                          title: Text(item.title),
                          subtitle: Text(item.route ?? ''),
                          onTap: () {
                            Get.back();
                            widget.controller.navigateToMenu(item);
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 通知面板
class _NotificationPanel extends StatelessWidget {
  const _NotificationPanel();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 400,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                '通知',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const Spacer(),
              TextButton(
                onPressed: () {},
                child: const Text('标记全部已读'),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          Expanded(
            child: ListView.builder(
              itemCount: 5,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
                    child: Icon(
                      Icons.notifications,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                  title: Text('通知标题 ${index + 1}'),
                  subtitle: Text('这是一条示例通知消息'),
                  trailing: Text(
                    '${index + 1}分钟前',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  onTap: () {},
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
