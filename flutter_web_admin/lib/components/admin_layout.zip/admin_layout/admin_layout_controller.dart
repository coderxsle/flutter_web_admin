import 'dart:async';
import 'package:get/get.dart';
import 'package:dang_gui_admin/components/layout/layout_menu_item.dart';

/// Admin Layout 控制器
class AdminLayoutController extends GetxController {
  /// 侧边栏是否展开
  final _isExpanded = true.obs;
  
  /// 侧边栏是否可见
  final _isVisible = true.obs;
  
  /// 当前激活的菜单ID
  final _activeMenuId = ''.obs;
  
  /// 展开的菜单ID列表
  final _expandedMenuIds = <String>[].obs;
  
  /// 菜单列表
  final _menuItems = <MenuItem>[].obs;
  
  /// 面包屑导航
  final _breadcrumbs = <BreadcrumbItem>[].obs;
  
  /// 侧边栏宽度
  final _sidebarWidth = 240.0.obs;
  
  /// 最小侧边栏宽度
  static const double minSidebarWidth = 60.0;
  
  /// 最大侧边栏宽度
  static const double maxSidebarWidth = 320.0;
  
  /// 响应式断点
  static const double mobileBreakpoint = 768.0;

  // Getters
  bool get isExpanded => _isExpanded.value;
  bool get isVisible => _isVisible.value;
  String get activeMenuId => _activeMenuId.value;
  List<String> get expandedMenuIds => _expandedMenuIds.toList();
  List<MenuItem> get menuItems => _menuItems.toList();
  List<BreadcrumbItem> get breadcrumbs => _breadcrumbs.toList();
  RxList<BreadcrumbItem> get breadcrumbsRx => _breadcrumbs;
  double get sidebarWidth => _sidebarWidth.value;
  
  /// 是否为移动端
  bool get isMobile => Get.width < mobileBreakpoint;
  
  /// 当前展开的侧边栏宽度
  double get currentSidebarWidth => isExpanded ? sidebarWidth : minSidebarWidth;

  @override
  void onInit() {
    super.onInit();
    _loadDefaultMenus();
    _listenToRouteChanges();
  }

  /// 切换侧边栏展开状态
  void toggleSidebar() {
    _isExpanded.value = !_isExpanded.value;
  }

  /// 设置侧边栏展开状态
  void setSidebarExpanded(bool expanded) {
    _isExpanded.value = expanded;
  }

  /// 切换侧边栏可见性
  void toggleSidebarVisibility() {
    _isVisible.value = !_isVisible.value;
  }

  /// 设置侧边栏可见性
  void setSidebarVisible(bool visible) {
    _isVisible.value = visible;
  }

  /// 设置侧边栏宽度
  void setSidebarWidth(double width) {
    if (width >= minSidebarWidth && width <= maxSidebarWidth) {
      _sidebarWidth.value = width;
    }
  }

  /// 设置菜单列表
  void setMenuItems(List<MenuItem> items) {
    _menuItems.value = items;
    _sortMenuItems();
  }

  /// 添加菜单项
  void addMenuItem(MenuItem item) {
    _menuItems.add(item);
    _sortMenuItems();
  }

  /// 移除菜单项
  void removeMenuItem(String id) {
    _menuItems.removeWhere((item) => item.id == id);
  }

  /// 设置激活的菜单
  void setActiveMenu(String menuId) {
    _activeMenuId.value = menuId;
    _updateBreadcrumbs(menuId);
  }

  /// 切换菜单展开状态
  void toggleMenuExpanded(String menuId) {
    if (_expandedMenuIds.contains(menuId)) {
      _expandedMenuIds.remove(menuId);
    } else {
      _expandedMenuIds.add(menuId);
    }
  }

  /// 设置菜单展开状态
  void setMenuExpanded(String menuId, bool expanded) {
    if (expanded) {
      if (!_expandedMenuIds.contains(menuId)) {
        _expandedMenuIds.add(menuId);
      }
    } else {
      _expandedMenuIds.remove(menuId);
    }
  }

  /// 导航到菜单
  void navigateToMenu(MenuItem menuItem) {
    if (menuItem.externalUrl != null) {
      // 处理外部链接
      // 这里可以使用 url_launcher 包打开外部链接
      return;
    }

    if (menuItem.route != null) {
      setActiveMenu(menuItem.id);
      Get.toNamed(menuItem.route!);
      
      // 在移动端，导航后自动隐藏侧边栏
      if (isMobile) {
        setSidebarVisible(false);
      }
    }
  }

  /// 根据路由查找菜单项
  MenuItem? findMenuByRoute(String route) {
    return _findMenuInList(_menuItems, route);
  }

  /// 在菜单列表中递归查找
  MenuItem? _findMenuInList(List<MenuItem> items, String route) {
    for (var item in items) {
      if (item.route == route) {
        return item;
      }
      if (item.hasChildren) {
        var found = _findMenuInList(item.children!, route);
        if (found != null) return found;
      }
    }
    return null;
  }

  /// 获取菜单路径（从根到当前菜单的路径）
  List<MenuItem> getMenuPath(String menuId) {
    List<MenuItem> path = [];
    _findMenuPath(_menuItems, menuId, path);
    return path;
  }

  /// 递归查找菜单路径
  bool _findMenuPath(List<MenuItem> items, String targetId, List<MenuItem> path) {
    for (var item in items) {
      path.add(item);
      if (item.id == targetId) {
        return true;
      }
      if (item.hasChildren) {
        if (_findMenuPath(item.children!, targetId, path)) {
          return true;
        }
      }
      path.removeLast();
    }
    return false;
  }

  /// 监听路由变化
  void _listenToRouteChanges() {
    // 初始化当前路由
    _updateCurrentRoute();
    
    // 使用定时器定期检查路由变化
    Timer.periodic(const Duration(milliseconds: 500), (timer) {
      _updateCurrentRoute();
    });
  }
  
  /// 更新当前路由
  void _updateCurrentRoute() {
    final currentRoute = Get.currentRoute;
    if (currentRoute.isNotEmpty) {
      var menuItem = findMenuByRoute(currentRoute);
      if (menuItem != null && _activeMenuId.value != menuItem.id) {
        setActiveMenu(menuItem.id);
        
        // 自动展开父菜单
        var path = getMenuPath(menuItem.id);
        for (var item in path) {
          if (item.hasChildren) {
            setMenuExpanded(item.id, true);
          }
        }
      }
    }
  }

  /// 更新面包屑导航
  void _updateBreadcrumbs(String menuId) {
    var path = getMenuPath(menuId);
    _breadcrumbs.value = path.map((item) => BreadcrumbItem(
      title: item.title,
      route: item.route,
    )).toList();
  }

  /// 对菜单项排序
  void _sortMenuItems() {
    _menuItems.sort((a, b) => a.sort.compareTo(b.sort));
    for (var item in _menuItems) {
      if (item.hasChildren) {
        item.children!.sort((a, b) => a.sort.compareTo(b.sort));
      }
    }
  }

  /// 加载默认菜单
  void _loadDefaultMenus() {
    final defaultMenus = [
      MenuItem(
        id: 'dashboard',
        title: '仪表盘',
        icon: 'dashboard',
        route: '/home',
        sort: 1,
      ),
      MenuItem(
        id: 'system',
        title: '系统管理',
        icon: 'settings',
        type: MenuItemType.group,
        sort: 2,
        children: [
          MenuItem(
            id: 'user-management',
            title: '用户管理',
            icon: 'person',
            route: '/second',
            sort: 1,
          ),
          MenuItem(
            id: 'role-management',
            title: '角色管理',
            icon: 'admin_panel_settings',
            route: '/three',
            sort: 2,
          ),
          MenuItem(
            id: 'menu-management',
            title: '菜单管理',
            icon: 'menu',
            route: '/theme-settings',
            sort: 3,
          ),
        ],
      ),
      MenuItem(
        id: 'tools',
        title: '工具',
        icon: 'build',
        type: MenuItemType.group,
        sort: 3,
        children: [
          MenuItem(
            id: 'recording',
            title: '录音工具',
            icon: 'mic',
            route: '/recording',
            sort: 1,
          ),
          MenuItem(
            id: 'realtime',
            title: '实时转写',
            icon: 'transcribe',
            route: '/realtime',
            sort: 2,
          ),
          MenuItem(
            id: 'funasr',
            title: 'FunASR',
            icon: 'voice_chat',
            route: '/funasr',
            sort: 3,
          ),
        ],
      ),
      MenuItem(
        id: 'demo',
        title: '演示页面',
        icon: 'code',
        route: '/demo',
        sort: 4,
      ),
      MenuItem(
        id: 'admin-demo',
        title: 'Admin Layout 演示',
        icon: 'dashboard',
        route: '/admin-demo',
        sort: 5,
      ),
    ];
    
    setMenuItems(defaultMenus);
  }
}

/// 面包屑导航项
class BreadcrumbItem {
  final String title;
  final String? route;

  const BreadcrumbItem({
    required this.title,
    this.route,
  });

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is BreadcrumbItem &&
        other.title == title &&
        other.route == route;
  }

  @override
  int get hashCode => title.hashCode ^ route.hashCode;
}
