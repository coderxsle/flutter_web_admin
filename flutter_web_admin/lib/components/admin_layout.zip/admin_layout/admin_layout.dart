import 'package:dang_gui_admin/components/layout/layout_menu_item.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../models/menu_item.dart';
import 'admin_layout_controller.dart';
import 'sidebar.dart';
import 'header.dart';

/// Admin Layout 主组件
class AdminLayout extends StatelessWidget {
  /// 主内容区域
  final Widget child;
  
  /// 是否显示头部导航
  final bool showHeader;
  
  /// 是否显示侧边栏
  final bool showSidebar;
  
  /// 自定义头部组件
  final PreferredSizeWidget? customHeader;

  const AdminLayout({
    super.key,
    required this.child,
    this.showHeader = true,
    this.showSidebar = true,
    this.customHeader,
  });

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AdminLayoutController>(
      builder: (controller) {
        return Scaffold(
          appBar: showHeader ? (customHeader ?? const AdminHeader()) : null,
          body: _buildBody(context, controller),
          drawer: controller.isMobile && showSidebar
              ? const AdminDrawer()
              : null,
          drawerScrimColor: Colors.black.withOpacity(0.3),
        );
      },
    );
  }

  /// 构建主体内容
  Widget _buildBody(BuildContext context, AdminLayoutController controller) {
    // 这里不使用 Obx，因为未直接依赖任何 Rx 变量
    if (controller.isMobile) {
      return _buildMobileLayout(context, controller);
    } else {
      return _buildDesktopLayout(context, controller);
    }
  }

  /// 构建移动端布局
  Widget _buildMobileLayout(BuildContext context, AdminLayoutController controller) {
    return child;
  }

  /// 构建桌面端布局
  Widget _buildDesktopLayout(BuildContext context, AdminLayoutController controller) {
    return Row(
      children: [
        // 侧边栏
        if (showSidebar) ...[
          const AdminSidebar(),
          const SidebarResizeHandle(),
        ],
        
        // 主内容区域
        Expanded(
          child: Container(
            color: Theme.of(context).colorScheme.background,
            child: child,
          ),
        ),
      ],
    );
  }
}

/// 移动端抽屉菜单
class AdminDrawer extends GetView<AdminLayoutController> {
  const AdminDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      width: 280,
      child: Column(
        children: [
          _buildDrawerHeader(context),
          Expanded(
            child: _buildMenuList(context),
          ),
          _buildDrawerFooter(context),
        ],
      ),
    );
  }

  /// 构建抽屉头部
  Widget _buildDrawerHeader(BuildContext context) {
    return DrawerHeader(
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Theme.of(context).primaryColor,
            Theme.of(context).primaryColor.withOpacity(0.8),
          ],
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.admin_panel_settings,
              color: Colors.white,
              size: 28,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Admin Panel',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '管理后台',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.white.withOpacity(0.8),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// 构建菜单列表
  Widget _buildMenuList(BuildContext context) {
    return Obx(() {
      return ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: controller.menuItems.length,
        itemBuilder: (context, index) {
          final menuItem = controller.menuItems[index];
          return _buildDrawerMenuItem(context, menuItem);
        },
      );
    });
  }

  /// 构建抽屉菜单项
  Widget _buildDrawerMenuItem(BuildContext context, MenuItem menuItem, {int level = 0}) {
    if (!menuItem.visible) {
      return const SizedBox.shrink();
    }

    if (menuItem.type == MenuItemType.group) {
      return _buildDrawerMenuGroup(context, menuItem, level);
    }

    return _buildDrawerMenuTile(context, menuItem, level);
  }

  /// 构建抽屉菜单分组
  Widget _buildDrawerMenuGroup(BuildContext context, MenuItem menuItem, int level) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // 分组标题
        if (level == 0) ...[
          Padding(
            padding: EdgeInsets.fromLTRB(16 + (level * 16), 16, 16, 8),
            child: Text(
              menuItem.title,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ),
        ] else ...[
          _buildDrawerExpandableTile(context, menuItem, level),
        ],
        
        // 子菜单
        Obx(() {
          final isExpanded = controller.expandedMenuIds.contains(menuItem.id);
          return AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: isExpanded || level == 0 ? null : 0,
            child: Column(
              children: menuItem.visibleChildren
                  .map((child) => _buildDrawerMenuItem(context, child, level: level + 1))
                  .toList(),
            ),
          );
        }),
      ],
    );
  }

  /// 构建抽屉可展开瓦片
  Widget _buildDrawerExpandableTile(BuildContext context, MenuItem menuItem, int level) {
    return Obx(() {
      final isExpanded = controller.expandedMenuIds.contains(menuItem.id);
      
      return ListTile(
        contentPadding: EdgeInsets.fromLTRB(16 + (level * 16), 4, 16, 4),
        leading: menuItem.icon != null
            ? Icon(_getIconData(menuItem.icon!))
            : null,
        title: Text(menuItem.title),
        trailing: Icon(
          isExpanded ? Icons.expand_less : Icons.expand_more,
        ),
        onTap: () => controller.toggleMenuExpanded(menuItem.id),
      );
    });
  }

  /// 构建抽屉菜单瓦片
  Widget _buildDrawerMenuTile(BuildContext context, MenuItem menuItem, int level) {
    return Obx(() {
      final isActive = controller.activeMenuId == menuItem.id;
      
      return ListTile(
        contentPadding: EdgeInsets.fromLTRB(16 + (level * 16), 4, 16, 4),
        leading: menuItem.icon != null
            ? Icon(
                _getIconData(menuItem.icon!),
                color: isActive ? Theme.of(context).primaryColor : null,
              )
            : null,
        title: Text(
          menuItem.title,
          style: TextStyle(
            color: isActive ? Theme.of(context).primaryColor : null,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
        selected: isActive,
        selectedTileColor: Theme.of(context).primaryColor.withOpacity(0.1),
        onTap: () {
          if (menuItem.hasChildren) {
            controller.toggleMenuExpanded(menuItem.id);
          } else {
            controller.navigateToMenu(menuItem);
            Navigator.of(context).pop(); // 关闭抽屉
          }
        },
      );
    });
  }

  /// 根据字符串获取图标数据
  IconData _getIconData(String iconName) {
    switch (iconName) {
      case 'dashboard':
        return Icons.dashboard;
      case 'settings':
        return Icons.settings;
      case 'person':
        return Icons.person;
      case 'admin_panel_settings':
        return Icons.admin_panel_settings;
      case 'menu':
        return Icons.menu;
      case 'build':
        return Icons.build;
      case 'mic':
        return Icons.mic;
      case 'transcribe':
        return Icons.transcribe;
      case 'voice_chat':
        return Icons.voice_chat;
      case 'code':
        return Icons.code;
      default:
        return Icons.circle;
    }
  }

  /// 构建抽屉底部
  Widget _buildDrawerFooter(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color: Theme.of(context).dividerColor,
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'v1.0.0',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).pop();
              Get.toNamed('/theme-settings');
            },
            icon: const Icon(Icons.settings, size: 20),
            tooltip: '设置',
          ),
        ],
      ),
    );
  }
}

/// 内容容器组件
class AdminContent extends StatelessWidget {
  /// 子组件
  final Widget child;
  
  /// 内边距
  final EdgeInsetsGeometry? padding;
  
  /// 是否显示滚动条
  final bool scrollable;

  const AdminContent({
    super.key,
    required this.child,
    this.padding,
    this.scrollable = true,
  });

  @override
  Widget build(BuildContext context) {
    Widget content = Container(
      padding: padding ?? const EdgeInsets.all(24),
      child: child,
    );

    if (scrollable) {
      content = SingleChildScrollView(
        child: content,
      );
    }

    return content;
  }
}
