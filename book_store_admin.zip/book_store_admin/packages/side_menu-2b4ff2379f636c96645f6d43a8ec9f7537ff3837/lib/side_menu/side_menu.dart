export 'side_menu_controller.dart';
export 'menu_item_model.dart';
export 'menu_level_one.dart';
import 'package:flutter/material.dart';
import 'side_menu_controller.dart';
import 'menu_item_model.dart';
import 'menu_level_one.dart';

class SideMenu extends StatefulWidget {
  final String? title;
  final List<MenuItemModel> menuItems;
  final double width;
  final Color backgroundColor;
  final Color selectedColor;
  final Color hoverColor;
  final Color textColor;
  final Color selectedTextColor;
  final double collapsedWidth;
  final double collapseThreshold;
  final SideMenuController? controller;
  
  const SideMenu({
    super.key,
    this.title,
    required this.menuItems,
    this.width = 250,
    this.backgroundColor = const Color(0xFF2A3F54),
    this.selectedColor = const Color(0xFF1ABB9C),
    this.hoverColor = const Color(0xFF374A5E),
    this.textColor = Colors.white70,
    this.selectedTextColor = Colors.white,
    this.collapsedWidth = 80,
    this.collapseThreshold = 800,
    this.controller,
  });

  @override
  State<SideMenu> createState() => _SideMenuState();
}

class _SideMenuState extends State<SideMenu> {
  late final SideMenuController controller;
  bool isCollapsed = false;

  @override
  void initState() {
    super.initState();
    controller = widget.controller ?? SideMenuController(
      menuItems: widget.menuItems,
      onStateChanged: () => setState(() {}),
    );
    
    // 添加监听以确保状态更新时刷新组件
    controller.addListener(() {
      if (mounted) {
        setState(() {
          // 菜单状态发生变化时刷新UI
        });
      }
    });
  }
  
  @override
  void dispose() {
    // 移除监听器，避免内存泄漏
    if (widget.controller == null) {
      // 只有在内部创建的controller才需要移除监听器
      controller.removeListener(() {});
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // 监听屏幕宽度，决定是否折叠菜单
    final screenWidth = MediaQuery.of(context).size.width;
    isCollapsed = screenWidth < widget.collapseThreshold;
    
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: isCollapsed ? widget.collapsedWidth : widget.width,
      color: widget.backgroundColor,
      curve: Curves.easeInOut,
      child: Column(
        children: [
          // 菜单头部
          Container(
            padding: const EdgeInsets.symmetric(vertical: 20),
            alignment: Alignment.center,
            child: isCollapsed 
                ? Icon(
                    Icons.menu,
                    color: widget.selectedTextColor,
                    size: 24,
                  )
                : Text(
                    widget.title ?? '后台管理系统',
                    style: TextStyle(
                      color: widget.selectedTextColor,
                      fontSize:18, 
                    ),
                  ),
          ),
          
          // 菜单项列表
          Expanded(
            child: ListView.builder(
              itemCount: widget.menuItems.length,
              itemBuilder: (context, index) {
                return MenuLevelOne(
                  menuItem: widget.menuItems[index],
                  selectedColor: widget.selectedColor,
                  hoverColor: widget.hoverColor,
                  textColor: widget.textColor,
                  selectedTextColor: widget.selectedTextColor,
                  controller: controller,
                  isCollapsed: isCollapsed,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}