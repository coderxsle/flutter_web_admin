import 'package:flutter/material.dart';

MenuItemModel item(String title, String id, IconData icon, String route, {List<MenuItemModel>? children}) {
  return MenuItemModel(id: id, title: title, icon: icon, route: route, children: children ?? []);
}

class MenuItemModel {
  final String id;
  final String title;
  final IconData icon;
  final List<MenuItemModel> children;
  final String? route;

  MenuItemModel({
    required this.id,
    required this.title,
    required this.icon,
    this.children = const [],
    this.route,
  });

  bool get hasChildren => children.isNotEmpty;
  bool get isLeaf => children.isEmpty;
}