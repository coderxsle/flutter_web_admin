import 'package:flutter/material.dart';
import 'side_menu_controller.dart';
import 'menu_item_model.dart';

class MenuLevelThree extends StatefulWidget {
  final MenuItemModel menuItem;
  final Color selectedColor;
  final Color hoverColor;
  final Color textColor;
  final Color selectedTextColor;
  final SideMenuController controller;
  final VoidCallback? onMenuItemClick;
  
  const MenuLevelThree({
    super.key,
    required this.menuItem,
    required this.selectedColor,
    required this.hoverColor,
    required this.textColor,
    required this.selectedTextColor,
    required this.controller,
    this.onMenuItemClick,
  });

  @override
  State<MenuLevelThree> createState() => _MenuLevelThreeState();
}

class _MenuLevelThreeState extends State<MenuLevelThree> {
  bool isHovered = false;

  @override
  Widget build(BuildContext context) {
    final isSelected = widget.controller.isMenuItemSelected(widget.menuItem.id);
    
    // 定义颜色，确保悬停颜色足够明显
    final effectiveHoverColor = Color.lerp(widget.hoverColor, widget.selectedColor, 0.3);
    
    return MouseRegion(
      onEnter: (event) {
        setState(() {
          isHovered = true;
        });
      },
      onExit: (event) {
        setState(() {
          isHovered = false;
        });
      },
      child: InkWell(
        onTap: () {
          // 只选择菜单项，不要关闭overlay
          widget.controller.selectMenuItem(widget.menuItem.id, route: widget.menuItem.route);
          
          // 不再调用关闭菜单的回调
          // if (widget.onMenuItemClick != null) {
          //   widget.onMenuItemClick!();
          // }
          
          // 强制更新状态
          setState(() {});
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          decoration: BoxDecoration(
            color: isSelected 
                ? widget.selectedColor 
                : (isHovered ? effectiveHoverColor : null),
            border: isHovered && !isSelected
                ? Border(
                    left: BorderSide(
                      color: widget.selectedColor,
                      width: 3,
                    ),
                  )
                : null,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(
            children: [
              Icon(
                widget.menuItem.icon,
                size: 16,
                color: isSelected ? widget.selectedTextColor : widget.textColor,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  widget.menuItem.title,
                  style: TextStyle(
                    color: isSelected ? widget.selectedTextColor : widget.textColor,
                    fontSize: 14,
                    fontWeight: isHovered ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}