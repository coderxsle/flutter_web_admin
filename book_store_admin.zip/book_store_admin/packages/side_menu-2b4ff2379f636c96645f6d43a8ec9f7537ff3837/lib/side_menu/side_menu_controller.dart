import 'menu_item_model.dart';

// 保存当前展开的菜单ID，确保在页面重建后能够恢复
String? _globalExpandedLevelOneId;

class SideMenuController {
  // 当前展开的一级菜单ID
  String? get expandedLevelOneId => _globalExpandedLevelOneId;
  set expandedLevelOneId(String? id) {
    _globalExpandedLevelOneId = id;
    onStateChanged();
    _notifyListeners();
  }
  
  // 当前选中的菜单项ID
  String? selectedMenuId;
  
  // 当前悬停的二级菜单ID
  String? hoveredLevelTwoId;
  
  // 菜单数据
  final List<MenuItemModel> menuItems;
  
  // 状态更新回调
  final Function() onStateChanged;
  
  // 额外的监听器列表，用于通知状态变化
  final List<Function()> _listeners = [];
  
  SideMenuController({
    required this.menuItems,
    required this.onStateChanged,
  });
  
  // 添加一个额外的监听器
  void addListener(Function() listener) {
    _listeners.add(listener);
  }
  
  // 移除一个监听器
  void removeListener(Function() listener) {
    _listeners.remove(listener);
  }
  
  // 通知所有额外的监听器
  void _notifyListeners() {
    for (final listener in _listeners) {
      listener();
    }
  }
  
  // 切换一级菜单展开状态
  void toggleLevelOne(String id) {
    if (expandedLevelOneId == id) {
      expandedLevelOneId = null;
      print('关闭菜单: $id');
    } else {
      expandedLevelOneId = id;
      print('展开菜单: $id');
    }
    onStateChanged();
    _notifyListeners();
  }
  
  // 选择菜单项
  void selectMenuItem(String id, {String? route}) {
    selectedMenuId = id;
    
    // 查找所选菜单项的父级菜单，并确保展开状态
    for (final menuItem in menuItems) {
      // 检查当前菜单项
      if (menuItem.id == id) {
        // 如果选择的是一级菜单项，不做特殊处理
        break;
      }
      
      // 检查二级菜单
      for (final childItem in menuItem.children) {
        if (childItem.id == id) {
          // 找到了选中的二级菜单项，确保其父级菜单保持展开
          expandedLevelOneId = menuItem.id;
          print('选中二级菜单: $id, 保持父菜单展开: ${menuItem.id}');
          break;
        }
        
        // 检查三级菜单
        for (final grandChildItem in childItem.children) {
          if (grandChildItem.id == id) {
            // 找到了选中的三级菜单项，确保其祖父级菜单保持展开
            expandedLevelOneId = menuItem.id;
            hoveredLevelTwoId = childItem.id;
            print('选中三级菜单: $id, 保持父菜单展开: ${menuItem.id}, 二级菜单: ${childItem.id}');
            break;
          }
        }
      }
    }
    
    onStateChanged();
    _notifyListeners();
  }
  
  // 设置悬停的二级菜单
  void setHoveredLevelTwo(String? id) {
    hoveredLevelTwoId = id;
    onStateChanged();
    _notifyListeners();
  }
  
  // 检查一级菜单是否展开
  bool isLevelOneExpanded(String id) {
    return expandedLevelOneId == id;
  }
  
  // 检查菜单项是否被选中
  bool isMenuItemSelected(String id) {
    return selectedMenuId == id;
  }
  
  // 检查菜单项是否有被选中的子菜单（递归）
  bool hasSelectedChild(MenuItemModel menuItem) {
    if (menuItem.children.isEmpty) {
      return false;
    }
    
    for (final child in menuItem.children) {
      if (isMenuItemSelected(child.id)) {
        return true;
      }
      
      if (hasSelectedChild(child)) {
        return true;
      }
    }
    
    return false;
  }
  
  // 检查二级菜单是否被悬停
  bool isLevelTwoHovered(String id) {
    return hoveredLevelTwoId == id;
  }
}