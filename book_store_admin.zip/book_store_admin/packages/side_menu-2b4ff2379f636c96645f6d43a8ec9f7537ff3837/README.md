# Side Menu

[中文文档](README.zh.md)

A powerful and customizable Flutter sidebar menu component for admin dashboards, control panels, and similar applications.

## Features

- Support for multi-level nested menu structure (up to three levels)
- Collapsible/expandable interaction design
- Fully customizable styles and themes
- Hover effects and selection states
- Responsive design for different screen sizes
- Simple and easy-to-use API

## Preview
![Example](example/iShot_2025-03-05_11.12.21.gif)
![Example](example/iShot_2025-03-05_10.26.47.gif)

## Installation

Add the dependency to your `pubspec.yaml` file:

```yaml
dependencies:
  side_menu: ^0.0.1
```

Or using Git repository:

```yaml
dependencies:
  side_menu:
    git:
      url: https://gitee.com/coderxsle/side_menu.git
```

## Usage

### Basic Usage

```dart
import 'package:flutter/material.dart';
import 'package:side_menu/side_menu.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SideMenu(
          title: 'Admin Console',
          menuItems: items,
        ),
      ),
    );
  }

  List<MenuItemModel> items() {
    return [
      item('Dashboard', 'dashboard', Icons.dashboard, '/dashboard'),
      item('User Management', 'user_management', Icons.people, '/users/list', children: [
        item('User List', 'user_roles', Icons.security, '/users/roles/admin'),
        item('Permissions', 'user_permissions', Icons.lock, '/users/permissions', children: [
          item('User Permissions', 'user_permissions', Icons.lock, '/users/permissions/user'),
          item('User Role', 'role_permissions', Icons.lock, '/users/permissions/role'),
        ]),
      ]),
    ];
  }
}
```

### Using Controller

```dart
final menuController = SideMenuController(
  menuItems: yourMenuItems,
  onStateChanged: () {
    // Handle menu state changes
    print('Selected menu ID: ${menuController.selectedMenuId}');
  },
);

// Then use it in SideMenu
SideMenu(
  menuItems: yourMenuItems,
  controller: menuController,
)

// Manually control selected item
menuController.selectMenuItem('dashboard');

// Toggle menu expansion/collapse
menuController.toggleMenu();
```

### Custom Styling

```dart
SideMenu(
  menuItems: yourMenuItems,
  width: 250,                                     // Menu width
  backgroundColor: const Color(0xFF2A3F54),       // Background color
  selectedColor: const Color(0xFF1ABB9C),         // Selected background color
  hoverColor: const Color(0xFF374A5E),            // Hover background color
  textColor: Colors.white70,                      // Text color
  selectedTextColor: Colors.white,                // Selected text color
  collapsedWidth: 60,                             // Collapsed width
)
```

## Configuration Options

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| menuItems | List<MenuItemModel> | Required | List of menu items |
| title | String | Empty string | Menu title |
| width | double | 250 | Width when expanded |
| backgroundColor | Color | Color(0xFF2A3F54) | Menu background color |
| selectedColor | Color | Color(0xFF1ABB9C) | Selected item background color |
| hoverColor | Color | Color(0xFF374A5E) | Hover item background color |
| textColor | Color | Colors.white70 | Text color |
| selectedTextColor | Color | Colors.white | Selected item text color |
| collapsedWidth | double | 60 | Width when collapsed |
| controller | SideMenuController | null | Menu controller |

## Menu Item Configuration

Use `MenuItemModel` to define the menu structure:

```dart
MenuItemModel({
  required String id,           // Unique identifier
  required String title,        // Menu title
  required IconData icon,       // Menu icon
  List<MenuItemModel> children = const [], // Child menu items
  String? route,                // Associated route
})
```

## Example Project

Check the [example](https://gitee.com/coderxsle/side_menu/tree/master/example) directory for a complete sample application.

## License

This project is licensed under the MIT License