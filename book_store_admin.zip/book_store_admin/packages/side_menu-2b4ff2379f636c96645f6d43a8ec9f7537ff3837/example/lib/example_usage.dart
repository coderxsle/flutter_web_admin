import 'package:flutter/material.dart';
import 'package:side_menu/side_menu.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  late SideMenuController _menuController;
  String _currentRoute = '/dashboard';
  
  @override
  void initState() {
    super.initState();
    _menuController = SideMenuController(
      menuItems: _getMenuItems(),
      onStateChanged: () {
        if (_menuController.selectedMenuId != null) {
          // 查找选中菜单项的路由
          final route = _findRouteById(_menuController.selectedMenuId!);
          if (route != null) {
            setState(() {
              _currentRoute = route;
            });
          }
        }
      },
    );
    
    // 默认选中仪表盘
    _menuController.selectMenuItem('dashboard', route: '/dashboard');
  }
  
  // 根据ID查找菜单项的路由
  String? _findRouteById(String id, [List<MenuItemModel>? items]) {
    items ??= _getMenuItems();
    
    for (final item in items) {
      if (item.id == id) {
        return item.route;
      }
      
      if (item.hasChildren) {
        final childRoute = _findRouteById(id, item.children);
        if (childRoute != null) {
          return childRoute;
        }
      }
    }
    
    return null;
  }
  
  // 获取菜单数据
  List<MenuItemModel> _getMenuItems() {
    return [
      item('仪表盘', 'dashboard', Icons.dashboard, '/dashboard'),
      item('用户管理', 'user_management', Icons.people, '/users/list', children: [
        item('用户角色', 'user_roles', Icons.security, '/users/roles/admin'),
        item('客户角色', 'customer_roles', Icons.person, '/users/roles/customer'),
        item('员工角色', 'staff_roles', Icons.badge, '/users/roles/staff'),
        item('权限设置', 'user_permissions', Icons.lock, '/users/permissions', children: [
          item('用户权限', 'user_permissions', Icons.lock, '/users/permissions/user'),
          item('角色权限', 'role_permissions', Icons.lock, '/users/permissions/role'),
        ]),
      ]),
      item('系统设置', 'settings', Icons.settings, '/settings'),
      item('媒体管理', 'media', Icons.perm_media, '/content/media', children: [
        item('文章列表', 'article_list', Icons.list, '/content/articles/list'),
        item('文章分类', 'article_categories', Icons.category, '/content/articles/categories'),
        item('文章标签', 'article_tags', Icons.tag, '/content/articles/tags'),
      ]),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // 侧边菜单
          SideMenu(
            title: '后台管理系统',
            menuItems: _getMenuItems(),
            controller: _menuController,
          ),
          // 主内容区域
          Expanded(
            child: Container(
              color: Colors.grey[100],
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 面包屑导航
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 5,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.home, size: 22),
                        const SizedBox(width: 8),
                        Text(
                          _currentRoute.replaceAll('/', ' > ').substring(3),
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  // 内容区域
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 5,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '当前页面: $_currentRoute',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            '这里是页面内容区域，根据选择的菜单项显示不同的内容。',
                            style: TextStyle(fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}