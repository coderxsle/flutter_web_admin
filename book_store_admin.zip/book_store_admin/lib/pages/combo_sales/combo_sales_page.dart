import 'package:flutter/material.dart';

class ComboSalesPage extends StatelessWidget {
  const ComboSalesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('组合销售记录页面'),
    );
  }
} 