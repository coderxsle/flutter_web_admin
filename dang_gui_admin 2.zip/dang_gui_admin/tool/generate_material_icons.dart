import 'dart:io';

/// 解析 Flutter SDK icons.dart，生成 lib/generated/material_icons.g.dart
/// 用法：
///   dart run tool/generate_material_icons.dart [可选:icons.dart绝对路径]
Future<void> main(List<String> args) async {
  final String? customPath = args.isNotEmpty ? args.first : null;
  final File iconsFile = await _locateIconsDart(customPath);
  if (!await iconsFile.exists()) {
    stderr.writeln('icons.dart 未找到: ${iconsFile.path}');
    exit(1);
  }

  final String source = await iconsFile.readAsString();
  final RegExp reg = RegExp(
    r"static const IconData\s+([a-z0-9_]+)\s*=\s*IconData\((0x[0-9a-fA-F]+)(?:,[^;]*matchTextDirection:\s*(true|false))?[^;]*\);",
    multiLine: true,
  );

  final Map<String, _IconRecord> icons = {};
  for (final match in reg.allMatches(source)) {
    final String name = match.group(1)!;
    final String hex = match.group(2)!;
    final String? mtd = match.group(3);
    final int codePoint = int.parse(hex);
    icons[name] = _IconRecord(
      name: name,
      codePoint: codePoint,
      matchTextDirection: mtd == 'true',
    );
  }

  if (icons.isEmpty) {
    stderr.writeln('未解析到任何 IconData。请检查 SDK 路径。');
    exit(2);
  }

  final String out = _buildDart(icons);
  final outFile = File('lib/generated/material_icons.g.dart');
  await outFile.create(recursive: true);
  await outFile.writeAsString(out);
  stdout.writeln('已生成: ${outFile.path} (共 ${icons.length} 个图标)');
}

Future<File> _locateIconsDart(String? customPath) async {
  if (customPath != null && customPath.isNotEmpty) return File(customPath);

  // 优先使用环境变量 FLUTTER_ROOT
  final flutterRoot = Platform.environment['FLUTTER_ROOT'];
  if (flutterRoot != null && flutterRoot.isNotEmpty) {
    final path = '$flutterRoot/packages/flutter/lib/src/material/icons.dart';
    final f = File(path);
    if (await f.exists()) return f;
  }

  // 尝试 FVM 常见路径
  final home = Platform.environment['HOME'] ?? '';
  final fvmDir = Directory('$home/.fvm/versions');
  if (await fvmDir.exists()) {
    final versions = await fvmDir
        .list()
        .where((e) => File('${e.path}/packages/flutter/lib/src/material/icons.dart').existsSync())
        .toList();
    versions.sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    for (final e in versions) {
      final candidate = File('${e.path}/packages/flutter/lib/src/material/icons.dart');
      if (await candidate.exists()) return candidate;
    }
  }

  // 兜底: 通过 which flutter 推断
  try {
    final which = await Process.run('which', ['flutter']);
    final out = (which.stdout as String?)?.trim() ?? '';
    if (out.isNotEmpty) {
      // out 形如 /path/to/flutter/bin/flutter -> 去掉 /bin/flutter
      final flutterBin = File(out);
      final rootDir = flutterBin.parent.parent.path; // ../.. 上两级
      final f = File('$rootDir/packages/flutter/lib/src/material/icons.dart');
      if (await f.exists()) return f;
    }
  } catch (_) {}

  // 项目内相对路径（多数情况下不存在）
  return File('packages/flutter/lib/src/material/icons.dart');
}

String _buildDart(Map<String, _IconRecord> icons) {
  final buffer = StringBuffer();
  buffer.writeln('// GENERATED CODE - DO NOT MODIFY BY HAND');
  buffer.writeln("import 'package:flutter/widgets.dart';");
  buffer.writeln('');
  buffer.writeln('/// Flutter SDK Material Icons 自动生成的映射');
  buffer.writeln('const Map<String, IconData> kMaterialIcons = <String, IconData>{');
  final names = icons.keys.toList()..sort();
  for (final name in names) {
    final i = icons[name]!;
    final mtd = i.matchTextDirection ? ', matchTextDirection: true' : '';
    buffer.writeln("  '$name': IconData(${i.codePoint}, fontFamily: 'MaterialIcons'$mtd),");
  }
  buffer.writeln('};');
  buffer.writeln('');
  buffer.writeln('const List<String> kMaterialIconNames = [');
  for (final name in names) {
    buffer.writeln("  '$name',");
  }
  buffer.writeln('];');
  return buffer.toString();
}

class _IconRecord {
  final String name;
  final int codePoint;
  final bool matchTextDirection;
  _IconRecord({required this.name, required this.codePoint, required this.matchTextDirection});
}
