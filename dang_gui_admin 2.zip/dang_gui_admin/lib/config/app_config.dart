


const String appName = "盛邦议录";
const String appNameEn = "Voice Note";
const String appNameIntro = "让每一次会议都有完整记录 \n 智能语音转写与纪要助手";

const String iosAppID = "6779000000";



// 初始化动画控制器
const int animationDuration = 1000;
const int waitLoadingFontsDuration = 2000;
const int animationIntroWaitDuration = 2000;



const String baseURL = "http://192.168.0.57:9099";
const String baseURLTest = "http://116.205.108.41:18000";

const String funasrBaseURL = "ws://192.168.100.7:10096";
const String funasrBaseURL1 = "ws://192.168.100.7:10096";
const String funasrBaseURL2 = "ws://192.168.100.7:10096";



// 实时转写服务地址
const String realtimeURL = "ws://192.168.0.57:9099";





// const String baseURL = "http://116.205.108.41:18000";
// const String baseURLTest = "http://116.205.108.41:18000";

// const String baseURL = "http://192.168.100.135:9099/dev-api";
// const String baseURLTest = "http://222.222.17.184:8181";

const String iOSAppStoreURL = "https://itunes.apple.com/cn/app/$iosAppID";

