import 'package:get_storage/get_storage.dart';

class Global {
  static final _box = GetStorage();
  static const _tokenKey = 'token';
  static const _userInfoKey = 'userInfo';

  // 获取Token
  static String? getToken() {
    return _box.read<String>(_tokenKey);
  }

  // 设置Token
  static Future<void> setToken(String token) async {
    await _box.write(_tokenKey, token);
  }

  // 清除Token
  static Future<void> clearToken() async {
    await _box.remove(_tokenKey);
  }

  // 获取用户信息
  static Map<String, dynamic>? getUserInfo() {
    return _box.read<Map<String, dynamic>>(_userInfoKey);
  }

  // 设置用户信息
  static Future<void> setUserInfo(Map<String, dynamic> userInfo) async {
    await _box.write(_userInfoKey, userInfo);
  }

  // 清除用户信息
  static Future<void> clearUserInfo() async {
    await _box.remove(_userInfoKey);
  }

  // 清除所有数据
  static Future<void> clearAll() async {
    await _box.erase();
  }

  // 判断是否已登录
  static bool isLoggedIn() {
    return getToken() != null;
  }
} 