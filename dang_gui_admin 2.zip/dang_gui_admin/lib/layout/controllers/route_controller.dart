/// @file RouteController 路由状态管理器
/// @description 管理应用路由状态，适配新的 Router 2.0 系统
import 'package:get/get.dart';
import '../../logger.dart';
import '../../routes/app_router_config.dart';
import '../../routes/app_route_state.dart';
import '../../routes/app_router_delegate.dart';
import '../models/route_record.dart';

/// 路由状态管理器
class RouteController extends GetxController {
  /// 路由配置管理器
  final AppRouterConfig _routerConfig = AppRouterConfig();
  
  /// 路由委托（用于程序化导航）
  AppRouterDelegate? _routerDelegate;
  
  /// 当前路由状态
  final Rx<AppRouteState> _currentRouteState = AppRouteState.defaultRoute().obs;
  AppRouteState get currentRouteState => _currentRouteState.value;
  
  /// 获取当前路由状态的响应式对象（用于监听）
  Rx<AppRouteState> get currentRouteStateRx => _currentRouteState;
  
  /// 当前路径（兼容旧代码）
  String get currentPath => _currentRouteState.value.path;
  
  /// 当前路径的响应式对象（兼容旧代码）
  Rx<String> get currentPathRx => _currentRouteState.value.path.obs;
  
  /// 路由历史记录
  final RxList<AppRouteState> _routeHistory = <AppRouteState>[].obs;
  List<AppRouteState> get routeHistory => _routeHistory;
  
  /// 路由查找缓存
  final Map<String, RouteConfig?> _routeCache = {};
  final Map<String, List<RouteConfig>> _hierarchyCache = {};
  
  /// 设置路由委托
  void setRouterDelegate(AppRouterDelegate delegate) {
    _routerDelegate = delegate;
  }

  /// 初始化路由
  @override
  void onInit() {
    super.onInit();
    _initializeRouteState();
  }

  /// 初始化路由状态
  void _initializeRouteState() {
    // 监听当前路由变化
    ever(_currentRouteState, (AppRouteState state) {
      _onRouteStateChanged(state);
    });
    
    // 初始化默认路由状态
    updateCurrentRoute('/home');
  }

  /// 路由状态变化回调
  void _onRouteStateChanged(AppRouteState state) {
    // 添加到历史记录
    if (_routeHistory.isEmpty || _routeHistory.last.path != state.path) {
      _routeHistory.add(state);
      
      // 限制历史记录长度
      if (_routeHistory.length > 50) {
        _routeHistory.removeAt(0);
      }
    }
    
    logger.d('🚀 [RouteController] Route state changed: ${state.path}');
  }

  /// 更新当前路由
  void updateCurrentRoute(String path, {
    Map<String, String>? queryParams,
    Map<String, String>? pathParams,
  }) {
    final routeConfig = _routerConfig.findRouteByPath(path);
    
    final newState = AppRouteState(
      path: path,
      name: routeConfig?.name ?? 'Unknown',
      queryParams: queryParams ?? {},
      pathParams: pathParams ?? {},
      routeConfig: routeConfig,
    );
    
    _currentRouteState.value = newState;
  }

  /// 程序化导航
  Future<void> navigateTo(String path, {
    Map<String, String>? queryParams,
    Map<String, String>? pathParams,
    Map<String, dynamic>? extra,
  }) async {
    if (_routerDelegate != null) {
      await _routerDelegate!.pushNamed(
        path,
        queryParams: queryParams,
        pathParams: pathParams,
        extra: extra,
      );
    } else {
      // 回退到更新本地状态
      updateCurrentRoute(path, queryParams: queryParams, pathParams: pathParams);
    }
  }

  /// 替换当前路由
  Future<void> replaceTo(String path, {
    Map<String, String>? queryParams,
    Map<String, String>? pathParams,
    Map<String, dynamic>? extra,
  }) async {
    if (_routerDelegate != null) {
      await _routerDelegate!.pushReplacementNamed(
        path,
        queryParams: queryParams,
        pathParams: pathParams,
        extra: extra,
      );
    } else {
      updateCurrentRoute(path, queryParams: queryParams, pathParams: pathParams);
    }
  }

  /// 返回上一页
  Future<bool> goBack() async {
    if (_routerDelegate != null) {
      return await _routerDelegate!.pop();
    } else {
      // 回退到历史记录
      if (_routeHistory.length > 1) {
        _routeHistory.removeLast();
        _currentRouteState.value = _routeHistory.last;
        return true;
      }
      return false;
    }
  }

  /// 获取菜单路由（过滤隐藏项）
  List<RouteConfig> get menuRoutes {
    return _routerConfig.menuRoutes;
  }

  /// 根据路径查找路由配置
  RouteConfig? findRouteByPath(String path) {
    // 检查缓存
    if (_routeCache.containsKey(path)) {
      logger.d('🏄🏽‍♂️ [PERF] findRouteByPath for $path: 0ms (cached)');
      return _routeCache[path];
    }
    
    final stopwatch = Stopwatch()..start();
    final result = _routerConfig.findRouteByPath(path);
    
    // 缓存结果
    _routeCache[path] = result;
    
    logger.d('🏄🏽‍♂️ [PERF] findRouteByPath for $path: ${stopwatch.elapsedMilliseconds}ms');
    return result;
  }

  /// 获取路由层级
  List<RouteConfig> getRouteHierarchy(String path) {
    // 检查缓存
    if (_hierarchyCache.containsKey(path)) {
      logger.d('🏄🏽‍♂️ [PERF] getRouteHierarchy for $path: 0ms (cached: true)');
      return _hierarchyCache[path]!;
    }
    
    final stopwatch = Stopwatch()..start();
    logger.d('🏄🏽‍♂️ [PERF] getRouteHierarchy started for: $path');
    
    final hierarchy = _routerConfig.getRouteHierarchy(path);
    
    // 缓存结果
    _hierarchyCache[path] = hierarchy;
    
    logger.d('🏄🏽‍♂️ [PERF] getRouteHierarchy completed: ${stopwatch.elapsedMilliseconds}ms, found ${hierarchy.length} routes (cached: false)');
    return hierarchy;
  }

  /// 清理缓存
  void _clearCache() {
    _routeCache.clear();
    _hierarchyCache.clear();
  }

  /// 获取面包屑导航
  List<AppRouteState> getBreadcrumbs() {
    return _currentRouteState.value.getBreadcrumbs();
  }

  /// 检查是否可以返回
  bool canGoBack() {
    if (_routerDelegate != null) {
      return _routerDelegate!.canPop();
    }
    return _routeHistory.length > 1;
  }

  /// 获取当前路由标题
  String get currentTitle {
    return _currentRouteState.value.title;
  }

  /// 获取当前路由图标
  String? get currentIcon {
    return _currentRouteState.value.icon;
  }

  /// 检查当前路由是否需要认证
  bool get requiresAuth {
    return _currentRouteState.value.requiresAuth;
  }

  /// 检查当前路由是否为全屏
  bool get isFullscreen {
    return _currentRouteState.value.isFullscreen;
  }

  /// 兼容旧代码的属性和方法
  
  /// 兼容旧的 routes 属性
  List<RouteRecord> get routes {
    // 将新的 RouteConfig 转换为旧的 RouteRecord 格式
    return _convertRouteConfigsToRecords(_routerConfig.routes);
  }

  /// 转换路由配置为路由记录
  List<RouteRecord> _convertRouteConfigsToRecords(List<RouteConfig> configs) {
    return configs.map((config) {
      return RouteRecord(
        path: config.path,
        name: config.name,
        redirect: config.redirect,
        meta: RouteMeta(
          title: config.meta?['title'] ?? config.name,
          svgIcon: config.meta?['icon'],
          hidden: config.meta?['hidden'] == true,
        ),
        children: config.children != null 
            ? _convertRouteConfigsToRecords(config.children!)
            : null,
      );
    }).toList();
  }

  /// 兼容旧的 internalPath 属性
  String get internalPath => _currentRouteState.value.path;
  set internalPath(String path) => updateCurrentRoute(path);

  /// 兼容旧的 internalPathRx 属性
  Rx<String> get internalPathRx {
    return _currentRouteState.value.path.obs;
  }

  /// 兼容旧的 subRouteFromCurrentRoute 属性
  String get subRouteFromCurrentRoute {
    final currentRoute = Get.currentRoute;
    // 如果当前路由不是全屏路由（launch, auth），则直接使用当前路由
    if (!currentRoute.startsWith('/launch') && !currentRoute.startsWith('/auth')) {
      return currentRoute;
    }
    // 否则返回当前内部路径
    return internalPath;
  }

  /// 释放资源
  @override
  void onClose() {
    _clearCache();
    super.onClose();
  }
}
