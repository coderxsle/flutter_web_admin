/// @file Layout 组件
/// @description 布局根组件，支持默认布局、混合布局和顶部布局三种模式
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'layout_default.dart';
import 'layout_mix.dart';
import 'layout_top.dart';

/// 布局类型枚举
enum LayoutType {
  /// 默认布局
  defaultLayout('default'),
  /// 混合布局
  mix('mix'),
  /// 顶部布局
  top('top');

  const LayoutType(this.value);
  final String value;
}

/// 应用状态管理器（模拟Vue的useAppStore）
class AppLayoutController extends GetxController {
  /// 当前布局类型
  final Rx<LayoutType> _layout = LayoutType.defaultLayout.obs;
  LayoutType get layout => _layout.value;
  set layout(LayoutType value) => _layout.value = value;

  /// 菜单折叠状态
  final RxBool _menuCollapse = false.obs;
  bool get menuCollapse => _menuCollapse.value;
  set menuCollapse(bool value) => _menuCollapse.value = value;

  /// 菜单暗黑主题
  final RxBool _menuDark = false.obs;
  bool get menuDark => _menuDark.value;
  set menuDark(bool value) => _menuDark.value = value;

  /// 标签页可见性
  final RxBool _tabVisible = true.obs;
  bool get tabVisible => _tabVisible.value;
  set tabVisible(bool value) => _tabVisible.value = value;

  /// 菜单手风琴模式
  final RxBool _menuAccordion = true.obs;
  bool get menuAccordion => _menuAccordion.value;
  set menuAccordion(bool value) => _menuAccordion.value = value;

  /// 过渡动画名称
  final RxString _transitionName = 'slide-right'.obs;
  String get transitionName => _transitionName.value;
  set transitionName(String value) => _transitionName.value = value;

  /// 标签页样式
  final RxString _tab = 'line'.obs;
  String get tab => _tab.value;
  set tab(String value) => _tab.value = value;

  /// 主题CSS变量（模拟）
  Map<String, dynamic> get themeCSSVar => {
    '--color-bg-1': Colors.grey[900],
    '--color-text-1': Colors.white,
    '--color-border': Colors.grey[700],
  };

  /// 设置菜单折叠状态
  void setMenuCollapse(bool collapse) {
    menuCollapse = collapse;
  }
}

/// 布局根组件
class LayoutIndex extends StatelessWidget {
  const LayoutIndex({super.key});

  @override
  Widget build(BuildContext context) {
    final appController = Get.find<AppLayoutController>();
    
    return Obx(() {
      // 布局组件映射
      final layoutMap = {
        LayoutType.mix: const LayoutMix(),
        LayoutType.top: const LayoutTop(),
        LayoutType.defaultLayout: const LayoutDefault(),
      };

      // 当前布局组件
      final currentLayout = layoutMap[appController.layout] ?? 
                           layoutMap[LayoutType.defaultLayout]!;

      return currentLayout;
    });
  }
}
