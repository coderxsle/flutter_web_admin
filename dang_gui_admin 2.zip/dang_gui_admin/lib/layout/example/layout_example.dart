// /// @file LayoutExample 布局示例
// /// @description 演示如何使用布局系统的示例代码
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import '../layout.dart';

// /// 布局示例页面
// class LayoutExamplePage extends StatelessWidget {
//   const LayoutExamplePage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     // 初始化布局系统
//     LayoutInitializer.initialize();
    
//     return const LayoutIndex();
//   }
// }

