/// @file MenuFoldBtn 组件
/// @description 菜单折叠按钮组件，支持响应式布局和抽屉模式
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../layout_index.dart';
import 'app_logo.dart';
import 'menu/app_menu.dart';

/// 设备类型检测工具类（模拟Vue的useDevice）
class DeviceController extends GetxController {
  /// 是否为桌面设备
  bool get isDesktop => Get.width > 768;
  
  /// 是否为移动设备
  bool get isMobile => Get.width <= 768;
}

/// 菜单折叠按钮组件
class MenuFoldBtn extends StatefulWidget {
  const MenuFoldBtn({super.key});

  @override
  State<MenuFoldBtn> createState() => _MenuFoldBtnState();
}

class _MenuFoldBtnState extends State<MenuFoldBtn> {
  /// 抽屉可见性状态
  bool _drawerVisible = false;

  /// 抽屉样式配置
  static const Map<String, dynamic> _drawerStyle = {
    'borderRight': '1px solid var(--color-border-2)',
    'boxSizing': 'border-box',
    'backgroundColor': 'var(--color-bg-1)',
  };

  /// 处理折叠按钮点击
  void _handleFoldClick() {
    final appController = Get.find<AppLayoutController>();
    final deviceController = Get.find<DeviceController>();

    if (deviceController.isDesktop) {
      appController.setMenuCollapse(!appController.menuCollapse);
    } else {
      setState(() {
        _drawerVisible = !_drawerVisible;
      });
    }
  }

  /// 处理菜单项点击
  void _handleMenuItemClick() {
    setState(() {
      _drawerVisible = false;
    });
  }

  /// 构建抽屉菜单
  Widget _buildDrawer() {
    final appController = Get.find<AppLayoutController>();
    
    return Drawer(
      width: 220,
      backgroundColor: appController.menuDark 
          ? Colors.grey[900] 
          : Theme.of(context).cardColor,
      child: Column(
        children: [
          // Logo区域
          const Logo(collapsed: false),
          
          // 菜单区域
          Expanded(
            child: AppMenu(
              onMenuItemClickAfter: _handleMenuItemClick,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final appController = Get.find<AppLayoutController>();
    final deviceController = Get.find<DeviceController>();
    
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // 折叠按钮
        Obx(() => Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(4),
          ),
          child: IconButton(
            iconSize: 18,
            padding: const EdgeInsets.all(8),
            constraints: const BoxConstraints(
              minWidth: 32,
              minHeight: 32,
            ),
            onPressed: _handleFoldClick,
            icon: Icon(
              !appController.menuCollapse 
                  ? Icons.menu_open 
                  : Icons.menu,
              color: Theme.of(context).iconTheme.color,
            ),
            tooltip: deviceController.isDesktop ? '折叠菜单' : '打开菜单',
          ),
        )),
        
        // 移动端抽屉
        if (!deviceController.isDesktop)
          Offstage(
            offstage: !_drawerVisible,
            child: _buildDrawer(),
          ),
      ],
    );
  }
}

/// 响应式布局构建器
class ResponsiveBuilder extends StatelessWidget {
  final Widget Function(BuildContext context, bool isDesktop) builder;
  
  const ResponsiveBuilder({
    super.key,
    required this.builder,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isDesktop = constraints.maxWidth > 768;
        return builder(context, isDesktop);
      },
    );
  }
}
