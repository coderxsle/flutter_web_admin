/// @file HeaderRightBar 组件
/// @description 头部右侧工具栏组件，包含项目配置、消息通知、全屏切换、主题切换和用户菜单等功能
import 'package:dang_gui_admin/app_manager.dart';
import 'package:dang_gui_admin/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'notice_widget.dart';
import 'setting_drawer.dart';

/// 用户状态管理器（模拟Vue的useUserStore）
class UserController extends GetxController {
  /// 用户头像
  final RxString _avatar = 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin'.obs;
  String get avatar => _avatar.value;
  set avatar(String value) => _avatar.value = value;

  /// 用户名称
  final RxString _name = 'Admin'.obs;
  String get name => _name.value;
  set name(String value) => _name.value = value;

  /// 退出登录
  Future<void> logout() async {
    // 模拟登出逻辑
    await Future.delayed(const Duration(milliseconds: 500));
    // 清除用户数据
    _name.value = '';
    _avatar.value = '';
  }
}

/// 头部右侧工具栏组件
class HeaderRightBar extends StatefulWidget {
  const HeaderRightBar({super.key});

  @override
  State<HeaderRightBar> createState() => _HeaderRightBarState();
}

class _HeaderRightBarState extends State<HeaderRightBar> {
  /// 全屏状态
  bool _isFullscreen = false;

  /// 设置抽屉引用
  final GlobalKey<SettingDrawerState> _settingDrawerKey = 
      GlobalKey<SettingDrawerState>();

  /// 用户菜单项配置
  final List<Map<String, dynamic>> _userMenuItems = [
    {
      'key': 'user',
      'label': '个人中心',
      'icon': Icons.person,
      'iconColor': Colors.blue,
      'route': '/system/account',
    },
    {
      'key': 'github',
      'label': '项目地址',
      'icon': Icons.code,
      'iconColor': Colors.green,
      'url': 'https://github.com/example/project',
    },
    {
      'key': 'password',
      'label': '修改密码',
      'icon': Icons.lock,
      'iconColor': Colors.orange,
      'action': 'changePassword',
    },
  ];

  /// 打开设置抽屉
  void _handleOpenSettings() {
    Scaffold.of(context).openEndDrawer();
  }

  /// 切换全屏
  void _toggleFullscreen() {
    setState(() {
      _isFullscreen = !_isFullscreen;
    });
    
    // 这里可以集成真实的全屏API
    Get.snackbar(
      '提示',
      _isFullscreen ? '已进入全屏模式' : '已退出全屏模式',
      duration: const Duration(seconds: 1),
    );
  }

  /// 处理用户菜单项点击
  void _handleUserMenuClick(String value) {
    switch (value) {
      case 'user':
        Get.toNamed('/system/account');
        break;
      case 'github':
        // 这里可以使用url_launcher打开外部链接
        Get.snackbar('提示', '打开项目地址: https://github.com/example/project');
        break;
      case 'password':
        Get.snackbar('提示', '修改密码功能');
        break;
      case 'logout':
        _handleLogout();
        break;
    }
  }

  /// 处理退出登录
  void _handleLogout() {
    Get.dialog(
      AlertDialog(
        title: const Text('提示'),
        content: const Text('确认退出登录？'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () async {
              Get.back(); // 关闭对话框
              AppManager.signOut();
            },
            child: const Text('确认'),
          ),
        ],
      ),
    );
  }

  /// 构建工具按钮
  Widget _buildToolButton({
    required IconData icon,
    required String tooltip,
    required VoidCallback onPressed,
    Widget? badge,
  }) {
    return Tooltip(
      message: tooltip,
      child: badge != null
          ? Badge(
              label: badge,
              child: _buildIconButton(icon, onPressed),
            )
          : _buildIconButton(icon, onPressed),
    );
  }

  /// 构建图标按钮
  Widget _buildIconButton(IconData icon, VoidCallback onPressed) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: IconButton(
        iconSize: 18,
        padding: const EdgeInsets.all(8),
        constraints: const BoxConstraints(
          minWidth: 32,
          minHeight: 32,
        ),
        onPressed: onPressed,
        icon: Icon(icon),
      ),
    );
  }

  /// 构建用户菜单项
  Widget _buildUserMenuItem(Map<String, dynamic> item) {
    return PopupMenuItem<String>(
      value: item['key'] as String,
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              color: item['iconColor'] ?? Colors.grey,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Icon(
              item['icon'],
              size: 12,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 12),
          Text(item['label']),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final userController = Get.find<UserController>();
    final theme = Theme.of(context);
    final screenWidth = MediaQuery.of(context).size.width;
    final isDesktop = screenWidth > 768;
    
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        // 项目配置按钮
        _buildToolButton(
          icon: Icons.settings,
          tooltip: '项目配置',
          onPressed: _handleOpenSettings,
        ),
        
        const SizedBox(width: 12),
        
        // 消息通知按钮
        PopupMenuButton<String>(
          offset: const Offset(0, 40),
          child: _buildToolButton(
            icon: Icons.notifications,
            tooltip: '消息通知',
            onPressed: () {},
            badge: const Text('9', style: TextStyle(fontSize: 10)),
          ),
          itemBuilder: (context) => [
            const PopupMenuItem(
              enabled: false,
              child: SizedBox(
                width: 300,
                height: 200,
                child: NoticeWidget(),
              ),
            ),
          ],
        ),
        
        const SizedBox(width: 12),
        
        // 全屏切换按钮（仅在桌面端显示）
        if (isDesktop) ...[
          _buildToolButton(
            icon: _isFullscreen ? Icons.fullscreen_exit : Icons.fullscreen,
            tooltip: '全屏切换',
            onPressed: _toggleFullscreen,
          ),
          
          const SizedBox(width: 12),
        ],
        
        // 主题切换按钮
        _buildToolButton(
          tooltip: '主题切换',
          icon: AppTheme.isDarkMode() ? Icons.dark_mode : Icons.light_mode,
          onPressed: () => AppTheme.toggleThemeMode(),
        ),
        
        const SizedBox(width: 16),
        
        // 用户下拉菜单
        PopupMenuButton<String>(
          onSelected: _handleUserMenuClick,
          offset: const Offset(0, 40),
          itemBuilder: (context) => [
            ..._userMenuItems.map((item) => _buildUserMenuItem(item) as PopupMenuItem<String>),
            const PopupMenuDivider(),
            PopupMenuItem<String>(
              value: 'logout',
              child: Row(
                children: [
                  Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Icon(
                      Icons.logout,
                      size: 12,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text('退出登录'),
                ],
              ),
            ),
          ],
          child: Obx(() => Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 用户头像
              CircleAvatar(
                radius: 16,
                backgroundColor: theme.primaryColor,
                child: userController.avatar.isNotEmpty
                    ? ClipOval(
                        child: Image.network(
                          userController.avatar,
                          width: 32,
                          height: 32,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => 
                              Icon(Icons.person, size: 20, color: Colors.white),
                        ),
                      )
                    : Icon(Icons.person, size: 20, color: Colors.white),
              ),
              
              const SizedBox(width: 8),
              
              // 用户名
              Text(
                userController.name,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: theme.textTheme.titleMedium?.color,
                ),
              ),
              
              const SizedBox(width: 4),
              
              // 下拉箭头
              Icon(
                Icons.keyboard_arrow_down,
                size: 16,
                color: theme.iconTheme.color?.withOpacity(0.6),
              ),
            ],
          )),
        ),
      ],
    );
  }
}
