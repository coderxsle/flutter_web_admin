/// @file MenuIcon 组件
/// @description 菜单图标组件，支持SVG图标和组件图标
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

/// 菜单图标组件属性
class MenuIconProps {
  /// SVG图标名称
  final String? svgIcon;
  /// 组件图标
  final IconData? icon;
  /// 图标大小
  final double size;
  /// 图标颜色
  final Color? color;

  const MenuIconProps({
    this.svgIcon,
    this.icon,
    this.size = 24,
    this.color,
  });
}

/// 菜单图标组件
class MenuIcon extends StatelessWidget {
  /// 组件属性
  final MenuIconProps props;

  const MenuIcon({
    super.key,
    required this.props,
  });

  /// 便捷构造函数
  MenuIcon.svg({
    super.key,
    required String svgIcon,
    double size = 24,
    Color? color,
  }) : props = MenuIconProps(
         svgIcon: svgIcon,
         size: size,
         color: color,
       );

  MenuIcon.icon({
    super.key,
    required IconData icon,
    double size = 24,
    Color? color,
  }) : props = MenuIconProps(
         icon: icon,
         size: size,
         color: color,
       );

  @override
  Widget build(BuildContext context) {
    // 优先使用SVG图标
    if (props.svgIcon != null && props.svgIcon!.isNotEmpty) {
      return _buildSvgIcon(context);
    }
    
    // 使用组件图标
    if (props.icon != null) {
      return _buildComponentIcon(context);
    }
    
    // 默认图标
    return Icon(
      Icons.circle,
      size: props.size,
      color: props.color ?? Theme.of(context).iconTheme.color,
    );
  }

  /// 构建SVG图标
  Widget _buildSvgIcon(BuildContext context) {
    final iconName = props.svgIcon!;
    // 构建完整的资源路径
    final assetPath = 'assets/icons/$iconName.svg';
    try {
      return SvgPicture.asset(
        assetPath,
        width: props.size,
        height: props.size,
        // 如果SVG加载失败，显示备用图标
        errorBuilder: (context, error, stackTrace) {
          return _buildFallbackIcon(context);
        },
      );
    } catch (e) {
      // 如果发生异常，返回备用图标
      return _buildFallbackIcon(context);
    }
  }

  /// 构建备用图标（当SVG加载失败时使用）
  Widget _buildFallbackIcon(BuildContext context) {
    // 根据图标名称映射到对应的Material图标
    final iconMap = <String, IconData>{
      'menu_home': Icons.home,
      'menu_chart': Icons.bar_chart,
      'menu_data': Icons.data_usage,
      'menu_detail': Icons.info,
      'menu_document': Icons.description,
      'menu_error': Icons.error,
      'menu_example': Icons.code,
      'menu_file': Icons.insert_drive_file,
      'menu_form': Icons.assignment,
      'menu_layout': Icons.view_quilt,
      'menu_multi': Icons.widgets,
      'menu_nav': Icons.navigation,
      'menu_result': Icons.check_circle,
      'menu_system': Icons.settings,
      'menu_table': Icons.table_chart,
      'menu_test': Icons.science,
      'menu_about': Icons.info,
      'icon_user': Icons.person,
      'icon_msg': Icons.message,
      'icon_notice': Icons.notifications,
      'icon_num': Icons.numbers,
      'icon_wait': Icons.hourglass_empty,
      'file': Icons.insert_drive_file,
      'folder': Icons.folder,
      'file_open': Icons.folder_open,
      'file_close': Icons.folder,
      'upload_file': Icons.upload_file,
      'upload_folder': Icons.create_new_folder,
      'backtop': Icons.keyboard_arrow_up,
      'time': Icons.access_time,
    };

    final iconData = iconMap[props.svgIcon] ?? Icons.circle;
    
    return Icon(
      iconData,
      size: props.size,
      color: props.color ?? Theme.of(context).iconTheme.color,
    );
  }

  /// 构建组件图标
  Widget _buildComponentIcon(BuildContext context) {
    return Icon(
      props.icon,
      size: props.size,
      color: props.color ?? Theme.of(context).iconTheme.color,
    );
  }
}
