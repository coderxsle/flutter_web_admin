/// @file Menu 组件
/// @description 系统菜单组件，支持垂直和水平布局、手风琴模式、响应式折叠等功能
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../logger.dart';
import '../../controllers/route_controller.dart';
import '../../layout_index.dart';
import '../../../routes/app_router_config.dart';
import '../menu_fold_btn.dart';
import 'menu_item.dart';

/// 菜单模式枚举
enum MenuMode {
  /// 垂直模式
  vertical,
  /// 水平模式
  horizontal,
}

/// 菜单组件属性
class AppMenuProps {
  /// 菜单项配置
  final List<RouteConfig>? menus;
  /// 菜单样式
  final BoxDecoration? decoration;
  /// 菜单模式
  final MenuMode mode;
  /// 是否自动展开选中菜单
  final bool autoOpenSelected;
  /// 手风琴模式
  final bool accordion;
  /// 是否折叠菜单
  final bool collapsed;

  const AppMenuProps({
    this.menus,
    this.decoration,
    this.mode = MenuMode.vertical,
    this.autoOpenSelected = true,
    this.accordion = true,
    this.collapsed = false,
  });
}

/// 系统菜单组件
class AppMenu extends StatefulWidget {
  /// 组件属性
  final AppMenuProps props;
  /// 菜单项点击后回调
  final VoidCallback? onMenuItemClickAfter;
  /// 路由变化回调
  final void Function(String path)? onRouteChanged;

  const AppMenu({
    super.key,
    this.props = const AppMenuProps(),
    this.onMenuItemClickAfter,
    this.onRouteChanged,
  });

  @override
  State<AppMenu> createState() => _AppMenuState();
}

class _AppMenuState extends State<AppMenu> {
  /// 当前激活的菜单路径
  final List<String> _activeKeys = [];
  late RouteController _routeController;
  late Worker _routeWorker;

  @override
  void initState() {
    super.initState();
    _routeController = Get.find<RouteController>();
    
    // 监听路由变化
    _routeWorker = ever(_routeController.currentRouteStateRx, (_) {
      if (mounted) {
        _updateActiveKeys();
      }
    });
    
    // 初始更新
    _updateActiveKeys();
  }

  @override
  void dispose() {
    _routeWorker.dispose();
    super.dispose();
  }

  /// 更新激活的菜单键
  void _updateActiveKeys() {
    if (!mounted) return;
    
    final stopwatch = Stopwatch()..start();
    logger.d('🏄🏽‍♂️ [PERF] _updateActiveKeys started');
    
    // 使用当前路由状态
    final currentPath = _routeController.currentRouteState.path;
    
    logger.d('🏄🏽‍♂️ [PERF] Current path determined: ${stopwatch.elapsedMilliseconds}ms');
    
    // 获取当前路由的层级结构
    final hierarchy = _routeController.getRouteHierarchy(currentPath);
    logger.d('🏄🏽‍♂️ [PERF] Route hierarchy retrieved: ${stopwatch.elapsedMilliseconds}ms, hierarchy: ${hierarchy.map((r) => r.path).toList()}');
    
    setState(() {
      _activeKeys.clear();
      _activeKeys.addAll(hierarchy.map((route) => route.path));
    });
    
    logger.d('🏄🏽‍♂️ [PERF] _updateActiveKeys completed: ${stopwatch.elapsedMilliseconds}ms');
  }

  /// 判断是否为外部链接
  bool _isExternal(String url) {
    return url.startsWith('http://') || url.startsWith('https://');
  }

  /// 处理菜单项点击
  void _handleMenuItemClick(String path) {
    final stopwatch = Stopwatch()..start();
    logger.d('🏄🏽‍♂️ [PERF] Menu click started for: $path');
    
    if (_isExternal(path)) {
      // 打开外部链接
      // 这里可以使用url_launcher包
      logger.d('Open external link: $path');
      return;
    }
    
    // 使用新的路由 API 进行导航
    _routeController.navigateTo(path);
    logger.d('🏄🏽‍♂️ [PERF] Navigation completed: ${stopwatch.elapsedMilliseconds}ms');
    
    logger.d('Menu clicked: $path');
    
    // 通知路由变化
    widget.onRouteChanged?.call(path);
    logger.d('🏄🏽‍♂️ [PERF] Route change notified: ${stopwatch.elapsedMilliseconds}ms');
    
    // 调用回调
    widget.onMenuItemClickAfter?.call();
    logger.d('🏄🏽‍♂️ [PERF] Menu click completed: ${stopwatch.elapsedMilliseconds}ms');
  }


  @override
  Widget build(BuildContext context) {
    final deviceController = Get.find<DeviceController>();
    final appController = Get.find<AppLayoutController>();
    
    // 获取侧边栏路由
    final List<RouteConfig> sidebarRoutes = widget.props.menus ?? _routeController.menuRoutes;
    
    
    // 计算是否折叠
    final shouldCollapse = deviceController.isMobile 
        ? false 
        : (widget.props.collapsed || appController.menuCollapse);

    return Container(
      decoration: widget.props.decoration,
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: sidebarRoutes.map((item) => MenuItem(
            props: MenuItemProps(
              item: item,
              level: 0,
              collapsed: shouldCollapse,
              activeKeys: _activeKeys,
              onItemClick: _handleMenuItemClick,
            ),
          )).toList(),
        ),
      ),
    );
  }
}

/// Menu组件的便捷构造函数
class Menu extends StatelessWidget {
  final List<RouteConfig>? menus;
  final BoxDecoration? decoration;
  final VoidCallback? onMenuItemClickAfter;

  const Menu({
    super.key,
    this.menus,
    this.decoration,
    this.onMenuItemClickAfter,
  });

  @override
  Widget build(BuildContext context) {
    return AppMenu(
      props: AppMenuProps(
        menus: menus,
        decoration: decoration,
      ),
      onMenuItemClickAfter: onMenuItemClickAfter,
    );
  }
}
