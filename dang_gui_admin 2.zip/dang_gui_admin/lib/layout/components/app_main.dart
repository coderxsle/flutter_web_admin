/// @file Main 组件
/// @description 主内容区组件，适配新的路由系统，直接显示路由内容
import 'package:dang_gui_admin/layout/controllers/route_controller.dart';
import 'package:dang_gui_admin/layout/controllers/tabs_controller.dart';
import 'package:dang_gui_admin/routes/app_route_state.dart';
import 'package:dang_gui_admin/demo/pages/gi_arco_button_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_dot_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_icon_box_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_icon_selector_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_pagination_demo_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_tag_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_space_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_arrow_popup_demo_page.dart';
import 'package:dang_gui_admin/demo/pages/gi_js_modal_page.dart';
import 'package:dang_gui_admin/demo/pages/api_test_page.dart';
import 'package:dang_gui_admin/modules/home2/home_view.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../layout_index.dart';


/// Main组件的便捷构造函数
class Main extends StatelessWidget {
  const Main({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppMain();
  }
}

/// 主内容区组件
class AppMain extends StatefulWidget {
  const AppMain({super.key});

  @override
  State<AppMain> createState() => _AppMainState();
}

class _AppMainState extends State<AppMain> {
  late RouteController _routeController;
  
  /// 上一个路由状态，用于检测路由变化
  AppRouteState? _previousRouteState;

  @override
  void initState() {
    super.initState();
    _routeController = Get.find<RouteController>();
    _previousRouteState = _routeController.currentRouteState;
  }

  /// 获取过渡动画
  Widget _buildTransition(Widget child, Animation<double> animation) {
    final appController = Get.find<AppLayoutController>();
    
    switch (appController.transitionName) {
      case 'slide-right':
        return SlideTransition(
          position: animation.drive(
            Tween(begin: const Offset(1.0, 0.0), end: Offset.zero),
          ),
          child: child,
        );
      case 'slide-left':
        return SlideTransition(
          position: animation.drive(
            Tween(begin: const Offset(-1.0, 0.0), end: Offset.zero),
          ),
          child: child,
        );
      case 'fade':
        return FadeTransition(opacity: animation, child: child);
      default:
        return FadeTransition(opacity: animation, child: child);
    }
  }

  @override
  Widget build(BuildContext context) {
    final tabsController = Get.find<TabsController>();
    
    return Expanded(
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
        ),
        child: Obx(() {
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            transitionBuilder: (child, animation) => 
                _buildTransition(child, animation),
            child: tabsController.reloadFlag
                ? _buildCurrentRouteContent()
                : const SizedBox.shrink(),
          );
        }),
      ),
    );
  }

  /// 构建当前路由内容
  Widget _buildCurrentRouteContent() {
    return Obx(() {
      final currentRouteState = _routeController.currentRouteState;
      
      // 检测路由变化
      if (_previousRouteState?.path != currentRouteState.path) {
        debugPrint('AppMain: Route changed from ${_previousRouteState?.path} to ${currentRouteState.path}');
        _previousRouteState = currentRouteState;
      }
      
      return Container(
        key: ValueKey(currentRouteState.path),
        decoration: const BoxDecoration(
          color: Colors.white,
        ),
        child: _getRouteContent(currentRouteState),
      );
    });
  }

  /// 获取路由内容
  Widget _getRouteContent(AppRouteState routeState) {
    debugPrint('AppMain _getRouteContent: path=${routeState.path}');
    
    // 根据路由路径返回对应的页面组件
    switch (routeState.path) {
      case '/home':
        return const HomeView2();
      
      // 组件展示路由
      case '/components/basic/button':
        return const GiArcoButtonDemoPage(title: '按钮组件');
      case '/components/basic/tag':
        return const GiTagDemoPage(title: '标签组件');
      case '/components/basic/dot':
        return const GiDotDemoPage(title: '圆点组件');
      
      case '/components/layout/space':
        return const GiSpaceDemoPage(title: '间距组件');
      case '/components/layout/iconbox':
        return const GiIconBoxDemoPage(title: '图标盒子');
      
      case '/components/interactive/selector':
        return const GiIconSelectorDemoPage(title: '图标选择器');
      case '/components/interactive/pagination':
        return const GiPaginationDemoPage(title: '分页组件');
      case '/components/interactive/popup':
        return const GiArrowPopupDemoPage(title: '弹出组件');
      
      // 功能演示路由
      case '/features/api':
        return const ApiTestPage(title: '接口测试');
      case '/features/modal':
        return const GiJsModalPage(title: '模态框演示');
      
      // 其他路由
      case '/second':
      case '/three':
      case '/theme-settings':
      case '/recording':
      case '/realtime':
      case '/funasr':
      case '/demo':
        return _buildDefaultContent(routeState);
      
      default:
        // 处理父级路由（如 /components, /features）
        if (routeState.path.startsWith('/components') || 
            routeState.path.startsWith('/features')) {
          return _buildCategoryContent(routeState);
        }
        return _buildDefaultContent(routeState);
    }
  }


  /// 默认页面内容
  Widget _buildDefaultContent(AppRouteState routeState) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.info, size: 64, color: Colors.grey),
          const SizedBox(height: 16),
          Text(
            routeState.title,
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            '当前路由: ${routeState.path}',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          Text(
            '页面内容正在开发中...',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  /// 构建分类页面内容
  Widget _buildCategoryContent(AppRouteState routeState) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            routeState.path.startsWith('/components') 
                ? Icons.widgets 
                : Icons.featured_play_list,
            size: 64,
            color: Colors.blue,
          ),
          const SizedBox(height: 16),
          Text(
            routeState.title,
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            '请从左侧菜单选择具体的子项目',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            '当前路由: ${routeState.path}',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }
}
