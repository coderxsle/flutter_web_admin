/// @file ReloadIcon 组件
/// @description 重载图标组件，用于页面重载功能
import 'package:dang_gui_admin/utils/message_utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/tabs_controller.dart';

/// 重载图标组件
class ReloadIcon extends StatefulWidget {
  const ReloadIcon({super.key});

  @override
  State<ReloadIcon> createState() => _ReloadIconState();
}

class _ReloadIconState extends State<ReloadIcon>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _rotationAnimation;
  bool _isLoading = false;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _rotationAnimation = Tween<double>(
      begin: 0,
      end: 2, // 360度旋转
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  /// 处理重载
  void _handleReload() async {
    if (_isLoading) return;
    
    setState(() {
      _isLoading = true;
    });
    
    // 播放旋转动画
    _animationController.forward();
    
    try {
      final tabsController = Get.find<TabsController>();
      tabsController.reloadPage();
      
      // 显示成功消息
      showInfo('页面重载成功');
    } catch (e) {
      // 显示错误消息
      showError('页面重载失败: $e');
    } finally {
      // 等待动画完成
      await Future.delayed(const Duration(milliseconds: 800));
      
      setState(() {
        _isLoading = false;
      });
      
      _animationController.reset();
    }
  }

  void _handleHover(bool isHovered) {
    setState(() {
      _isHovered = isHovered;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return MouseRegion(
      onEnter: (_) => _handleHover(true),
      onExit: (_) => _handleHover(false),
      child: GestureDetector(
        onTap: _handleReload,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: _isHovered 
                ? theme.colorScheme.secondary.withOpacity(0.1)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(4),
          ),
          child: AnimatedBuilder(
            animation: _rotationAnimation,
            builder: (context, child) {
              return Transform.rotate(
                angle: _rotationAnimation.value * 3.14159, // 转换为弧度
                child: Icon(
                  Icons.refresh,
                  size: 16,
                  color: _isLoading
                      ? theme.primaryColor
                      : (_isHovered 
                          ? theme.primaryColor
                          : theme.iconTheme.color?.withOpacity(0.7)),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
