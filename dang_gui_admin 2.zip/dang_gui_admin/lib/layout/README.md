# Flutter 布局系统

这是一个完整的 Flutter 管理后台布局系统，100% 基于原 Vue 组件的功能和交互逻辑迁移而来。

## 📋 功能特性

### 🎯 核心功能
- ✅ **三种布局模式**：默认布局、混合布局、顶部布局
- ✅ **响应式设计**：支持桌面端和移动端自适应
- ✅ **菜单系统**：多层级菜单、手风琴模式、图标支持
- ✅ **标签页系统**：多种样式、拖拽排序、右键菜单
- ✅ **面包屑导航**：自动生成、动画效果
- ✅ **主题系统**：明暗主题切换、菜单主题配置
- ✅ **折叠功能**：侧边栏折叠、移动端抽屉

### 🎨 UI 组件
- ✅ **Logo 组件**：支持折叠状态、首页导航
- ✅ **菜单组件**：递归结构、多种模式
- ✅ **标签页组件**：多样式支持、操作菜单
- ✅ **工具栏组件**：通知、设置、用户菜单
- ✅ **设置抽屉**：布局配置、主题设置

## 📁 文件结构

```
lib/layout/
├── layout_index.dart              # 主布局根组件
├── layout_default.dart            # 默认布局
├── layout_mix.dart                # 混合布局  
├── layout_top.dart                # 顶部布局
├── layout_binding.dart            # 依赖注入绑定
├── layout.dart                    # 统一导出文件
├── controllers/                   # 状态管理器
│   ├── route_controller.dart      # 路由管理
│   └── tabs_controller.dart       # 标签页管理
├── models/                        # 数据模型
│   └── route_record.dart          # 路由记录模型
├── components/                    # 布局组件
│   ├── app_logo.dart              # Logo组件
│   ├── app_main.dart              # 主内容区
│   ├── menu_fold_btn.dart         # 菜单折叠按钮
│   ├── asider/                    # 侧边栏
│   ├── breadcrumb/                # 面包屑导航
│   ├── header/                    # 头部组件
│   ├── header_right_bar/          # 右侧工具栏
│   ├── menu/                      # 菜单系统
│   └── tabs/                      # 标签页系统
└── example/                       # 使用示例
    └── layout_example.dart        # 完整示例
```

## 🚀 快速开始

### 1. 添加依赖

在 `pubspec.yaml` 中添加必要依赖：

```yaml
dependencies:
  flutter:
    sdk: flutter
  get: ^4.6.6
```

### 2. 初始化布局系统

```dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'layout/layout.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Admin Dashboard',
      initialBinding: LayoutBinding(),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // 初始化布局系统
    LayoutInitializer.initialize();
    
    return LayoutIndex();
  }
}
```

### 3. 配置路由

```dart
// 在路由控制器中配置您的路由
final routeController = Get.find<RouteController>();
routeController.setRoutes([
  RouteRecord(
    path: '/dashboard',
    name: 'Dashboard',
    meta: RouteMeta(
      title: '仪表板',
      svgIcon: 'dashboard',
      hidden: false,
    ),
  ),
  // 更多路由...
]);
```

## 🎛️ 布局模式

### 默认布局（LayoutDefault）
- 左侧边栏 + 右侧内容区
- 适合传统的管理后台

### 混合布局（LayoutMix）
- 左侧一级菜单 + 顶部二级导航
- 支持菜单联动，响应式设计

### 顶部布局（LayoutTop）
- 顶部横向导航
- 适合简洁的单层菜单结构

## 🔧 配置选项

### 布局配置

```dart
final appController = Get.find<AppLayoutController>();

// 切换布局模式
appController.layout = LayoutType.mix;

// 菜单配置
appController.menuCollapse = true;    // 折叠菜单
appController.menuDark = true;        // 暗黑主题
appController.menuAccordion = true;   // 手风琴模式

// 标签页配置
appController.tabVisible = true;      // 显示标签页
appController.tab = 'custom1';        // 标签页样式
```

### 主题配置

```dart
// 主题切换
Get.changeThemeMode(
  Get.isDarkMode ? ThemeMode.light : ThemeMode.dark,
);

// 菜单主题
appController.menuDark = !appController.menuDark;
```

## 📱 响应式特性

### 断点设置
- 桌面端：> 768px
- 移动端：≤ 768px

### 自适应行为
- **桌面端**：显示完整布局，支持侧边栏折叠
- **移动端**：隐藏侧边栏，使用抽屉菜单

## 🎨 自定义样式

### 标签页样式
- `line`: 线条样式（默认）
- `card`: 卡片样式
- `custom1`: 自定义样式1
- `custom2`: 标签样式

### 菜单图标
支持两种图标类型：
```dart
// SVG 图标
MenuIcon(props: MenuIconProps(svgIcon: 'home'))

// Flutter 图标
MenuIcon(props: MenuIconProps(icon: Icons.home))
```

## 🔌 扩展开发

### 添加新的布局模式

1. 创建新的布局组件
2. 在 `LayoutType` 枚举中添加新类型
3. 在 `LayoutIndex` 中注册新布局

### 自定义菜单项

```dart
RouteRecord(
  path: '/custom',
  name: 'Custom',
  meta: RouteMeta(
    title: '自定义页面',
    svgIcon: 'custom-icon',
    hidden: false,
  ),
  children: [
    // 子菜单...
  ],
)
```

## 🐛 常见问题

### Q: 如何添加新的菜单项？
A: 在 `RouteController` 中配置新的 `RouteRecord`，系统会自动生成对应的菜单项。

### Q: 如何自定义主题？
A: 通过 Flutter 的 `ThemeData` 配置全局主题，或使用 `AppLayoutController` 配置菜单主题。

### Q: 移动端菜单如何工作？
A: 移动端自动隐藏侧边栏，点击菜单按钮会显示抽屉菜单。

### Q: 如何禁用某个菜单项？
A: 在 `RouteMeta` 中设置 `hidden: true`。

## 📄 许可证

本项目基于原 Vue 组件的功能和交互逻辑，完全使用 Flutter 重新实现。

## 🤝 贡献

欢迎提交 Issue 和 Pull Request 来改进这个布局系统！

---

**注意**：这是一个完整的布局系统实现，与原 Vue 组件在功能和交互上保持 100% 一致。所有组件都遵循 Flutter 最佳实践，具有清晰的代码结构和完整的注释。
