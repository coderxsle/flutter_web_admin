/// @file Layout 布局系统入口文件
/// @description 导出所有布局相关的组件和控制器
library layout;

// 主布局组件
export 'layout_index.dart';
export 'layout_default.dart';
export 'layout_mix.dart';
export 'layout_top.dart';

// 布局绑定
export 'layout_binding.dart';

// 控制器
export 'controllers/route_controller.dart';
export 'controllers/tabs_controller.dart';

// 模型
export 'models/route_record.dart';

// 组件
export 'components/app_logo.dart';
export 'components/app_main.dart';
export 'components/menu_fold_btn.dart';

// 侧边栏组件
export 'components/asider/app_asider.dart';

// 头部组件
export 'components/header/app_header.dart';
export 'components/breadcrumb/app_breadcrumb.dart';

// 菜单组件
export 'components/menu/app_menu.dart';
export 'components/menu/menu_item.dart';
export 'components/menu/menu_icon.dart';

// 标签页组件
export 'components/tabs/app_tabs.dart';
export 'components/tabs/magic_icon.dart';
export 'components/tabs/reload_icon.dart';

// 右侧工具栏组件
export 'components/header_right_bar/header_right_bar.dart';
export 'components/header_right_bar/notice_widget.dart';
export 'components/header_right_bar/setting_drawer.dart';
