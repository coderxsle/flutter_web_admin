/// @file LayoutTop 组件
/// @description 顶部布局组件，采用顶部横向导航的布局方式
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'components/app_logo.dart';
import 'components/app_main.dart';
import 'components/header_right_bar/header_right_bar.dart';
import 'components/header_right_bar/setting_drawer.dart';
import 'components/menu/app_menu.dart';
import 'components/tabs/app_tabs.dart';
import 'layout_index.dart';

/// 顶部布局组件
class LayoutTop extends StatelessWidget {
  const LayoutTop({super.key});

  @override
  Widget build(BuildContext context) {
    final appController = Get.find<AppLayoutController>();
    final theme = Theme.of(context);
    
    return Scaffold(
      endDrawer: Drawer(
        child: const SettingDrawer(),
      ),
      body: Column(
        children: [
          // 顶部头部区域
          Container(
            height: 56,
            padding: const EdgeInsets.only(right: 16),
            decoration: BoxDecoration(
              color: theme.appBarTheme.backgroundColor ?? theme.cardColor,
              border: Border(
                bottom: BorderSide(
                  color: theme.dividerColor,
                  width: 1,
                ),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.02),
                  blurRadius: 4,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
            child: Row(
              children: [
                // Logo区域
                const Logo(),
                
                // 顶部菜单区域
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: AppMenu(
                      props: const AppMenuProps(
                        mode: MenuMode.horizontal,
                      ),
                    ),
                  ),
                ),
                
                // 右侧工具栏
                const HeaderRightBar(),
              ],
            ),
          ),
          
          // 标签页区域
          Obx(() => appController.tabVisible 
              ? const AppTabs() 
              : const SizedBox.shrink()),
          
          // 主内容区
          const Main(),
        ],
      ),
    );
  }
}
