/// @file RouteRecord 模型
/// @description 路由记录模型，对应Vue Router的RouteRecordRaw
import 'package:flutter/material.dart';

/// 路由元数据
class RouteMeta {
  /// 路由标题
  final String? title;
  /// 是否隐藏
  final bool hidden;
  /// SVG图标名称
  final String? svgIcon;
  /// 图标数据
  final IconData? icon;
  /// 是否固定标签页
  final bool affix;
  /// 面包屑是否显示
  final bool breadcrumb;
  /// 激活的菜单路径
  final String? activeMenu;
  /// 是否不显示子菜单
  final bool noShowingChildren;
  /// 重定向路径
  final String? redirect;

  const RouteMeta({
    this.title,
    this.hidden = false,
    this.svgIcon,
    this.icon,
    this.affix = false,
    this.breadcrumb = true,
    this.activeMenu,
    this.noShowingChildren = false,
    this.redirect,
  });

  /// 从Map创建RouteMeta
  factory RouteMeta.fromMap(Map<String, dynamic> map) {
    return RouteMeta(
      title: map['title'],
      hidden: map['hidden'] ?? false,
      svgIcon: map['svgIcon'],
      icon: map['icon'],
      affix: map['affix'] ?? false,
      breadcrumb: map['breadcrumb'] ?? true,
      activeMenu: map['activeMenu'],
      noShowingChildren: map['noShowingChildren'] ?? false,
      redirect: map['redirect'],
    );
  }

  /// 转换为Map
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'hidden': hidden,
      'svgIcon': svgIcon,
      'icon': icon,
      'affix': affix,
      'breadcrumb': breadcrumb,
      'activeMenu': activeMenu,
      'noShowingChildren': noShowingChildren,
      'redirect': redirect,
    };
  }

  /// 复制并修改
  RouteMeta copyWith({
    String? title,
    bool? hidden,
    String? svgIcon,
    IconData? icon,
    bool? affix,
    bool? breadcrumb,
    String? activeMenu,
    bool? noShowingChildren,
    String? redirect,
  }) {
    return RouteMeta(
      title: title ?? this.title,
      hidden: hidden ?? this.hidden,
      svgIcon: svgIcon ?? this.svgIcon,
      icon: icon ?? this.icon,
      affix: affix ?? this.affix,
      breadcrumb: breadcrumb ?? this.breadcrumb,
      activeMenu: activeMenu ?? this.activeMenu,
      noShowingChildren: noShowingChildren ?? this.noShowingChildren,
      redirect: redirect ?? this.redirect,
    );
  }
}

/// 路由记录
class RouteRecord {
  final String path;                    /// 路由路径
  final String? name;                   /// 路由名称
  final Widget? component;              /// 路由组件
  final List<RouteRecord>? children;    /// 子路由
  final RouteMeta? meta;                /// 路由元数据
  final String? redirect;               /// 重定向路径
  final String? fullPath;               /// 完整路径

  const RouteRecord({
    required this.path,
    this.name,
    this.component,
    this.children,
    this.meta,
    this.redirect,
    this.fullPath,
  });

  /// 从Map创建RouteRecord
  factory RouteRecord.fromMap(Map<String, dynamic> map) {
    return RouteRecord(
      path: map['path'],
      name: map['name'],
      component: map['component'],
      children: map['children'] != null
          ? (map['children'] as List)
              .map((child) => RouteRecord.fromMap(child))
              .toList()
          : null,
      meta: map['meta'] != null ? RouteMeta.fromMap(map['meta']) : null,
      redirect: map['redirect'],
      fullPath: map['fullPath'],
    );
  }

  /// 转换为Map
  Map<String, dynamic> toMap() {
    return {
      'path': path,
      'name': name,
      'component': component,
      'children': children?.map((child) => child.toMap()).toList(),
      'meta': meta?.toMap(),
      'redirect': redirect,
      'fullPath': fullPath,
    };
  }

  /// 复制并修改
  RouteRecord copyWith({
    String? path,
    String? name,
    Widget? component,
    List<RouteRecord>? children,
    RouteMeta? meta,
    String? redirect,
    String? fullPath,
  }) {
    return RouteRecord(
      path: path ?? this.path,
      name: name ?? this.name,
      component: component ?? this.component,
      children: children ?? this.children,
      meta: meta ?? this.meta,
      redirect: redirect ?? this.redirect,
      fullPath: fullPath ?? this.fullPath,
    );
  }

  /// 是否有子路由
  bool get hasChildren => children != null && children!.isNotEmpty;

  /// 获取显示的子路由
  List<RouteRecord> get showingChildren {
    if (children == null) return [];
    return children!.where((child) => child.meta?.hidden != true).toList();
  }

  /// 是否只有一个显示的子路由
  bool get hasOnlyOneShowingChild => showingChildren.length == 1;

  /// 获取唯一显示的子路由
  RouteRecord? get onlyOneChild {
    final showing = showingChildren;
    return showing.length == 1 ? showing.first : null;
  }
}
