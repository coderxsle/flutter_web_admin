import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:dang_gui_admin/logger.dart';
import 'package:dang_gui_admin/routes/app_pages.dart';

/// 认证中间件
/// 负责检查用户是否已登录，如果未登录则重定向到登录页面
class LaunchMiddleware extends GetMiddleware {
  @override
  int get priority => 0; // 最高优先级
  
  // 用于跟踪字体加载状态
  static bool _fontLoaded = true;
  
  // 设置字体已加载完成的方法
  static void setFontLoaded(bool loaded) {
    _fontLoaded = loaded;
    debugPrint('LaunchMiddleware - 字体加载状态: $_fontLoaded');
  }
  
  @override
  RouteSettings? redirect(String? route) {
    // 如果字体未加载完成，重定向到启动页
    if (!_fontLoaded && route != Routes.LAUNCH) {
      logger.i("字体未加载，重定向到启动页");
      return const RouteSettings(name: Routes.LAUNCH);
    }
    
    // 获取认证服务进行路由检查
    try {
      // final authService = Get.find<AuthService>();
      // return authService.checkRouteAuth(route);
      
    } catch (e) {
      // 如果认证服务不可用，则使用简单检查
      logger.e("认证服务不可用: $e");
      
      // 定义公开路由列表
      final publicRoutes = [Routes.LAUNCH, Routes.AUTH, Routes.FUNASR, Routes.HOME];
      if (publicRoutes.contains(route)) {
        return null;
      }
      
      // 安全起见，如果无法检查认证状态，则重定向到登录页面
      return const RouteSettings(name: Routes.AUTH);
    }
    return null;
  }
}