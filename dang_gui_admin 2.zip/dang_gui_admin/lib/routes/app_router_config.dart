/// @file AppRouterConfig 路由配置类
/// @description 基于 Router 2.0 的路由配置系统，支持嵌套路由和参数解析
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../layout/layout_demo_widget.dart';
import '../modules/auth/login_view.dart';
import '../modules/auth/binding.dart';
import '../layout/layout_binding.dart';

/// 路由配置项
class RouteConfig {
  /// 路由路径
  final String path;
  /// 路由名称
  final String name;
  /// 页面构建器
  final Widget Function(BuildContext context, Map<String, String> params)? pageBuilder;
  /// 绑定
  final Binding? binding;
  /// 子路由
  final List<RouteConfig>? children;
  /// 是否需要认证
  final bool requiresAuth;
  /// 路由元数据
  final Map<String, dynamic>? meta;
  /// 重定向路径
  final String? redirect;

  const RouteConfig({
    required this.path,
    required this.name,
    this.pageBuilder,
    this.binding,
    this.children,
    this.requiresAuth = false,
    this.meta,
    this.redirect,
  });

  /// 复制并修改路由配置
  RouteConfig copyWith({
    String? path,
    String? name,
    Widget Function(BuildContext context, Map<String, String> params)? pageBuilder,
    Binding? binding,
    List<RouteConfig>? children,
    bool? requiresAuth,
    Map<String, dynamic>? meta,
    String? redirect,
  }) {
    return RouteConfig(
      path: path ?? this.path,
      name: name ?? this.name,
      pageBuilder: pageBuilder ?? this.pageBuilder,
      binding: binding ?? this.binding,
      children: children ?? this.children,
      requiresAuth: requiresAuth ?? this.requiresAuth,
      meta: meta ?? this.meta,
      redirect: redirect ?? this.redirect,
    );
  }
}

/// 应用路由配置
class AppRouterConfig {
  /// 单例实例
  static final AppRouterConfig _instance = AppRouterConfig._internal();
  factory AppRouterConfig() => _instance;
  AppRouterConfig._internal();

  /// 路由配置列表
  static final List<RouteConfig> _routes = [
    // 认证路由 - 全屏显示
    RouteConfig(
      path: '/auth',
      name: 'Auth',
      pageBuilder: (context, params) => const LoginView(),
      binding: LoginBinding(),
      requiresAuth: false,
      meta: {'fullscreen': true, 'title': '用户登录'},
    ),

    // 根路由 - 重定向到首页
    RouteConfig(
      path: '/',
      name: 'Root',
      redirect: '/home',
      meta: {'hidden': true},
    ),

    // 主布局路由 - 包含所有子路由
    RouteConfig(
      path: '/home',
      name: 'Home',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '首页', 'icon': 'menu_home'},
    ),

    RouteConfig(
      path: '/dashboard',
      name: 'Dashboard',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '仪表板', 'icon': 'menu_chart'},
    ),

    // 组件展示路由
    RouteConfig(
      path: '/components',
      name: 'Components',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '组件展示', 'icon': 'menu_example'},
      children: [
        // 基础组件
        RouteConfig(
          path: '/components/basic',
          name: 'BasicComponents',
          pageBuilder: (context, params) => const LayoutDemoWidget(),
          binding: LayoutBinding(),
          requiresAuth: true,
          meta: {'title': '基础组件', 'icon': 'menu_form'},
          children: [
            RouteConfig(
              path: '/components/basic/button',
              name: 'Button',
              pageBuilder: (context, params) => const LayoutDemoWidget(),
              binding: LayoutBinding(),
              requiresAuth: true,
              meta: {'title': '按钮', 'icon': 'menu_form'},
            ),
            RouteConfig(
              path: '/components/basic/tag',
              name: 'Tag',
              pageBuilder: (context, params) => const LayoutDemoWidget(),
              binding: LayoutBinding(),
              requiresAuth: true,
              meta: {'title': '标签', 'icon': 'menu_form'},
            ),
            RouteConfig(
              path: '/components/basic/dot',
              name: 'Dot',
              pageBuilder: (context, params) => const LayoutDemoWidget(),
              binding: LayoutBinding(),
              requiresAuth: true,
              meta: {'title': '圆点', 'icon': 'menu_form'},
            ),
          ],
        ),
        // 布局组件
        RouteConfig(
          path: '/components/layout',
          name: 'LayoutComponents',
          pageBuilder: (context, params) => const LayoutDemoWidget(),
          binding: LayoutBinding(),
          requiresAuth: true,
          meta: {'title': '布局组件', 'icon': 'menu_layout'},
          children: [
            RouteConfig(
              path: '/components/layout/space',
              name: 'Space',
              pageBuilder: (context, params) => const LayoutDemoWidget(),
              binding: LayoutBinding(),
              requiresAuth: true,
              meta: {'title': '间距', 'icon': 'menu_layout'},
            ),
            RouteConfig(
              path: '/components/layout/iconbox',
              name: 'IconBox',
              pageBuilder: (context, params) => const LayoutDemoWidget(),
              binding: LayoutBinding(),
              requiresAuth: true,
              meta: {'title': '图标盒子', 'icon': 'menu_layout'},
            ),
          ],
        ),
        // 交互组件
        RouteConfig(
          path: '/components/interactive',
          name: 'InteractiveComponents',
          pageBuilder: (context, params) => const LayoutDemoWidget(),
          binding: LayoutBinding(),
          requiresAuth: true,
          meta: {'title': '交互组件', 'icon': 'menu_nav'},
          children: [
            RouteConfig(
              path: '/components/interactive/selector',
              name: 'IconSelector',
              pageBuilder: (context, params) => const LayoutDemoWidget(),
              binding: LayoutBinding(),
              requiresAuth: true,
              meta: {'title': '图标选择器', 'icon': 'menu_nav'},
            ),
            RouteConfig(
              path: '/components/interactive/pagination',
              name: 'Pagination',
              pageBuilder: (context, params) => const LayoutDemoWidget(),
              binding: LayoutBinding(),
              requiresAuth: true,
              meta: {'title': '分页', 'icon': 'menu_nav'},
            ),
            RouteConfig(
              path: '/components/interactive/popup',
              name: 'Popup',
              pageBuilder: (context, params) => const LayoutDemoWidget(),
              binding: LayoutBinding(),
              requiresAuth: true,
              meta: {'title': '弹出', 'icon': 'menu_nav'},
            ),
          ],
        ),
      ],
    ),

    // 功能演示路由
    RouteConfig(
      path: '/features',
      name: 'Features',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '功能演示', 'icon': 'menu_chart'},
      children: [
        RouteConfig(
          path: '/features/api',
          name: 'ApiTest',
          pageBuilder: (context, params) => const LayoutDemoWidget(),
          binding: LayoutBinding(),
          requiresAuth: true,
          meta: {'title': '接口测试', 'icon': 'menu_data'},
        ),
        RouteConfig(
          path: '/features/modal',
          name: 'ModalDemo',
          pageBuilder: (context, params) => const LayoutDemoWidget(),
          binding: LayoutBinding(),
          requiresAuth: true,
          meta: {'title': '模态框', 'icon': 'menu_result'},
        ),
      ],
    ),

    // 其他路由
    RouteConfig(
      path: '/second',
      name: 'Second',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '第二页', 'icon': 'menu_nav'},
    ),

    RouteConfig(
      path: '/three',
      name: 'Three',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '第三页', 'icon': 'menu_nav'},
    ),

    RouteConfig(
      path: '/theme-settings',
      name: 'ThemeSettings',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '主题设置', 'icon': 'menu_system'},
    ),

    RouteConfig(
      path: '/recording',
      name: 'Recording',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '录音', 'icon': 'menu_nav'},
    ),

    RouteConfig(
      path: '/realtime',
      name: 'Realtime',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '实时', 'icon': 'menu_nav'},
    ),

    RouteConfig(
      path: '/funasr',
      name: 'FunASR',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': 'FunASR', 'icon': 'menu_nav'},
    ),

    RouteConfig(
      path: '/demo',
      name: 'Demo',
      pageBuilder: (context, params) => const LayoutDemoWidget(),
      binding: LayoutBinding(),
      requiresAuth: true,
      meta: {'title': '演示', 'icon': 'menu_test'},
    ),
  ];

  /// 获取所有路由配置
  List<RouteConfig> get routes => List.unmodifiable(_routes);

  /// 根据路径查找路由配置
  RouteConfig? findRouteByPath(String path) {
    return _findRouteInList(_routes, path);
  }

  /// 在路由列表中递归查找路由
  RouteConfig? _findRouteInList(List<RouteConfig> routes, String path) {
    for (final route in routes) {
      if (route.path == path) {
        return route;
      }
      if (route.children != null) {
        final found = _findRouteInList(route.children!, path);
        if (found != null) {
          return found;
        }
      }
    }
    return null;
  }

  /// 根据名称查找路由配置
  RouteConfig? findRouteByName(String name) {
    return _findRouteByNameInList(_routes, name);
  }

  /// 在路由列表中递归查找路由（按名称）
  RouteConfig? _findRouteByNameInList(List<RouteConfig> routes, String name) {
    for (final route in routes) {
      if (route.name == name) {
        return route;
      }
      if (route.children != null) {
        final found = _findRouteByNameInList(route.children!, name);
        if (found != null) {
          return found;
        }
      }
    }
    return null;
  }

  /// 获取路由层级结构
  List<RouteConfig> getRouteHierarchy(String path) {
    final hierarchy = <RouteConfig>[];
    final segments = path.split('/').where((s) => s.isNotEmpty).toList();
    
    String currentPath = '';
    for (final segment in segments) {
      currentPath += '/$segment';
      final route = findRouteByPath(currentPath);
      if (route != null) {
        hierarchy.add(route);
      }
    }
    
    return hierarchy;
  }

  /// 获取菜单路由（过滤隐藏项）
  List<RouteConfig> get menuRoutes {
    return _filterMenuRoutes(_routes);
  }

  /// 过滤菜单路由
  List<RouteConfig> _filterMenuRoutes(List<RouteConfig> routes) {
    final result = <RouteConfig>[];
    
    for (final route in routes) {
      // 跳过隐藏路由和全屏路由
      final meta = route.meta ?? {};
      if (meta['hidden'] == true || meta['fullscreen'] == true) {
        continue;
      }
      
      // 处理子路由
      List<RouteConfig>? filteredChildren;
      if (route.children != null) {
        filteredChildren = _filterMenuRoutes(route.children!);
        if (filteredChildren.isEmpty) {
          filteredChildren = null;
        }
      }
      
      result.add(route.copyWith(children: filteredChildren));
    }
    
    return result;
  }

  /// 解析路径参数
  Map<String, String> parsePathParams(String template, String path) {
    final params = <String, String>{};
    final templateSegments = template.split('/');
    final pathSegments = path.split('/');
    
    if (templateSegments.length != pathSegments.length) {
      return params;
    }
    
    for (int i = 0; i < templateSegments.length; i++) {
      final templateSegment = templateSegments[i];
      final pathSegment = pathSegments[i];
      
      if (templateSegment.startsWith(':')) {
        final paramName = templateSegment.substring(1);
        params[paramName] = pathSegment;
      }
    }
    
    return params;
  }

  /// 构建路径
  String buildPath(String template, Map<String, String> params) {
    String result = template;
    
    params.forEach((key, value) {
      result = result.replaceAll(':$key', value);
    });
    
    return result;
  }

  /// 验证路径格式
  bool isValidPath(String path) {
    if (path.isEmpty || !path.startsWith('/')) {
      return false;
    }
    
    // 检查是否有连续的斜杠
    if (path.contains('//')) {
      return false;
    }
    
    return true;
  }

  /// 规范化路径
  String normalizePath(String path) {
    if (path.isEmpty) {
      return '/';
    }
    
    if (!path.startsWith('/')) {
      path = '/$path';
    }
    
    // 移除末尾的斜杠（除了根路径）
    if (path.length > 1 && path.endsWith('/')) {
      path = path.substring(0, path.length - 1);
    }
    
    return path;
  }

  /// 添加路由配置
  void addRoute(RouteConfig route) {
    _routes.add(route);
  }

  /// 移除路由配置
  void removeRoute(String path) {
    _routes.removeWhere((route) => route.path == path);
  }

  /// 清空所有路由配置
  void clearRoutes() {
    _routes.clear();
  }
}
