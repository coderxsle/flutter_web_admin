import 'package:get/get.dart';
import 'app_router_config.dart';

part 'app_routes.dart';

/// 应用页面配置（已弃用，使用 AppRouterConfig 代替）
/// 保留此类仅为向后兼容
@Deprecated('Use AppRouterConfig instead')
class AppPages {
  AppPages._();
  
  /// 获取路由配置（兼容旧代码）
  static List<GetPage> get routes {
    // 返回空列表，因为新系统不使用 GetPage
    // 所有路由配置都在 AppRouterConfig 中
    return [];
  }
  
  /// 获取路由配置管理器
  static AppRouterConfig get routerConfig => AppRouterConfig();
}
