// /// @file RouteConfig 路由配置
// /// @description 路由分类配置，区分全屏路由和布局内路由

// /// 路由类型枚举
// enum RouteType {
//   /// 全屏路由（覆盖整个屏幕，如登录页、404页等）
//   fullscreen,
//   /// 布局内路由（在布局系统内显示的页面）
//   layout,
// }

// /// 路由配置类
// class RouteConfig {
  
//   final String path; /// 路由路径
//   final RouteType type; /// 路由类型
//   final String? title; /// 路由标题
//   final bool requiresAuth; /// 是否需要认证

//   const RouteConfig({
//     required this.path,
//     required this.type,
//     this.title,
//     this.requiresAuth = true,
//   });
// }

// /// 路由配置映射
// class RouteConfigs {
//   static const Map<String, RouteConfig> _configs = {
//     // 全屏路由
//     '/launch': RouteConfig(path: '/launch', type: RouteType.fullscreen, title: '启动页', requiresAuth: false),
//     '/auth': RouteConfig(path: '/auth', type: RouteType.fullscreen, title: '登录', requiresAuth: false),
//     '/404': RouteConfig(path: '/404', type: RouteType.fullscreen, title: '页面不存在', requiresAuth: false),

//     // 布局内路由
//     '/': RouteConfig(path: '/', type: RouteType.layout, title: '首页'),
//     '/dashboard': RouteConfig(path: '/dashboard', type: RouteType.layout, title: '仪表盘'),
//     '/home': RouteConfig(path: '/home', type: RouteType.layout, title: '首页'),
//     '/second': RouteConfig(path: '/second', type: RouteType.layout, title: '第二页'),
//     '/three': RouteConfig(path: '/three', type: RouteType.layout, title: '第三页'),
//     '/theme-settings': RouteConfig(path: '/theme-settings', type: RouteType.layout, title: '主题设置'),
//     '/recording': RouteConfig(path: '/recording', type: RouteType.layout, title: '录音'),
//     '/realtime': RouteConfig(path: '/realtime', type: RouteType.layout, title: '实时'),
//     '/funasr': RouteConfig(path: '/funasr', type: RouteType.layout, title: 'FunASR'),
//     '/demo': RouteConfig(path: '/demo', type: RouteType.layout, title: '演示'),
//   };

//   /// 获取路由配置
//   static RouteConfig? getConfig(String path) {
//     return _configs[path];
//   }

//   /// 判断是否为全屏路由
//   static bool isFullscreenRoute(String path) {
//     final config = getConfig(path);
//     return config?.type == RouteType.fullscreen;
//   }

//   /// 判断是否为布局内路由
//   static bool isLayoutRoute(String path) {
//     final config = getConfig(path);
//     return config?.type == RouteType.layout;
//   }

//   /// 获取所有全屏路由
//   static List<String> getFullscreenRoutes() {
//     return _configs.entries
//         .where((entry) => entry.value.type == RouteType.fullscreen)
//         .map((entry) => entry.key)
//         .toList();
//   }

//   /// 获取所有布局内路由
//   static List<String> getLayoutRoutes() {
//     return _configs.entries
//         .where((entry) => entry.value.type == RouteType.layout)
//         .map((entry) => entry.key)
//         .toList();
//   }
// }


