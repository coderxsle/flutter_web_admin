/// @file RouteListener 路由监听器
/// @description 监听路由变化并同步相关状态，如菜单状态、标签页状态等
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import '../logger.dart';
import '../layout/controllers/route_controller.dart';
import '../layout/controllers/tabs_controller.dart';
import '../layout/layout_index.dart';
import 'app_route_state.dart';

/// 路由监听器
class RouteListener {
  /// 单例实例
  static final RouteListener _instance = RouteListener._internal();
  factory RouteListener() => _instance;
  RouteListener._internal();

  /// 是否已初始化
  bool _isInitialized = false;

  /// Worker 列表
  final List<Worker> _workers = [];

  /// 初始化路由监听器
  void initialize() {
    if (_isInitialized) {
      debugPrint('⚠️ [RouteListener] Already initialized');
      return;
    }

    debugPrint('🚀 [RouteListener] Initializing route listener');

    try {
      _setupRouteStateListener();
      _setupTabsListener();
      _setupLayoutListener();
      
      _isInitialized = true;
      debugPrint('✅ [RouteListener] Route listener initialized successfully');
    } catch (e) {
      debugPrint('❌ [RouteListener] Failed to initialize: $e');
    }
  }

  /// 设置路由状态监听器
  void _setupRouteStateListener() {
    try {
      final routeController = Get.find<RouteController>();
      
      // 监听当前路由状态变化
      final routeWorker = ever(routeController.currentRouteStateRx, (AppRouteState state) {
        _onRouteStateChanged(state);
      });
      
      _workers.add(routeWorker);
      debugPrint('✅ [RouteListener] Route state listener setup complete');
    } catch (e) {
      debugPrint('❌ [RouteListener] Failed to setup route state listener: $e');
    }
  }

  /// 设置标签页监听器
  void _setupTabsListener() {
    try {
      final tabsController = Get.find<TabsController>();
      final routeController = Get.find<RouteController>();
      
      // 监听路由变化，同步标签页状态
      final tabWorker = ever(routeController.currentRouteStateRx, (AppRouteState state) {
        _syncTabsWithRoute(state, tabsController);
      });
      
      _workers.add(tabWorker);
      debugPrint('✅ [RouteListener] Tabs listener setup complete');
    } catch (e) {
      debugPrint('❌ [RouteListener] Failed to setup tabs listener: $e');
    }
  }

  /// 设置布局监听器
  void _setupLayoutListener() {
    try {
      final appController = Get.find<AppLayoutController>();
      final routeController = Get.find<RouteController>();
      
      // 监听路由变化，更新布局状态
      final layoutWorker = ever(routeController.currentRouteStateRx, (AppRouteState state) {
        _syncLayoutWithRoute(state, appController);
      });
      
      _workers.add(layoutWorker);
      debugPrint('✅ [RouteListener] Layout listener setup complete');
    } catch (e) {
      debugPrint('❌ [RouteListener] Failed to setup layout listener: $e');
    }
  }

  /// 路由状态变化回调
  void _onRouteStateChanged(AppRouteState state) {
    debugPrint('🔄 [RouteListener] Route state changed: ${state.path}');
    
    try {
      // 更新浏览器标题
      _updateBrowserTitle(state);
      
      // 记录路由访问日志
      _logRouteAccess(state);
      
      // 触发自定义事件
      _triggerRouteChangeEvent(state);
      
    } catch (e) {
      debugPrint('❌ [RouteListener] Error handling route state change: $e');
    }
  }

  /// 同步标签页与路由
  void _syncTabsWithRoute(AppRouteState state, TabsController tabsController) {
    try {
      // 如果是全屏路由，不需要标签页
      if (state.isFullscreen) {
        return;
      }
      
      // 添加或激活标签页
      tabsController.addOrActivateTab(
        path: state.path,
        title: state.title,
        icon: state.icon,
      );
      
      debugPrint('🏷️ [RouteListener] Tabs synced with route: ${state.path}');
    } catch (e) {
      debugPrint('❌ [RouteListener] Error syncing tabs with route: $e');
    }
  }

  /// 同步布局与路由
  void _syncLayoutWithRoute(AppRouteState state, AppLayoutController appController) {
    try {
      // 根据路由类型调整布局
      if (state.isFullscreen) {
        // 全屏路由可能需要特殊处理
        debugPrint('📱 [RouteListener] Fullscreen route detected: ${state.path}');
      }
      
      // 可以根据路由元数据调整布局设置
      final meta = state.routeConfig?.meta;
      if (meta != null) {
        // 例如：某些路由可能需要隐藏侧边栏
        if (meta['hideSidebar'] == true) {
          appController.menuCollapse = true;
        }
        
        // 或者某些路由需要特定的布局模式
        if (meta['layoutMode'] != null) {
          final layoutMode = meta['layoutMode'] as String;
          switch (layoutMode) {
            case 'top':
              appController.layout = LayoutType.top;
              break;
            case 'mix':
              appController.layout = LayoutType.mix;
              break;
            default:
              appController.layout = LayoutType.defaultLayout;
          }
        }
      }
      
      debugPrint('🏗️ [RouteListener] Layout synced with route: ${state.path}');
    } catch (e) {
      debugPrint('❌ [RouteListener] Error syncing layout with route: $e');
    }
  }

  /// 更新浏览器标题
  void _updateBrowserTitle(AppRouteState state) {
    try {
      if (kIsWeb) {
        // 在 Web 平台更新浏览器标题
        final title = '${state.title} - 当归管理系统';
        // 这里可以使用 dart:html 或其他方式更新标题
        debugPrint('🌐 [RouteListener] Browser title updated: $title');
      }
    } catch (e) {
      debugPrint('❌ [RouteListener] Error updating browser title: $e');
    }
  }

  /// 记录路由访问日志
  void _logRouteAccess(AppRouteState state) {
    try {
      logger.i('📍 Route accessed: ${state.path} (${state.name})');
      
      // 可以在这里添加更详细的访问统计
      final accessInfo = {
        'path': state.path,
        'name': state.name,
        'timestamp': DateTime.now().toIso8601String(),
        'queryParams': state.queryParams,
        'pathParams': state.pathParams,
      };
      
      // 发送到分析服务或本地存储
      _sendAccessAnalytics(accessInfo);
      
    } catch (e) {
      debugPrint('❌ [RouteListener] Error logging route access: $e');
    }
  }

  /// 发送访问分析数据
  void _sendAccessAnalytics(Map<String, dynamic> accessInfo) {
    // 这里可以集成分析服务，如 Google Analytics、百度统计等
    debugPrint('📊 [RouteListener] Access analytics: $accessInfo');
  }

  /// 触发路由变化事件
  void _triggerRouteChangeEvent(AppRouteState state) {
    try {
      // 可以在这里触发自定义事件，供其他组件监听
      Get.find<RouteController>().update(); // 通知 GetBuilder 更新
      
      // 或者使用 EventBus 等事件系统
      debugPrint('📢 [RouteListener] Route change event triggered: ${state.path}');
    } catch (e) {
      debugPrint('❌ [RouteListener] Error triggering route change event: $e');
    }
  }

  /// 添加自定义路由监听器
  void addCustomListener(void Function(AppRouteState) listener) {
    try {
      final routeController = Get.find<RouteController>();
      
      final customWorker = ever(routeController.currentRouteStateRx, listener);
      _workers.add(customWorker);
      
      debugPrint('✅ [RouteListener] Custom listener added');
    } catch (e) {
      debugPrint('❌ [RouteListener] Error adding custom listener: $e');
    }
  }

  /// 移除所有监听器
  void removeAllListeners() {
    try {
      for (final worker in _workers) {
        worker.dispose();
      }
      _workers.clear();
      
      debugPrint('🧹 [RouteListener] All listeners removed');
    } catch (e) {
      debugPrint('❌ [RouteListener] Error removing listeners: $e');
    }
  }

  /// 获取监听器状态
  Map<String, dynamic> getListenerStatus() {
    return {
      'initialized': _isInitialized,
      'activeWorkers': _workers.length,
      'timestamp': DateTime.now().toIso8601String(),
    };
  }

  /// 重新初始化监听器
  void reinitialize() {
    debugPrint('🔄 [RouteListener] Reinitializing listeners');
    
    // 清理现有监听器
    removeAllListeners();
    _isInitialized = false;
    
    // 重新初始化
    initialize();
  }

  /// 销毁监听器
  void dispose() {
    debugPrint('🗑️ [RouteListener] Disposing route listener');
    
    removeAllListeners();
    _isInitialized = false;
  }

  /// 检查控制器是否可用
  bool _isControllerAvailable<T>() {
    try {
      Get.find<T>();
      return true;
    } catch (e) {
      return false;
    }
  }


  /// 延迟初始化（等待控制器就绪）
  Future<void> delayedInitialize({Duration delay = const Duration(milliseconds: 100)}) async {
    await Future.delayed(delay);
    
    // 检查必要的控制器是否已注册
    final controllersReady = _isControllerAvailable<RouteController>() &&
                            _isControllerAvailable<TabsController>() &&
                            _isControllerAvailable<AppLayoutController>();
    
    if (controllersReady) {
      initialize();
    } else {
      debugPrint('⏳ [RouteListener] Controllers not ready, retrying...');
      // 递归重试，但限制重试次数
      if (delay.inMilliseconds < 1000) {
        await delayedInitialize(delay: Duration(milliseconds: delay.inMilliseconds * 2));
      } else {
        debugPrint('❌ [RouteListener] Failed to initialize after multiple retries');
      }
    }
  }
}
