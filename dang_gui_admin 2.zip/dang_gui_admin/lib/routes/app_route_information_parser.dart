/// @file AppRouteInformationParser 路由信息解析器
/// @description 解析浏览器 URL 并转换为应用路由状态，支持嵌套路由和查询参数
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'app_router_config.dart';
import 'app_route_state.dart';

/// 应用路由信息解析器
class AppRouteInformationParser extends RouteInformationParser<AppRouteState> {
  /// 路由配置
  final AppRouterConfig _routerConfig = AppRouterConfig();

  @override
  Future<AppRouteState> parseRouteInformation(RouteInformation routeInformation) async {
    final uri = Uri.parse(routeInformation.location ?? '/');
    final path = _normalizePath(uri.path);
    final queryParams = uri.queryParameters;
    
    debugPrint('🔍 [RouteParser] Parsing route: $path, query: $queryParams');
    
    // 查找匹配的路由配置
    final routeConfig = _findMatchingRoute(path);
    
    if (routeConfig == null) {
      debugPrint('⚠️ [RouteParser] No matching route found for: $path, redirecting to /home');
      // 如果没有找到匹配的路由，重定向到首页
      return AppRouteState(
        path: '/home',
        name: 'Home',
        queryParams: queryParams,
        pathParams: {},
        isRedirect: true,
        originalPath: path,
      );
    }
    
    // 处理重定向
    if (routeConfig.redirect != null) {
      debugPrint('🔄 [RouteParser] Redirecting from $path to ${routeConfig.redirect}');
      final redirectConfig = _routerConfig.findRouteByPath(routeConfig.redirect!);
      return AppRouteState(
        path: routeConfig.redirect!,
        name: redirectConfig?.name ?? 'Unknown',
        queryParams: queryParams,
        pathParams: {},
        isRedirect: true,
        originalPath: path,
        routeConfig: redirectConfig,
      );
    }
    
    // 解析路径参数
    final pathParams = _parsePathParams(routeConfig.path, path);
    
    debugPrint('✅ [RouteParser] Route parsed successfully: ${routeConfig.name}');
    
    return AppRouteState(
      path: path,
      name: routeConfig.name,
      queryParams: queryParams,
      pathParams: pathParams,
      routeConfig: routeConfig,
    );
  }

  @override
  RouteInformation? restoreRouteInformation(AppRouteState configuration) {
    final uri = Uri(
      path: configuration.path,
      queryParameters: configuration.queryParams.isNotEmpty 
          ? configuration.queryParams 
          : null,
    );
    
    debugPrint('🔄 [RouteParser] Restoring route information: ${uri.toString()}');
    
    return RouteInformation(
      location: uri.toString(),
      state: configuration.toJson(),
    );
  }

  /// 查找匹配的路由配置
  RouteConfig? _findMatchingRoute(String path) {
    // 首先尝试精确匹配
    var routeConfig = _routerConfig.findRouteByPath(path);
    if (routeConfig != null) {
      return routeConfig;
    }
    
    // 如果没有精确匹配，尝试模式匹配（支持参数路由）
    routeConfig = _findRouteByPattern(path);
    if (routeConfig != null) {
      return routeConfig;
    }
    
    // 如果仍然没有匹配，尝试查找父路由
    final segments = path.split('/').where((s) => s.isNotEmpty).toList();
    for (int i = segments.length - 1; i >= 0; i--) {
      final parentPath = '/${segments.take(i + 1).join('/')}';
      routeConfig = _routerConfig.findRouteByPath(parentPath);
      if (routeConfig != null) {
        debugPrint('🔍 [RouteParser] Found parent route: $parentPath for $path');
        return routeConfig;
      }
    }
    
    return null;
  }

  /// 通过模式匹配查找路由
  RouteConfig? _findRouteByPattern(String path) {
    final allRoutes = _getAllRoutes(_routerConfig.routes);
    
    for (final route in allRoutes) {
      if (_isRouteMatch(route.path, path)) {
        return route;
      }
    }
    
    return null;
  }

  /// 获取所有路由（扁平化）
  List<RouteConfig> _getAllRoutes(List<RouteConfig> routes) {
    final result = <RouteConfig>[];
    
    for (final route in routes) {
      result.add(route);
      if (route.children != null) {
        result.addAll(_getAllRoutes(route.children!));
      }
    }
    
    return result;
  }

  /// 检查路由是否匹配
  bool _isRouteMatch(String routePattern, String path) {
    final routeSegments = routePattern.split('/').where((s) => s.isNotEmpty).toList();
    final pathSegments = path.split('/').where((s) => s.isNotEmpty).toList();
    
    if (routeSegments.length != pathSegments.length) {
      return false;
    }
    
    for (int i = 0; i < routeSegments.length; i++) {
      final routeSegment = routeSegments[i];
      final pathSegment = pathSegments[i];
      
      // 如果是参数段（以:开头），则匹配任何值
      if (routeSegment.startsWith(':')) {
        continue;
      }
      
      // 否则必须完全匹配
      if (routeSegment != pathSegment) {
        return false;
      }
    }
    
    return true;
  }

  /// 解析路径参数
  Map<String, String> _parsePathParams(String routePattern, String path) {
    final params = <String, String>{};
    final routeSegments = routePattern.split('/').where((s) => s.isNotEmpty).toList();
    final pathSegments = path.split('/').where((s) => s.isNotEmpty).toList();
    
    if (routeSegments.length != pathSegments.length) {
      return params;
    }
    
    for (int i = 0; i < routeSegments.length; i++) {
      final routeSegment = routeSegments[i];
      final pathSegment = pathSegments[i];
      
      if (routeSegment.startsWith(':')) {
        final paramName = routeSegment.substring(1);
        params[paramName] = Uri.decodeComponent(pathSegment);
      }
    }
    
    return params;
  }

  /// 规范化路径
  String _normalizePath(String path) {
    if (path.isEmpty) {
      return '/';
    }
    
    if (!path.startsWith('/')) {
      path = '/$path';
    }
    
    // 移除末尾的斜杠（除了根路径）
    if (path.length > 1 && path.endsWith('/')) {
      path = path.substring(0, path.length - 1);
    }
    
    // 移除重复的斜杠
    path = path.replaceAll(RegExp(r'/+'), '/');
    
    return path;
  }

}
