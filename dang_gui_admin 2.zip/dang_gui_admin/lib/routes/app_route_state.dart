/// @file AppRouteState 路由状态类
/// @description 表示应用的路由状态，包含路径、参数、配置等信息
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'app_router_config.dart';

/// 应用路由状态
class AppRouteState {
  /// 当前路径
  final String path;
  
  /// 路由名称
  final String name;
  
  /// 查询参数
  final Map<String, String> queryParams;
  
  /// 路径参数
  final Map<String, String> pathParams;
  
  /// 路由配置
  final RouteConfig? routeConfig;
  
  /// 是否为重定向
  final bool isRedirect;
  
  /// 原始路径（重定向前的路径）
  final String? originalPath;
  
  /// 路由历史记录
  final List<String> history;
  
  /// 额外的状态数据
  final Map<String, dynamic> extra;
  
  /// 创建时间戳
  final DateTime timestamp;

  AppRouteState({
    required this.path,
    required this.name,
    this.queryParams = const {},
    this.pathParams = const {},
    this.routeConfig,
    this.isRedirect = false,
    this.originalPath,
    this.history = const [],
    this.extra = const {},
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  /// 复制并修改路由状态
  AppRouteState copyWith({
    String? path,
    String? name,
    Map<String, String>? queryParams,
    Map<String, String>? pathParams,
    RouteConfig? routeConfig,
    bool? isRedirect,
    String? originalPath,
    List<String>? history,
    Map<String, dynamic>? extra,
    DateTime? timestamp,
  }) {
    return AppRouteState(
      path: path ?? this.path,
      name: name ?? this.name,
      queryParams: queryParams ?? this.queryParams,
      pathParams: pathParams ?? this.pathParams,
      routeConfig: routeConfig ?? this.routeConfig,
      isRedirect: isRedirect ?? this.isRedirect,
      originalPath: originalPath ?? this.originalPath,
      history: history ?? this.history,
      extra: extra ?? this.extra,
      timestamp: timestamp ?? this.timestamp,
    );
  }

  /// 添加查询参数
  AppRouteState addQueryParam(String key, String value) {
    final newParams = Map<String, String>.from(queryParams);
    newParams[key] = value;
    return copyWith(queryParams: newParams);
  }

  /// 移除查询参数
  AppRouteState removeQueryParam(String key) {
    final newParams = Map<String, String>.from(queryParams);
    newParams.remove(key);
    return copyWith(queryParams: newParams);
  }

  /// 添加路径参数
  AppRouteState addPathParam(String key, String value) {
    final newParams = Map<String, String>.from(pathParams);
    newParams[key] = value;
    return copyWith(pathParams: newParams);
  }

  /// 添加历史记录
  AppRouteState addToHistory(String path) {
    final newHistory = List<String>.from(history);
    newHistory.add(path);
    // 限制历史记录长度
    if (newHistory.length > 50) {
      newHistory.removeAt(0);
    }
    return copyWith(history: newHistory);
  }

  /// 获取完整的 URL
  String get fullUrl {
    final uri = Uri(
      path: path,
      queryParameters: queryParams.isNotEmpty ? queryParams : null,
    );
    return uri.toString();
  }

  /// 获取路由标题
  String get title {
    return routeConfig?.meta?['title'] ?? name;
  }

  /// 获取路由图标
  String? get icon {
    return routeConfig?.meta?['icon'];
  }

  /// 是否需要认证
  bool get requiresAuth {
    return routeConfig?.requiresAuth ?? false;
  }

  /// 是否为全屏路由
  bool get isFullscreen {
    return routeConfig?.meta?['fullscreen'] == true;
  }

  /// 是否为隐藏路由
  bool get isHidden {
    return routeConfig?.meta?['hidden'] == true;
  }

  /// 获取面包屑路径
  List<AppRouteState> getBreadcrumbs() {
    final breadcrumbs = <AppRouteState>[];
    final segments = path.split('/').where((s) => s.isNotEmpty).toList();
    final routerConfig = AppRouterConfig();
    
    String currentPath = '';
    for (final segment in segments) {
      currentPath += '/$segment';
      final config = routerConfig.findRouteByPath(currentPath);
      if (config != null && config.meta?['hidden'] != true) {
        breadcrumbs.add(AppRouteState(
          path: currentPath,
          name: config.name,
          routeConfig: config,
        ));
      }
    }
    
    return breadcrumbs;
  }

  /// 序列化为 JSON
  Map<String, dynamic> toJson() {
    return {
      'path': path,
      'name': name,
      'queryParams': queryParams,
      'pathParams': pathParams,
      'isRedirect': isRedirect,
      'originalPath': originalPath,
      'history': history,
      'extra': extra,
      'timestamp': timestamp.millisecondsSinceEpoch,
    };
  }

  /// 从 JSON 反序列化
  factory AppRouteState.fromJson(Map<String, dynamic> json) {
    return AppRouteState(
      path: json['path'] ?? '/',
      name: json['name'] ?? 'Unknown',
      queryParams: Map<String, String>.from(json['queryParams'] ?? {}),
      pathParams: Map<String, String>.from(json['pathParams'] ?? {}),
      isRedirect: json['isRedirect'] ?? false,
      originalPath: json['originalPath'],
      history: List<String>.from(json['history'] ?? []),
      extra: Map<String, dynamic>.from(json['extra'] ?? {}),
      timestamp: DateTime.fromMillisecondsSinceEpoch(
        json['timestamp'] ?? DateTime.now().millisecondsSinceEpoch,
      ),
    );
  }

  /// 序列化为字符串
  String toJsonString() {
    return jsonEncode(toJson());
  }

  /// 从字符串反序列化
  factory AppRouteState.fromJsonString(String jsonString) {
    try {
      final json = jsonDecode(jsonString) as Map<String, dynamic>;
      return AppRouteState.fromJson(json);
    } catch (e) {
      debugPrint('❌ [RouteState] Failed to parse JSON: $e');
      return AppRouteState(path: '/', name: 'Home');
    }
  }

  /// 验证路由状态
  bool isValid() {
    // 检查必要字段
    if (path.isEmpty || name.isEmpty) {
      return false;
    }
    
    // 检查路径格式
    if (!path.startsWith('/')) {
      return false;
    }
    
    return true;
  }

  /// 比较两个路由状态是否相等
  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    
    return other is AppRouteState &&
        other.path == path &&
        other.name == name &&
        mapEquals(other.queryParams, queryParams) &&
        mapEquals(other.pathParams, pathParams) &&
        other.isRedirect == isRedirect &&
        other.originalPath == originalPath;
  }

  @override
  int get hashCode {
    return Object.hash(
      path,
      name,
      queryParams,
      pathParams,
      isRedirect,
      originalPath,
    );
  }

  @override
  String toString() {
    return 'AppRouteState(path: $path, name: $name, queryParams: $queryParams, pathParams: $pathParams)';
  }

  /// 创建默认路由状态
  factory AppRouteState.defaultRoute() {
    return AppRouteState(
      path: '/home',
      name: 'Home',
    );
  }

  /// 创建错误路由状态
  factory AppRouteState.error({
    String path = '/home',
    String? errorMessage,
  }) {
    return AppRouteState(
      path: path,
      name: 'Error',
      extra: {
        'error': true,
        'errorMessage': errorMessage ?? 'Unknown error',
      },
    );
  }

  /// 创建重定向路由状态
  factory AppRouteState.redirect({
    required String from,
    required String to,
    String? name,
  }) {
    return AppRouteState(
      path: to,
      name: name ?? 'Redirect',
      isRedirect: true,
      originalPath: from,
    );
  }

  /// 获取路由层级深度
  int get depth {
    return path.split('/').where((s) => s.isNotEmpty).length;
  }

  /// 是否为根路由
  bool get isRoot {
    return path == '/';
  }

  /// 是否为子路由
  bool get isChild {
    return depth > 1;
  }

  /// 获取父路由路径
  String? get parentPath {
    if (isRoot) return null;
    
    final segments = path.split('/').where((s) => s.isNotEmpty).toList();
    if (segments.length <= 1) return '/';
    
    segments.removeLast();
    return '/${segments.join('/')}';
  }

  /// 检查是否为指定路径的子路由
  bool isChildOf(String parentPath) {
    if (parentPath == '/') {
      return path != '/';
    }
    
    return path.startsWith('$parentPath/') && path != parentPath;
  }

  /// 检查是否匹配指定的路径模式
  bool matchesPattern(String pattern) {
    final patternSegments = pattern.split('/').where((s) => s.isNotEmpty).toList();
    final pathSegments = path.split('/').where((s) => s.isNotEmpty).toList();
    
    if (patternSegments.length != pathSegments.length) {
      return false;
    }
    
    for (int i = 0; i < patternSegments.length; i++) {
      final patternSegment = patternSegments[i];
      final pathSegment = pathSegments[i];
      
      // 如果是参数段（以:开头），则匹配任何值
      if (patternSegment.startsWith(':')) {
        continue;
      }
      
      // 如果是通配符段（*），则匹配任何值
      if (patternSegment == '*') {
        continue;
      }
      
      // 否则必须完全匹配
      if (patternSegment != pathSegment) {
        return false;
      }
    }
    
    return true;
  }
}
