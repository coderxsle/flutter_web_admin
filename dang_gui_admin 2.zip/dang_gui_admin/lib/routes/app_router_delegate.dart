/// @file AppRouterDelegate 路由委托
/// @description 管理应用的路由导航和页面栈，集成 GetX 状态管理
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'app_router_config.dart';
import 'app_route_state.dart';
import '../middlewares/launch_middleware.dart';

/// 应用路由委托
class AppRouterDelegate extends RouterDelegate<AppRouteState>
    with ChangeNotifier, PopNavigatorRouterDelegateMixin<AppRouteState> {
  
  /// 导航器键
  @override
  final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
  
  /// 路由配置
  final AppRouterConfig _routerConfig = AppRouterConfig();
  
  /// 当前路由状态
  AppRouteState _currentConfiguration = AppRouteState.defaultRoute();
  
  /// 路由历史栈
  final List<AppRouteState> _routeStack = [];
  
  /// 是否正在导航中
  bool _isNavigating = false;
  
  /// 中间件列表
  final List<GetMiddleware> _middlewares = [LaunchMiddleware()];

  /// 构造函数
  AppRouterDelegate() {
    // 确保当前配置有正确的路由配置
    final routeConfig = _routerConfig.findRouteByPath(_currentConfiguration.path);
    if (routeConfig != null) {
      _currentConfiguration = _currentConfiguration.copyWith(routeConfig: routeConfig);
    }
    
    // 初始化路由栈，确保至少有一个页面
    _routeStack.add(_currentConfiguration);
  }

  /// 获取当前配置
  @override
  AppRouteState get currentConfiguration => _currentConfiguration;

  /// 设置新的路由配置
  @override
  Future<void> setNewRoutePath(AppRouteState configuration) async {
    if (_isNavigating) {
      debugPrint('⏳ [RouterDelegate] Navigation in progress, ignoring new route');
      return;
    }
    
    _isNavigating = true;
    
    try {
      debugPrint('🚀 [RouterDelegate] Setting new route path: ${configuration.path}');
      
      // 应用中间件
      final processedConfig = await _applyMiddlewares(configuration);
      if (processedConfig == null) {
        debugPrint('🚫 [RouterDelegate] Route blocked by middleware');
        return;
      }
      
      // 更新当前配置
      _updateCurrentConfiguration(processedConfig);
      
      // 通知监听器
      notifyListeners();
      
      debugPrint('✅ [RouterDelegate] Route path set successfully: ${processedConfig.path}');
    } catch (e) {
      debugPrint('❌ [RouterDelegate] Error setting route path: $e');
      // 发生错误时回退到默认路由
      _updateCurrentConfiguration(AppRouteState.defaultRoute());
      notifyListeners();
    } finally {
      _isNavigating = false;
    }
  }

  /// 构建导航器
  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: navigatorKey,
      pages: _buildPages(),
      onPopPage: _onPopPage,
    );
  }

  /// 构建页面列表
  List<Page> _buildPages() {
    debugPrint('🔍 [RouterDelegate] Building pages, route stack length: ${_routeStack.length}');
    
    // 总是确保有默认页面
    final pages = <Page>[_createDefaultPage()];
    debugPrint('✅ [RouterDelegate] Added default page as fallback');
    
    // 如果路由栈不为空，尝试添加路由页面
    if (_routeStack.isNotEmpty) {
      for (int i = 0; i < _routeStack.length; i++) {
        final routeState = _routeStack[i];
        debugPrint('🔍 [RouterDelegate] Creating page for route: ${routeState.path}');
        final page = _createPageForRoute(routeState, i);
        if (page != null) {
          // 如果成功创建页面，替换默认页面
          pages.clear();
          pages.add(page);
          debugPrint('✅ [RouterDelegate] Page created successfully for: ${routeState.path}');
          break; // 只使用第一个成功创建的页面
        } else {
          debugPrint('❌ [RouterDelegate] Failed to create page for: ${routeState.path}');
        }
      }
    }
    
    debugPrint('🔍 [RouterDelegate] Total pages built: ${pages.length}');
    return pages;
  }

  /// 为路由创建页面
  Page? _createPageForRoute(AppRouteState routeState, int index) {
    debugPrint('🔍 [RouterDelegate] _createPageForRoute called for: ${routeState.path}');
    
    final routeConfig = routeState.routeConfig ?? 
                      _routerConfig.findRouteByPath(routeState.path);
    
    if (routeConfig == null) {
      debugPrint('⚠️ [RouterDelegate] No route config found for: ${routeState.path}');
      debugPrint('🔍 [RouterDelegate] Available routes: ${_routerConfig.menuRoutes.map((r) => r.path).join(', ')}');
      return null;
    }
    
    debugPrint('✅ [RouterDelegate] Found route config for: ${routeState.path}');
    
    // 初始化绑定
    if (routeConfig.binding != null) {
      routeConfig.binding!.dependencies();
    }
    
    // 构建页面内容
    Widget pageContent;
    if (routeConfig.pageBuilder != null) {
      // 尝试获取有效的 BuildContext
      BuildContext? context;
      try {
        context = navigatorKey.currentContext ?? Get.context;
      } catch (e) {
        debugPrint('⚠️ [RouterDelegate] Get.context not available, using Builder');
      }
      
      if (context != null) {
        pageContent = routeConfig.pageBuilder!(context, routeState.pathParams);
      } else {
        // 如果无法获取context，使用Builder作为后备
        pageContent = Builder(
          builder: (ctx) => routeConfig.pageBuilder!(ctx, routeState.pathParams),
        );
      }
    } else {
      pageContent = _buildDefaultContent(routeState);
    }
    
    // 创建页面
    return MaterialPage(
      key: ValueKey('${routeState.path}_$index'),
      name: routeState.path,
      arguments: routeState,
      child: pageContent,
    );
  }

  /// 创建默认页面
  Page _createDefaultPage() {
    return MaterialPage(
      key: const ValueKey('default_page'),
      name: '/home',
      child: _buildDefaultContent(AppRouteState.defaultRoute()),
    );
  }

  /// 构建默认内容
  Widget _buildDefaultContent(AppRouteState routeState) {
    return Scaffold(
      appBar: AppBar(
        title: Text(routeState.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.info, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            Text(
              '页面内容区域',
              style: Theme.of(Get.context!).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(
              '当前路由: ${routeState.path}',
              style: Theme.of(Get.context!).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  /// 处理页面弹出
  bool _onPopPage(Route<dynamic> route, dynamic result) {
    if (!route.didPop(result)) {
      return false;
    }
    
    // 从路由栈中移除最后一个路由
    if (_routeStack.isNotEmpty) {
      _routeStack.removeLast();
      
      // 如果栈不为空，更新当前配置为栈顶路由
      if (_routeStack.isNotEmpty) {
        _updateCurrentConfiguration(_routeStack.last);
      } else {
        // 如果栈为空，回到默认路由
        _updateCurrentConfiguration(AppRouteState.defaultRoute());
      }
      
      notifyListeners();
    }
    
    return true;
  }

  /// 更新当前配置
  void _updateCurrentConfiguration(AppRouteState newConfiguration) {
    if (_currentConfiguration != newConfiguration) {
      // 添加到历史记录
      final updatedConfig = newConfiguration.addToHistory(_currentConfiguration.path);
      
      _currentConfiguration = updatedConfig;
      
      // 更新路由栈
      _updateRouteStack(updatedConfig);
      
      debugPrint('📍 [RouterDelegate] Current configuration updated: ${updatedConfig.path}');
    }
  }

  /// 更新路由栈
  void _updateRouteStack(AppRouteState newConfiguration) {
    // 如果是新路由，添加到栈中
    if (_routeStack.isEmpty || _routeStack.last.path != newConfiguration.path) {
      _routeStack.add(newConfiguration);
      
      // 限制栈的大小
      if (_routeStack.length > 20) {
        _routeStack.removeAt(0);
      }
    }
  }

  /// 应用中间件
  Future<AppRouteState?> _applyMiddlewares(AppRouteState configuration) async {
    var currentConfig = configuration;
    
    for (final middleware in _middlewares) {
      
      final redirect = middleware.redirect(currentConfig.path);
      if (redirect != null) {
        debugPrint('🔄 [RouterDelegate] Middleware redirect: ${currentConfig.path} -> ${redirect.name}');
        
        final redirectConfig = _routerConfig.findRouteByPath(redirect.name!);
        if (redirectConfig != null) {
          currentConfig = AppRouteState.redirect(
            from: currentConfig.path,
            to: redirect.name!,
            name: redirectConfig.name,
          ).copyWith(routeConfig: redirectConfig);
        }
      }
    }
    
    return currentConfig;
  }

  /// 程序化导航到指定路径
  Future<void> pushNamed(String path, {
    Map<String, String>? queryParams,
    Map<String, String>? pathParams,
    Map<String, dynamic>? extra,
  }) async {
    final routeConfig = _routerConfig.findRouteByPath(path);
    
    final newState = AppRouteState(
      path: path,
      name: routeConfig?.name ?? 'Unknown',
      queryParams: queryParams ?? {},
      pathParams: pathParams ?? {},
      routeConfig: routeConfig,
      extra: extra ?? {},
    );
    
    await setNewRoutePath(newState);
  }

  /// 替换当前路由
  Future<void> pushReplacementNamed(String path, {
    Map<String, String>? queryParams,
    Map<String, String>? pathParams,
    Map<String, dynamic>? extra,
  }) async {
    // 移除当前路由
    if (_routeStack.isNotEmpty) {
      _routeStack.removeLast();
    }
    
    // 添加新路由
    await pushNamed(path, 
      queryParams: queryParams,
      pathParams: pathParams,
      extra: extra,
    );
  }

  /// 清空栈并导航到指定路径
  Future<void> pushNamedAndClearStack(String path, {
    Map<String, String>? queryParams,
    Map<String, String>? pathParams,
    Map<String, dynamic>? extra,
  }) async {
    // 清空路由栈
    _routeStack.clear();
    
    // 导航到新路由
    await pushNamed(path,
      queryParams: queryParams,
      pathParams: pathParams,
      extra: extra,
    );
  }

  /// 返回上一页
  Future<bool> pop() async {
    if (_routeStack.length > 1) {
      _routeStack.removeLast();
      _updateCurrentConfiguration(_routeStack.last);
      notifyListeners();
      return true;
    }
    return false;
  }

  /// 检查是否可以返回
  bool canPop() {
    return _routeStack.length > 1;
  }

  /// 获取路由历史
  List<AppRouteState> get routeHistory => List.unmodifiable(_routeStack);

  /// 清空路由历史
  void clearHistory() {
    final currentRoute = _routeStack.isNotEmpty ? _routeStack.last : _currentConfiguration;
    _routeStack.clear();
    _routeStack.add(currentRoute);
    notifyListeners();
  }

  /// 添加中间件
  void addMiddleware(GetMiddleware middleware) {
    _middlewares.add(middleware);
  }

  /// 移除中间件
  void removeMiddleware(GetMiddleware middleware) {
    _middlewares.remove(middleware);
  }

  /// 获取当前路由深度
  int get currentDepth => _routeStack.length;

  /// 检查指定路径是否在栈中
  bool isInStack(String path) {
    return _routeStack.any((state) => state.path == path);
  }

  /// 移除栈中指定路径的路由
  void removeFromStack(String path) {
    _routeStack.removeWhere((state) => state.path == path);
    
    // 如果移除的是当前路由，更新当前配置
    if (_currentConfiguration.path == path && _routeStack.isNotEmpty) {
      _updateCurrentConfiguration(_routeStack.last);
    }
    
    notifyListeners();
  }

  /// 获取路由栈信息（用于调试）
  String getStackInfo() {
    final info = StringBuffer();
    info.writeln('Route Stack (${_routeStack.length} items):');
    for (int i = 0; i < _routeStack.length; i++) {
      final state = _routeStack[i];
      final marker = i == _routeStack.length - 1 ? '→ ' : '  ';
      info.writeln('$marker[$i] ${state.path} (${state.name})');
    }
    return info.toString();
  }

  /// 释放资源
  @override
  void dispose() {
    _routeStack.clear();
    super.dispose();
  }
}
