import 'package:get/get.dart';
import 'auth_service.dart';

/// 权限服务
class PermissionService extends GetxService {
  static PermissionService get to => Get.find();

  /// 路由权限映射
  final Map<String, List<String>> _routePermissions = {
    '/home': ['dashboard:view'],
    '/second': ['user:view'],
    '/three': ['role:view'],
    '/theme-settings': ['system:settings'],
    '/recording': ['tool:recording'],
    '/realtime': ['tool:realtime'],
    '/funasr': ['tool:funasr'],
    '/demo': ['demo:view'],
  };

  /// 菜单权限映射
  final Map<String, String> _menuPermissions = {
    'dashboard': 'dashboard:view',
    'user-management': 'user:view',
    'role-management': 'role:view',
    'menu-management': 'menu:view',
    'recording': 'tool:recording',
    'realtime': 'tool:realtime',
    'funasr': 'tool:funasr',
    'demo': 'demo:view',
  };

  /// 检查是否有指定权限
  bool hasPermission(String permission) {
    return AuthService.to.hasPermission(permission);
  }

  /// 检查是否有多个权限中的任意一个
  bool hasAnyPermission(List<String> permissions) {
    return permissions.any((permission) => hasPermission(permission));
  }

  /// 检查是否有所有指定权限
  bool hasAllPermissions(List<String> permissions) {
    return permissions.every((permission) => hasPermission(permission));
  }

  /// 检查路由权限
  bool hasRoutePermission(String? route) {
    if (route == null) return true;
    
    final permissions = _routePermissions[route];
    if (permissions == null || permissions.isEmpty) return true;
    
    return hasAnyPermission(permissions);
  }

  /// 检查菜单权限
  bool hasMenuPermission(String menuId) {
    final permission = _menuPermissions[menuId];
    if (permission == null) return true;
    
    return hasPermission(permission);
  }

  /// 获取用户可访问的路由列表
  List<String> getAccessibleRoutes() {
    final accessibleRoutes = <String>[];
    
    for (final entry in _routePermissions.entries) {
      if (hasRoutePermission(entry.key)) {
        accessibleRoutes.add(entry.key);
      }
    }
    
    return accessibleRoutes;
  }

  /// 获取用户可访问的菜单ID列表
  List<String> getAccessibleMenus() {
    final accessibleMenus = <String>[];
    
    for (final entry in _menuPermissions.entries) {
      if (hasMenuPermission(entry.key)) {
        accessibleMenus.add(entry.key);
      }
    }
    
    return accessibleMenus;
  }

  /// 添加路由权限
  void addRoutePermission(String route, List<String> permissions) {
    _routePermissions[route] = permissions;
  }

  /// 移除路由权限
  void removeRoutePermission(String route) {
    _routePermissions.remove(route);
  }

  /// 添加菜单权限
  void addMenuPermission(String menuId, String permission) {
    _menuPermissions[menuId] = permission;
  }

  /// 移除菜单权限
  void removeMenuPermission(String menuId) {
    _menuPermissions.remove(menuId);
  }

  /// 检查角色权限
  bool hasRole(String role) {
    return AuthService.to.hasRole(role);
  }

  /// 检查是否有任意角色
  bool hasAnyRole(List<String> roles) {
    return roles.any((role) => hasRole(role));
  }

  /// 获取权限描述
  String getPermissionDescription(String permission) {
    final descriptions = {
      'dashboard:view': '查看仪表盘',
      'user:view': '查看用户',
      'user:create': '创建用户',
      'user:edit': '编辑用户',
      'user:delete': '删除用户',
      'role:view': '查看角色',
      'role:create': '创建角色',
      'role:edit': '编辑角色',
      'role:delete': '删除角色',
      'menu:view': '查看菜单',
      'menu:create': '创建菜单',
      'menu:edit': '编辑菜单',
      'menu:delete': '删除菜单',
      'system:settings': '系统设置',
      'tool:recording': '录音工具',
      'tool:realtime': '实时转写',
      'tool:funasr': 'FunASR工具',
      'demo:view': '查看演示',
      'profile:edit': '编辑个人资料',
    };
    
    return descriptions[permission] ?? permission;
  }

  /// 获取角色描述
  String getRoleDescription(String role) {
    final descriptions = {
      'admin': '超级管理员',
      'manager': '管理员',
      'user': '普通用户',
      'guest': '访客',
    };
    
    return descriptions[role] ?? role;
  }
}
