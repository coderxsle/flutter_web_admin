import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../models/user_info.dart';

/// 认证服务
class AuthService extends GetxService {
  static AuthService get to => Get.find();

  final _storage = GetStorage();
  final _currentUser = Rxn<UserInfo>();
  final _isLoggedIn = false.obs;

  /// 当前用户
  UserInfo? get currentUser => _currentUser.value;

  /// 是否已登录
  bool get isLoggedIn => _isLoggedIn.value;

  /// 用户token
  String? get token => _storage.read('token');

  @override
  void onInit() {
    super.onInit();
    _loadUserFromStorage();
  }

  /// 登录
  Future<bool> login(String username, String password) async {
    try {
      // 这里应该调用登录API
      // 模拟登录过程
      await Future.delayed(const Duration(seconds: 1));

      if (username == 'admin' && password == '123456') {
        final user = UserInfo(
          id: '1',
          username: 'admin',
          nickname: '管理员',
          email: 'admin@example.com',
          avatar: null,
          role: 'admin',
          permissions: ['*'], // 超级管理员拥有所有权限
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );

        await _saveUserToStorage(user, 'mock_token_123456');
        return true;
      } else if (username == 'user' && password == '123456') {
        final user = UserInfo(
          id: '2',
          username: 'user',
          nickname: '普通用户',
          email: 'user@example.com',
          avatar: null,
          role: 'user',
          permissions: ['dashboard:view', 'profile:edit'],
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );

        await _saveUserToStorage(user, 'mock_token_654321');
        return true;
      }

      return false;
    } catch (e) {
      print('登录失败: $e');
      return false;
    }
  }

  /// 登出
  Future<void> logout() async {
    try {
      // 这里应该调用登出API
      await Future.delayed(const Duration(milliseconds: 500));

      // 清除本地存储
      await _clearUserFromStorage();
    } catch (e) {
      print('登出失败: $e');
    }
  }

  /// 刷新token
  Future<bool> refreshToken() async {
    try {
      final currentToken = token;
      if (currentToken == null) return false;

      // 这里应该调用刷新token的API
      await Future.delayed(const Duration(seconds: 1));

      // 模拟刷新成功
      await _storage.write('token', '${currentToken}_refreshed');
      return true;
    } catch (e) {
      print('刷新token失败: $e');
      return false;
    }
  }

  /// 更新用户信息
  Future<bool> updateProfile(UserInfo userInfo) async {
    try {
      // 这里应该调用更新用户信息的API
      await Future.delayed(const Duration(seconds: 1));

      _currentUser.value = userInfo;
      await _storage.write('user', userInfo.toJson());
      return true;
    } catch (e) {
      print('更新用户信息失败: $e');
      return false;
    }
  }

  /// 修改密码
  Future<bool> changePassword(String oldPassword, String newPassword) async {
    try {
      // 这里应该调用修改密码的API
      await Future.delayed(const Duration(seconds: 1));

      // 模拟修改密码
      return oldPassword == '123456';
    } catch (e) {
      print('修改密码失败: $e');
      return false;
    }
  }

  /// 检查权限
  bool hasPermission(String permission) {
    if (currentUser == null) return false;
    if (currentUser!.permissions.contains('*')) return true;
    return currentUser!.permissions.contains(permission);
  }

  /// 检查角色
  bool hasRole(String role) {
    if (currentUser == null) return false;
    return currentUser!.role == role;
  }

  /// 从存储加载用户信息
  void _loadUserFromStorage() {
    try {
      final userData = _storage.read('user');
      final token = _storage.read('token');

      if (userData != null && token != null) {
        _currentUser.value = UserInfo.fromJson(userData);
        _isLoggedIn.value = true;
      }
    } catch (e) {
      print('加载用户信息失败: $e');
      _clearUserFromStorage();
    }
  }

  /// 保存用户信息到存储
  Future<void> _saveUserToStorage(UserInfo user, String token) async {
    try {
      await _storage.write('user', user.toJson());
      await _storage.write('token', token);
      
      _currentUser.value = user;
      _isLoggedIn.value = true;
    } catch (e) {
      print('保存用户信息失败: $e');
      rethrow;
    }
  }

  /// 清除用户信息
  Future<void> _clearUserFromStorage() async {
    try {
      await _storage.remove('user');
      await _storage.remove('token');
      
      _currentUser.value = null;
      _isLoggedIn.value = false;
    } catch (e) {
      print('清除用户信息失败: $e');
    }
  }
}
