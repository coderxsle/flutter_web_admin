import 'dart:async';
import 'package:dang_gui_admin/logger.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

/// WebSocket 连接状态回调
typedef WebSocketStatusCallback = void Function(bool isConnected);

/// WebSocket 消息回调
typedef WebSocketMessageCallback = void Function(String message);

/// WebSocket 错误回调
typedef WebSocketErrorCallback = void Function(dynamic error);

/// WebSocket 管理器
class WebSocketManager {
  // 配置常量
  static const int _maxRetryCount = 3;        // 最大重试次数
  static const int _retryDelaySeconds = 2;    // 重试间隔（秒）
  static const int _connectTimeoutSeconds = 10; // 连接超时时间（秒）
  static const int _heartbeatIntervalSeconds = 30; // 心跳间隔（秒）
  
  WebSocketChannel? _channel;
  bool _isConnected = false;
  DateTime? _lastSendTime;
  Timer? _heartbeatTimer;
  
  // 回调函数
  final WebSocketStatusCallback? onConnectionStatusChanged;
  final WebSocketMessageCallback? onMessageReceived;
  final WebSocketErrorCallback? onError;
  
  WebSocketManager({
    this.onConnectionStatusChanged,
    this.onMessageReceived,
    this.onError,
  });

  bool get isConnected => _isConnected;
  DateTime? get lastSendTime => _lastSendTime;

  /// 建立 WebSocket 连接
  Future<bool> connect(String url, {Map<String, String>? headers}) async {
    for (int retry = 0; retry < _maxRetryCount; retry++) {
      try {
        logger.i('正在连接WebSocket (第${retry + 1}次): $url');

        // 创建WebSocket连接，带超时处理
        _channel = WebSocketChannel.connect(Uri.parse(url));
        
        // 等待连接建立或超时
        await Future.any([
          _channel!.ready,
          Future.delayed(const Duration(seconds: _connectTimeoutSeconds)).then((_) {
            throw TimeoutException('WebSocket连接超时');
          }),
        ]);
        
        // 监听 WebSocket 消息
        _channel!.stream.listen(
          _handleMessage, 
          onError: _handleError, 
          onDone: _handleDone,
          cancelOnError: false,
        );
        
        _isConnected = true;
        _lastSendTime = DateTime.now();
        _startHeartbeat();
        onConnectionStatusChanged?.call(_isConnected);
        
        logger.i('WebSocket连接成功');
        return true;
        
      } catch (e, stack) {
        logger.e('WebSocket连接失败 (第${retry + 1}次)', error: e, stackTrace: stack);
        _cleanup();
        
        if (retry < _maxRetryCount - 1) {
          final delay = _retryDelaySeconds * (retry + 1); // 指数退避
          logger.i('等待$delay秒后重试...');
          await Future.delayed(Duration(seconds: delay));
        }
      }
    }
    
    logger.e('WebSocket连接失败，已达最大重试次数');
    return false;
  }

  /// 处理 WebSocket 消息
  void _handleMessage(dynamic message) {
    try {
      _lastSendTime = DateTime.now();
      
      // 将消息转换为字符串（支持文本和二进制消息）
      String messageStr;
      if (message is String) {
        messageStr = message;
      } else {
        // 如果是二进制数据，尝试解码为UTF-8字符串
        messageStr = String.fromCharCodes(message);
      }
      
      onMessageReceived?.call(messageStr);
      
    } catch (e, stack) {
      logger.e('处理WebSocket消息失败', error: e, stackTrace: stack);
      onError?.call(e);
    }
  }

  /// 处理 WebSocket 错误
  void _handleError(dynamic error) {
    logger.e('WebSocket发生错误: $error');
    _cleanup();
    onError?.call(error);
  }

  /// 处理 WebSocket 关闭
  void _handleDone() {
    logger.i('WebSocket连接已关闭');
    _cleanup();
  }

  /// 启动心跳机制
  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(
      const Duration(seconds: _heartbeatIntervalSeconds),
      (timer) {
        if (_isConnected) {
          _checkConnectionHealth();
        }
      },
    );
  }

  /// 检查连接健康状态
  void _checkConnectionHealth() {
    if (_lastSendTime != null) {
      final timeSinceLastSend = DateTime.now().difference(_lastSendTime!);
      if (timeSinceLastSend.inSeconds > _heartbeatIntervalSeconds * 2) {
        logger.w('WebSocket连接可能已断开，超过${timeSinceLastSend.inSeconds}秒未收到消息');
        disconnect();
      }
    }
  }

  /// 发送数据
  Future<void> send(dynamic data) async {
    if (!_isConnected || _channel == null) {
      throw StateError('WebSocket未连接，无法发送数据');
    }

    try {
      _channel!.sink.add(data);
      _lastSendTime = DateTime.now();
    } catch (e, stack) {
      logger.e('发送WebSocket数据失败', error: e, stackTrace: stack);
      _cleanup();
      rethrow;
    }
  }

  /// 清理连接状态
  void _cleanup() {
    _isConnected = false;
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;
    onConnectionStatusChanged?.call(_isConnected);
  }

  /// 关闭连接
  void disconnect() {
    if (!_isConnected) {
      logger.d('WebSocket已经关闭');
      return;
    }
    
    logger.i('正在关闭WebSocket连接');
    
    try {
      _channel?.sink.close();
    } catch (e) {
      logger.w('关闭WebSocket时发生错误: $e');
    }
    
    _channel = null;
    _lastSendTime = null;
    _cleanup();
    
    logger.i('WebSocket连接已关闭');
  }

  /// 释放资源
  void dispose() {
    disconnect();
  }
}