import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:collection';
import 'package:dang_gui_admin/logger.dart';
import 'websocket_manager2.dart';

/// 实时语音转写服务
class RealtimeTranscriptionService {
  // 服务配置
  late String _serverUrl;                    // 可配置的服务器地址
  String? _apiKey;                           // API密钥认证
  String? _sessionId;                        // 会话ID
  
  // 音频处理核心参数（按文档要求）
  static const int _sampleRate = 16000;      // 16kHz采样率
  static const int _chunkSize = 960;         // 每次发送的数据大小960字节/帧 
  static const int _sendIntervalMs = 30;     // 每30毫秒发送一次
  static const int _maxQueueSize = 1000;     // 最大队列长度
  
  late final WebSocketManager _channel;
  final _resultController = StreamController<Map<String, dynamic>>.broadcast();
  
  Stream<Map<String, dynamic>> get resultStream => _resultController.stream;
  bool get isConnected => _channel.isConnected;

  int _totalFramesSent = 0;
  int _totalBytesSent = 0;
  final _audioDataQueue = Queue<Uint8List>();
  Timer? _sendTimer;
  bool _isRecognitionStarted = false;

  RealtimeTranscriptionService({
    required String serverUrl,
    String? apiKey,
    String? sessionId,
  }) {
    _serverUrl = serverUrl;
    _apiKey = apiKey;
    _sessionId = sessionId;
    
    _channel = WebSocketManager(
      onConnectionStatusChanged: _handleConnectionStatus,
      onMessageReceived: _handleMessage,
      onError: _handleError,
    );
  }

  /// 处理连接状态变化
  void _handleConnectionStatus(bool isConnected) {
    logger.i('WebSocket连接状态: ${isConnected ? '已连接' : '已断开'}');
    if (!isConnected) {
      _isRecognitionStarted = false;
      _stopSendTimer();
    }
  }

  /// 处理收到的消息
  void _handleMessage(String message) {
    try {
      final response = json.decode(message) as Map<String, dynamic>;
      final messageType = response['type'] as String?;
      
      switch (messageType) {
        case 'status':
          _handleStatusMessage(response);
          break;
        case 'result':
          _handleResultMessage(response);
          break;
        case 'error':
          _handleErrorMessage(response);
          break;
        default:
          logger.d('收到未知消息类型: $messageType, 消息: $message');
      }
    } catch (e, stack) {
      logger.e('解析消息失败', error: e, stackTrace: stack);
    }
  }

  /// 处理状态消息
  void _handleStatusMessage(Map<String, dynamic> response) {
    final data = response['data'] as Map<String, dynamic>?;
    final status = data?['status'] as String?;
    
    logger.i('收到状态消息: $status');
    _resultController.add(response);
  }

  /// 处理识别结果消息
  void _handleResultMessage(Map<String, dynamic> response) {
    final data = response['data'] as Map<String, dynamic>?;
    final text = data?['text'] as String?;
    final isFinal = data?['is_final'] as bool? ?? false;
    
    if (text != null && text.isNotEmpty) {
      logger.i('收到识别结果 (${isFinal ? '最终' : '实时'}): $text');
      _resultController.add(response);
    }
  }

  /// 处理错误消息
  void _handleErrorMessage(Map<String, dynamic> response) {
    final data = response['data'] as Map<String, dynamic>?;
    final errorCode = data?['error_code'] as String?;
    final message = data?['message'] as String?;
    
    logger.e('服务端错误: $errorCode - $message');
    _resultController.add(response);
  }

  /// 处理错误
  void _handleError(dynamic error) {
    logger.e('WebSocket错误: $error');
    _resultController.add({
      'type': 'error',
      'data': {'error_code': 'WEBSOCKET_ERROR', 'message': error.toString()}
    });
  }

  /// 建立连接
  Future<bool> connect() async {
    // 构建WebSocket URL
    final uri = Uri.parse(_serverUrl);
    final wsScheme = uri.scheme == 'https' ? 'wss' : 'ws';
    var wsUrl = '$wsScheme://${uri.host}:${uri.port}/ws/speech/recognize';
    
    // 添加查询参数
    final queryParams = <String, String>{};
    if (_sessionId != null) queryParams['token'] = _sessionId!;
    if (_apiKey != null) queryParams['apiKey'] = _apiKey!;
    
    if (queryParams.isNotEmpty) {
      wsUrl += '?${queryParams.entries
          .map((e) => '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
          .join('&')}';
    }
    
    logger.i('连接到WebSocket: $wsUrl');
    return await _channel.connect(wsUrl);
  }

  /// 配置识别参数
  /// 
  // realtime  600ms
  // balanced  1200ms
  // accurate  3000ms
  // precision 5000ms
  // ultra_precision 10000ms
  Future<void> configureRecognition({
    String modelName = 'paraformer-zh-streaming',
    String language = 'zh',
    bool useVad = true,
    bool usePunc = true,
    bool useItn = true,
    List<String> hotwords = const [],
    String bufferStrategy = 'accurate', 
  }) async {
    if (!isConnected) {
      throw StateError('WebSocket未连接');
    }

    final configMessage = {
      'type': 'config',
      'data': {
        'model_name': modelName,
        'language': language,
        'use_vad': useVad,
        'use_punc': usePunc,
        'use_itn': useItn,
        'hotwords': hotwords,
        'buffer_strategy': bufferStrategy,
      }
    };

    await _channel.send(json.encode(configMessage));
    logger.i('已发送配置消息');
  }

  /// 开始识别会话
  Future<void> startRecognition() async {
    if (!isConnected) {
      throw StateError('WebSocket未连接');
    }

    final startMessage = {
      'type': 'start',
      'data': {}
    };

    await _channel.send(json.encode(startMessage));
    _isRecognitionStarted = true;
    logger.i('已开始识别会话');
  }

  /// 发送音频数据
  Future<void> sendAudioData(Uint8List audioData) async {
    if (!isConnected || !_isRecognitionStarted) {
      logger.w('识别未开始，无法发送音频数据');
      return;
    }

    // 检查队列大小
    if (_audioDataQueue.length >= _maxQueueSize) {
      logger.w('队列已满，丢弃旧数据');
      _audioDataQueue.removeFirst();
    }

    // 将数据转换为 Uint8List 并加入队列
    _audioDataQueue.add(Uint8List.fromList(audioData));
    
    // 启动发送定时器
    _startSendTimer();
  }


  /// 启动发送定时器
  void _startSendTimer() {
    _sendTimer ??= Timer.periodic(
      const Duration(milliseconds: _sendIntervalMs), 
      (timer) {
        if (_audioDataQueue.isNotEmpty) {
          _sendQueuedData();
        }
      }
    );
  }

  /// 停止发送定时器
  void _stopSendTimer() {
    _sendTimer?.cancel();
    _sendTimer = null;
  }

  /// 发送队列中的数据
  void _sendQueuedData() {
    if (_audioDataQueue.isEmpty || !isConnected) return;

    try {
      // 累积音频数据到指定大小
      final buffer = <int>[];
      
      while (_audioDataQueue.isNotEmpty && buffer.length < _chunkSize) {
        final data = _audioDataQueue.removeFirst();
        buffer.addAll(data);
      }
      
      // 如果累积的数据超过块大小，将多余部分放回队列
      if (buffer.length > _chunkSize) {
        final excess = buffer.sublist(_chunkSize);
        _audioDataQueue.addFirst(Uint8List.fromList(excess));
        buffer.removeRange(_chunkSize, buffer.length);
      }
      
      // 只有当数据量达到指定大小时才发送
      if (buffer.length == _chunkSize) {
        final audioData = Uint8List.fromList(buffer);
        
        // 1. 创建metadata
        final metadata = jsonEncode({'type': 'audio_data'});
        final metadataBytes = utf8.encode(metadata);
        
        // 2. 创建完整的二进制消息
        final message = _createBinaryMessage(metadataBytes, audioData);
        
        // 3. 发送二进制数据
        _channel.send(message);

        _totalFramesSent++;
        _totalBytesSent += audioData.length;
        
        // logger.d('发送第 $_totalFramesSent 帧音频数据，大小: ${audioData.length} 字节');
        // logger.d('audioData: $audioData');

      }
      
    } catch (e, stack) {
      logger.e('发送音频数据失败', error: e, stackTrace: stack);
    }
  }


  /// 创建二进制消息格式
  Uint8List _createBinaryMessage(Uint8List metadata, Uint8List audioData) {
    // 消息格式: [4字节长度] + [metadata] + [音频数据]
    final metadataLength = metadata.length;
    final totalLength = 4 + metadataLength + audioData.length;
    
    final message = Uint8List(totalLength);
    final byteData = ByteData.view(message.buffer);
    
    // 写入metadata长度 (Big Endian)
    byteData.setUint32(0, metadataLength, Endian.big);
    
    // 写入metadata
    message.setRange(4, 4 + metadataLength, metadata);
    
    // 写入音频数据
    message.setRange(4 + metadataLength, totalLength, audioData);
    
    return message;
  }

  /// 停止识别
  Future<void> stopRecognition() async {
    logger.i('准备停止识别，发送剩余数据...');
    
    _stopSendTimer();

    // 发送剩余的音频数据
    while (_audioDataQueue.isNotEmpty && isConnected) {
      _sendQueuedData();
      await Future.delayed(const Duration(milliseconds: _sendIntervalMs));
    }

    if (!isConnected) {
      logger.w('WebSocket连接已断开，无法发送停止信号');
      return;
    }

    // 发送停止消息
    final stopMessage = {
      'type': 'stop',
      'data': {}
    };

    try {
      await _channel.send(json.encode(stopMessage));
      logger.i('已发送停止信号，共发送 $_totalFramesSent 帧，总计 $_totalBytesSent 字节');
      
      // 等待服务器处理完最后的数据
      await Future.delayed(const Duration(seconds: 2));
      
    } catch (e, stack) {
      logger.e('发送停止信号失败', error: e, stackTrace: stack);
    } finally {
      _cleanupSession();
    }
  }

  /// 清理会话状态
  void _cleanupSession() {
    _isRecognitionStarted = false;
    _totalFramesSent = 0;
    _totalBytesSent = 0;
    _audioDataQueue.clear();
  }

  /// 关闭连接
  void disconnect() {
    _stopSendTimer();
    _cleanupSession();
    _channel.disconnect();
  }

  /// 释放资源
  void dispose() {
    _stopSendTimer();
    _cleanupSession();
    logger.i('正在释放实时转写服务资源');
    _channel.dispose();
    _resultController.close();
    logger.i('实时转写服务资源已释放');
  }
} 