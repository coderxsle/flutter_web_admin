import 'package:get/get.dart';

import '../controllers/three_controller.dart';

class ThreeBinding extends Binding {
  @override
  List<Bind> dependencies() {
    return [
      Bind.lazyPut<ThreeController>(() => ThreeController()),
    ];
  }
}
  