import 'package:get/get.dart';

class ThreeController extends GetxController {
  //TODO: Implement ThreeController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }



  void increment() => count.value++;
}
