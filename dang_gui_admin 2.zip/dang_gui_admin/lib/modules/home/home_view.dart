import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:dang_gui_admin/components/load_state.dart';
import 'package:dang_gui_admin/components/navigator_title.dart';
import 'package:dang_gui_admin/components/page_bottom_button.dart';
import 'package:dang_gui_admin/theme/app_theme.dart';
import 'package:dang_gui_admin/app_manager.dart';
import 'package:dang_gui_admin/models/voice_record.dart';
import '../../theme/theme_selector.dart';
import 'controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});


    @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const NavigatorTitle("会议纪要"),
        elevation: 0,
        backgroundColor: Theme.of(context).colorScheme.surface,
        foregroundColor: Theme.of(context).colorScheme.onSurface,
        actions: buildActions(),
      ),
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: Column(
        children: [
          // 头部统计信息
          buildListHeaderView(),
          // 列表视图
          buildRefreshView(),
        ],
      ),
      bottomNavigationBar: pageBottomButton(
        title: '开始录音',
        onPressed: () => Get.toNamed('/funasr'),
      ),
    );
  }

  /// 构建头部统计信息
  Widget buildListHeaderView() {
    return Obx(() => Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: Theme.of(Get.context!).colorScheme.primaryContainer,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(
            Icons.mic_rounded,
            color: Theme.of(Get.context!).colorScheme.primary,
            size: 24,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '录音记录',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Theme.of(Get.context!).colorScheme.onPrimaryContainer,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '共 ${controller.dataList.length} 条录音',
                  style: TextStyle(
                    fontSize: 14,
                    color: Theme.of(Get.context!).colorScheme.onPrimaryContainer.withOpacity(0.7),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Theme.of(Get.context!).colorScheme.primary,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              '${controller.dataList.where((record) => record.transcription != null).length} 已转文字',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: Theme.of(Get.context!).colorScheme.onPrimary,
              ),
            ),
          ),
        ],
      ),
    ));
  }

  List<Widget> buildActions() {
    return [
      // 使用 Builder 获取正确的 context

      // 添加服务器设置按钮
      IconButton(
        tooltip: '服务器设置',
        icon: const Icon(Icons.settings),
        onPressed: () => controller.showServerSettingDialog(),
      ),

      // 添加主题设置按钮
      Builder(
        builder: (context) => IconButton(
          tooltip: '主题设置',
          icon: const Icon(Icons.color_lens),
          onPressed: () => Scaffold.of(context).openEndDrawer(),
        ),
      ),

      // 添加快速切换明暗模式按钮
      IconButton(
        tooltip: '切换明暗模式',
        icon: Icon(AppTheme.isDarkMode() ? Icons.dark_mode : Icons.light_mode),
        onPressed: () => AppTheme.toggleThemeMode(),
      ),

      // 退出登录
      IconButton(
        tooltip: '退出登录',
        icon: Icon(Icons.logout),
        onPressed: () => AppManager.signOut(),
      ),
    ];
  }

  // 右侧抽屉
  Widget buildEndDrawer() {
    return Drawer(
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.color_lens, size: 24),
                  const SizedBox(width: 8),
                  const Text(
                    '主题设置',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Get.back(),
                  ),
                ],
              ),
              const Divider(),
              const Expanded(
                child: SingleChildScrollView(
                  child: ThemeSelector(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  /// 构建可刷新的列表视图
  /// 包含下拉刷新、上拉加载、空状态、错误状态等
  Widget buildRefreshView() {
    return Obx(() => LayoutSubviews(
      state: controller.recode.value,
      controller: controller.refreshCtrl,
      onRefresh: controller.onRefresh,
      onLoad: controller.onLoad,
      child: controller.dataList.isEmpty 
        ? _buildEmptyState()
        : ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: controller.dataList.length,
            itemBuilder: (context, index) {
              final record = controller.dataList[index];
              return _buildRecordCard(record, index);
            },
          ),
    ));
  }

  /// 构建空状态视图
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.mic_off_rounded,
            size: 80,
            color: Colors.grey.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            '暂无录音记录',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: Colors.grey.withOpacity(0.8),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '点击下方按钮开始录音',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.withOpacity(0.6),
            ),
          ),
        ],
      ),
    );
  }

  /// 构建录音卡片
  Widget _buildRecordCard(VoiceRecord record, int index) {
    return Container(
      margin: const EdgeInsets.all(12), 
      decoration: BoxDecoration(
        color: Theme.of(Get.context!).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 0), 
          ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _showRecordDetail(record),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 标题和菜单按钮
              Row(
                children: [
                  Expanded(
                    child: Text(
                      record.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  PopupMenuButton<String>(
                    icon: Icon(
                      Icons.more_vert,
                      color: Colors.grey.withOpacity(0.7),
                    ),
                    onSelected: (value) {
                      switch (value) {
                        case 'rename':
                          _showRenameDialog(record);
                          break;
                        case 'delete':
                          controller.deleteRecord(record);
                          break;
                      }
                    },
                    itemBuilder: (context) => [
                      const PopupMenuItem(
                        value: 'rename',
                        child: Row(
                          children: [
                            Icon(Icons.edit, size: 18),
                            SizedBox(width: 8),
                            Text('重命名'),
                          ],
                        ),
                      ),
                      const PopupMenuItem(
                        value: 'delete',
                        child: Row(
                          children: [
                            Icon(Icons.delete, size: 18, color: Colors.red),
                            SizedBox(width: 8),
                            Text('删除', style: TextStyle(color: Colors.red)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              
              const SizedBox(height: 12),
              
              // 录音信息行
              Row(
                children: [
                  // 时长
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Theme.of(Get.context!).colorScheme.secondaryContainer,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.access_time,
                          size: 14,
                          color: Theme.of(Get.context!).colorScheme.onSecondaryContainer,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          record.formattedDuration,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: Theme.of(Get.context!).colorScheme.onSecondaryContainer,
                          ),
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(width: 12),
                  
                  // 录音时间
                  Text(
                    record.formattedRecordTime,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.withOpacity(0.8),
                    ),
                  ),
                  
                  const Spacer(),
                  
                  // 转文字按钮
                  _buildTranscriptionButton(record),
                ],
              ),
              
              // 转文字状态指示器
              if (record.transcription != null || record.isTranscribing)
                Container(
                  margin: const EdgeInsets.only(top: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: record.isTranscribing 
                      ? Colors.orange.withOpacity(0.1)
                      : Colors.green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: record.isTranscribing 
                        ? Colors.orange.withOpacity(0.3)
                        : Colors.green.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      if (record.isTranscribing)
                        SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
                          ),
                        )
                      else
                        Icon(
                          Icons.check_circle,
                          size: 16,
                          color: Colors.green,
                        ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          record.isTranscribing 
                            ? '正在转换为文字...' 
                            : '已转换为文字',
                          style: TextStyle(
                            fontSize: 12,
                            color: record.isTranscribing ? Colors.orange : Colors.green,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                      if (record.transcription != null)
                        TextButton(
                          onPressed: () => controller.onTranscriptionTap(record),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            minimumSize: Size.zero,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                          child: Text(
                            '查看',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.green,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  /// 构建转文字按钮
  Widget _buildTranscriptionButton(VoiceRecord record) {
    if (record.isTranscribing) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.orange.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.orange, width: 1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 12,
              height: 12,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
              ),
            ),
            const SizedBox(width: 6),
            Text(
              '转换中',
              style: TextStyle(
                fontSize: 12,
                color: Colors.orange,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      );
    }

    return ElevatedButton(
      onPressed: () => controller.onTranscriptionTap(record),
      style: ElevatedButton.styleFrom(
        backgroundColor: record.transcription != null 
          ? Theme.of(Get.context!).colorScheme.secondaryContainer
          : Theme.of(Get.context!).colorScheme.primary,
        foregroundColor: record.transcription != null
          ? Theme.of(Get.context!).colorScheme.onSecondaryContainer
          : Theme.of(Get.context!).colorScheme.onPrimary,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        elevation: 0,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            record.transcription != null ? Icons.visibility : Icons.text_fields,
            size: 16,
          ),
          const SizedBox(width: 6),
          Text(
            record.transcriptionButtonText,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  /// 显示录音详情
  void _showRecordDetail(VoiceRecord record) {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Theme.of(Get.context!).colorScheme.surface,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    record.title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => Get.close(),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _buildDetailRow('录音时长', record.formattedDuration),
            _buildDetailRow('录音时间', record.formattedRecordTime),
            _buildDetailRow('文件路径', record.filePath),
            if (record.transcription != null)
              _buildDetailRow('转文字状态', '已完成'),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      Get.back();
                      // TODO: 实现播放功能
                      Get.snackbar('提示', '播放功能开发中');
                    },
                    child: const Text('播放录音'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Get.close();
                      controller.onTranscriptionTap(record);
                    },
                    child: Text(record.transcriptionButtonText),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      isScrollControlled: true,
    );
  }

  /// 构建详情行
  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.withOpacity(0.8),
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// 显示重命名对话框
  void _showRenameDialog(VoiceRecord record) {
    final textController = TextEditingController(text: record.title);
    Get.dialog(
      AlertDialog(
        title: const Text('重命名录音'),
        content: TextField(
          controller: textController,
          decoration: const InputDecoration(
            labelText: '录音标题',
            border: OutlineInputBorder(),
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('取消'),
          ),
          ElevatedButton(
            onPressed: () {
              if (textController.text.trim().isNotEmpty) {
                final index = controller.dataList.indexWhere((item) => item.id == record.id);
                if (index != -1) {
                  controller.dataList[index] = record.copyWith(title: textController.text.trim());
                  Get.back();
                  Get.snackbar('提示', '重命名成功');
                }
              }
            },
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }
}
