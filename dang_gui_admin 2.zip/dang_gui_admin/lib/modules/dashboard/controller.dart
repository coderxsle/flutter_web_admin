import 'package:get/get.dart';

class DashboardController extends GetxController {
  //TODO: Implement HomeController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }
  void increment() => count.value++;
}
