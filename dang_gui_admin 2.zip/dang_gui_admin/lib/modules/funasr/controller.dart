import 'dart:io';
import 'dart:async';
import 'dart:typed_data';
import 'package:get/get.dart';
import 'package:dang_gui_admin/config/app_config.dart';
import 'package:dang_gui_admin/loacal_storage.dart';
import 'realtime_service.dart';
import 'package:record/record.dart';
import 'package:flutter/material.dart';
import 'package:dang_gui_admin/logger.dart';
import 'package:dang_gui_admin/app_manager.dart';
import 'package:dang_gui_admin/services/recorder_service.dart';
import 'package:path_provider/path_provider.dart';


// 实时转写控制器
class FunasrController extends GetxController {

  // 录音机服务
  late final RecorderService _recorderService;
  
  // FunASR实时转写服务
  late final FunasrRealtimeService _realtimeService;

  // 滚动控制器，用于自动滚动到底部
  ScrollController? scrollController;

  // 录音时长计时器
  Timer? _recordingTimer;
  int _recordingDuration = 0; // 录音时长（秒）
  
  int get recordingDuration => _recordingDuration;
  set recordingDuration(int value) {
    if (_recordingDuration != value) {
      _recordingDuration = value;
      update(['recordingDuration']);
    }
  }

  // 格式化录音时长为 MM:SS 格式
  String get formattedDuration {
    final minutes = (_recordingDuration ~/ 60).toString().padLeft(2, '0');
    final seconds = (_recordingDuration % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }
  
  // 实时转写状态
  bool _isRealtimeTranscribing = false;
  bool get isRealtimeTranscribing => _isRealtimeTranscribing;
  set isRealtimeTranscribing(bool value) {
    if (_isRealtimeTranscribing != value) {
      _isRealtimeTranscribing = value;
      update(['isRealtimeTranscribing']);
    }
  }

  // 实时转写转写文本
  String _transcriptionText = '';
  String get transcriptionText => _transcriptionText;
  set transcriptionText(String value) {
    if (_transcriptionText != value) {
      _transcriptionText = value;
      update(['transcriptionText']);
      // 文本更新后自动滚动到底部
      _scrollToBottom();
    }
  }

  // 2pass模式下的文本管理
  String _finalText = '';      // 最终确定的文本（2pass-offline结果）
  String _tempText = '';       // 临时实时文本（2pass-online结果）
  
  // 实时写入文件相关
  File? _transcriptionFile;    // 转写文件对象（完整格式：时间戳+讲话人+内容）
  File? _speakerFile;          // 讲话人文件（讲话人+内容）
  File? _contentFile;          // 纯内容文件（仅内容）
  String? _currentRecordingPath; // 当前录音文件路径

  // 自动滚动到底部
  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scrollController?.hasClients == true) {
        scrollController?.animateTo(
          scrollController!.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  /// 显示说话人区分功能提示弹窗
  void showSpeakerIdentificationDialog() {
    Get.dialog(
      AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.people_alt_outlined,
              color: Theme.of(Get.context!).primaryColor,
              size: 24,
            ),
            const SizedBox(width: 12),
            const Text(
              '区分说话人',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '受当前服务器性能，和算法架构的限制，暂不支持实时区分说话人。',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Color.fromARGB(255, 224, 18, 4),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '说话人识别需要分析完整音频中的声纹特征进行聚类分析，因此需要在录音结束后进行处理。',
              style: TextStyle(
                fontSize: 14,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              '录音结束后会自动进行说话人区分，并标注到对应文本中。',
              style: TextStyle(
                fontSize: 16,
                height: 1.5,
                color: Colors.green[600],
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Get.close(),
            child: Text(
              '我知道了',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        contentPadding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
        actionsPadding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
      ),
    );
  }


  @override
  Future<void> onInit() async {
    super.onInit();
    
    // 初始化录音服务
    _recorderService = RecorderService();

    // ScrollController 用于控制滚动
    scrollController = ScrollController();

    // 实时转写服务（使用默认热词）
    logger.i('实时转写服务: ${AppManager.userToken}');
    
    // 从本地存储读取服务器地址，如果没有则使用默认值
    final savedServerUrl = localStorageRead<String>('funasrBaseURL') ?? funasrBaseURL;
    logger.i('使用服务器地址: $savedServerUrl');
    
    _realtimeService = FunasrRealtimeService(
      serverUrl: savedServerUrl,
      sessionId: AppManager.userToken,
      // 可以自定义热词
      // hotwords: {
      //   "阿里巴巴": 20,      // 公司名称，权重20
      //   "达摩院": 20,        // 部门名称，权重20  
      //   "夜雨飘零": 20,      // 人名，权重20
      //   "语音识别": 15,      // 技术术语，权重15
      //   "人工智能": 15       // 技术术语，权重15
      // }
      hotwords: {
        "盛邦集团": 20,
        "闫总": 30,
        "李哥": 30,
        "顺利": 30,
        "月龙": 30,
        "李超": 30,
        "亚琪": 30,
        "钟文": 30,
        "尚娟": 30,
        "陈奇": 30,
        "国盛": 30,
        "宇航": 30,
        "雪松": 30,
        "李爽": 30,
        "王森": 30,
        "晓明": 20,
        "张峰": 20,
        "梦楠": 20,
      },
    );
    
    // 先连接WebSocket
    await _realtimeService.connect();

  }

  @override
  void onClose() {
    _recordingTimer?.cancel();
    scrollController = null;
    
    // 如果还在录音状态，写入异常结束标记到三个文件
    if (isRealtimeTranscribing) {
      final endTime = DateTime.now().toString();
      final endContent = '\n=== 语音转写异常结束 $endTime ===\n';
      
      if (_transcriptionFile != null) {
        _transcriptionFile!.writeAsString(endContent, mode: FileMode.append).catchError((error) {
          logger.e('写入完整格式文件异常结束标记失败', error: error);
          return _transcriptionFile!;
        });
      }
      if (_speakerFile != null) {
        _speakerFile!.writeAsString(endContent, mode: FileMode.append).catchError((error) {
          logger.e('写入讲话人格式文件异常结束标记失败', error: error);
          return _transcriptionFile!;
        });
      }
      if (_contentFile != null) {
        _contentFile!.writeAsString(endContent, mode: FileMode.append).catchError((error) {
          logger.e('写入纯内容格式文件异常结束标记失败', error: error);
          return _transcriptionFile!;
        });
      }
    }
    
    // 清理文件引用
    _speakerFile = null;
    _contentFile = null;
    _transcriptionFile = null;
    _currentRecordingPath = null;
    
    _realtimeService.dispose();
    _recorderService.dispose();
    super.onClose();
  }

  // 开始录音计时
  void _startRecordingTimer() {
    recordingDuration = 0;
    _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      recordingDuration = recordingDuration + 1;
    });
  }

  // 停止录音计时
  void _stopRecordingTimer() {
    _recordingTimer?.cancel();
    _recordingTimer = null;
  }

  // 开始实时语音转写
  // 实时转写需要录音，所以需要先检查录音权限
  // 如果已经在录音，则停止录音和转写
  // 如果未录音，则开始录音并获取音频流
  // 然后开始实时转写
  Future<void> startRealtimeTranscription() async {
    if (isRealtimeTranscribing) {
      isRealtimeTranscribing = false;

      // 停止录音计时
      _stopRecordingTimer();

      // 先停止转写
      await _realtimeService.stopRecognition();
      
      // 再停止录音
      final recordingPath = await _recorderService.stopRecording();
      if (recordingPath != null) {
        logger.i('录音文件已保存到: $recordingPath');
      }
      
      // 写入结束标记到三个转写文件
      final endTime = DateTime.now().toString();
      if (_transcriptionFile != null) {
        await _transcriptionFile!.writeAsString('\n=== 完整转写记录结束 $endTime ===\n', mode: FileMode.append);
        logger.i('完整格式转写文件已完成: ${_transcriptionFile!.path}');
      }
      if (_speakerFile != null) {
        await _speakerFile!.writeAsString('\n=== 讲话人转写记录结束 $endTime ===\n', mode: FileMode.append);
        logger.i('讲话人格式转写文件已完成: ${_speakerFile!.path}');
      }
      if (_contentFile != null) {
        await _contentFile!.writeAsString('\n=== 纯内容转写记录结束 $endTime ===\n', mode: FileMode.append);
        logger.i('纯内容格式转写文件已完成: ${_contentFile!.path}');
      }
      
      // 复制文件到Downloads文件夹
      await _copyFilesToDownloads();
      
      logger.i('转写文本内容: $transcriptionText');
      
      _realtimeService.disconnect();
      return;
    }

    isRealtimeTranscribing = true;
    transcriptionText = '';
    
    // 重置2pass模式的文本缓存
    _finalText = '';
    _tempText = '';

    try {

      // 先连接WebSocket
      // 改为进入页面就先链接 WebSocket
      // final connected = await _realtimeService.connect();
      // if (!connected) throw '实时转写服务连接失败';

      // 开始录音计时
      _startRecordingTimer();

      // 配置录音参数
      const config = RecordConfig(
        encoder: AudioEncoder.pcm16bits,      // PCM 16bit
        sampleRate: 16000,                    // 16kHz 采样率
        numChannels: 1,                       // 单声道
      );

      
      // 开始录音并获取音频流
      _recorderService.startRecording(config, (stream) {
        _listenAudioStream(stream);
      });

      // 提前生成转写文件路径（基于时间戳）
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final documentsDir = await getApplicationDocumentsDirectory();
      _currentRecordingPath = '${documentsDir.path}/recording_$timestamp.pcm';
      
      // 创建三个不同格式的转写文件
      final baseDir = documentsDir.path;
      final startTime = DateTime.now().toString();
      
      // 1. 完整格式：时间戳+讲话人+内容
      _transcriptionFile = File('$baseDir/recording_${timestamp}_full.txt');
      await _transcriptionFile!.writeAsString('=== 完整转写记录（时间戳+讲话人+内容）开始 $startTime ===\n\n');
      
      // 2. 讲话人+内容格式
      _speakerFile = File('$baseDir/recording_${timestamp}_speaker.txt');
      await _speakerFile!.writeAsString('=== 讲话人转写记录（讲话人+内容）开始 $startTime ===\n\n');
      
      // 3. 纯内容格式
      _contentFile = File('$baseDir/recording_${timestamp}_content.txt');
      await _contentFile!.writeAsString('=== 纯内容转写记录 开始 $startTime ===\n\n');
      
      logger.i('转写文件已创建:');
      logger.i('  完整格式: ${_transcriptionFile!.path}');
      logger.i('  讲话人格式: ${_speakerFile!.path}');
      logger.i('  纯内容格式: ${_contentFile!.path}');

      // 订阅转写结果
      _listenTranscriptionResult();

      // 开始识别会话（发送配置消息）
      await _realtimeService.startRecognition(
        customMode: "2pass",              // 启用2pass模式
        customChunkSize: [5, 10, 5],      // 控制延迟和准确率平衡
        customChunkInterval: 10,          // 处理间隔
      );
      
    } catch (e) {
      logger.e('实时转写出错', error: e);
      _stopRecordingTimer();
      await _recorderService.stopRecording();
      _realtimeService.disconnect();
      transcriptionText = '实时转写出错: $e';
      isRealtimeTranscribing = false;
    }
  }



  // 订阅录音机开始录音的音频流
  // 开始录音后，需要订阅录音机开始录音的音频流，并发送给实时转写服务
  void _listenAudioStream(Stream<Uint8List> stream) {
    logger.i('开始订阅音频流');
    stream.listen((data) async {
        if (isRealtimeTranscribing) {
          try {
            await _realtimeService.sendAudioData(Uint8List.fromList(data));
          } catch (e) {
            logger.e('发送音频数据失败', error: e);
            isRealtimeTranscribing = false;
          }
        }
      },
      onError: (error) {
        logger.e('音频流错误', error: error);
        isRealtimeTranscribing = false;
      },
      onDone: () {
        logger.i('音频流结束');
        isRealtimeTranscribing = false;
      },
    );
  }



  // 订阅转写结果
  void _listenTranscriptionResult() {
    _realtimeService.resultStream.listen((result) {
        // final status = result.status;
        final text = result.text;
        final isFinal = result.isFinal;
        final status = result.status;
        final mode = result.mode;
        final speaker = result.speakerInfo?.name ?? '';
        final timestamp = DateTime.now().toString();
            
        if (text.isNotEmpty) {
          // 根据模式处理文本
          if (status == 'partial' && mode == '2pass-online') {
            // 在线模式：实时显示，但是临时的
            _tempText += text;
          } else if (status == 'final' && mode == '2pass-offline') {
            // 离线模式：更准确，替换对应的临时结果
            if (speaker.isNotEmpty) {
              _finalText += "$speaker: \n$text\n";
            } else {
              _finalText += "$text\n";
            }
            // '[$timestamp][$speaker] $text\n';
            _tempText = '';  // 清空临时文本，因为已经被离线结果替换
            
            // 实时写入最终确定的文本到文件
            _writeToFileRealtime(text, speaker, timestamp);
            
          } else {
            // 未知模式，记录日志
            logger.w('未知的mode值: "$mode", 直接追加到_finalText');
            _finalText += text;
            
            // 写入未知模式的文本
            // _writeToFileRealtime(text, 'unknown-$mode-$status', timestamp);
          }
          // 显示组合结果：最终文本 + 临时文本
          transcriptionText = _finalText + _tempText;
        }
        
        // 识别结束处理
        if (isFinal) {
          // 只有2pass-offline的final才清空临时缓存
          // 2pass-online的final只是表示这段在线识别结束，等待离线优化结果
          if (mode == '2pass-offline') {
            _tempText = '';
            // 重新更新显示文本
            transcriptionText = _finalText + _tempText;
          }
        }

      },
      onError: (error) {
        logger.e('转写出错', error: error);
        transcriptionText += '\n[转写出错: $error]';
        isRealtimeTranscribing = false;
        
        // 写入错误信息到文件
        _writeToFileRealtime('[转写出错: $error]', '系统', DateTime.now().toString());
      },
    );
  }

  /// 实时写入文本到三个不同格式的文件
  void _writeToFileRealtime(String text, String speaker, String timestamp) {
    if (_transcriptionFile == null || _speakerFile == null || _contentFile == null) return;
    
    try {
      // 1. 完整格式：时间戳+讲话人+内容
      final fullContent = '[$timestamp][$speaker] $text\n';
      _transcriptionFile!.writeAsString(fullContent, mode: FileMode.append).catchError((error) {
        logger.e('写入完整格式文件失败', error: error);
        return _transcriptionFile!;
      });
      
      // 2. 讲话人+内容格式
      final speakerContent = '$speaker: $text\n';
      _speakerFile!.writeAsString(speakerContent, mode: FileMode.append).catchError((error) {
        logger.e('写入讲话人格式文件失败', error: error);
        return _transcriptionFile!;
      });
      
      // 3. 纯内容格式
      final contentOnly = '$text\n';
      _contentFile!.writeAsString(contentOnly, mode: FileMode.append).catchError((error) {
        logger.e('写入纯内容格式文件失败', error: error);
        return _transcriptionFile!;
      });
      
      logger.d('实时写入三个文件: [$speaker] $text');
    } catch (e) {
      logger.e('实时写入文件出错', error: e);
    }
  }

  /// 复制转写文件到Downloads文件夹
  Future<void> _copyFilesToDownloads() async {
    try {
      // 获取Downloads文件夹路径
      Directory? downloadsDir;
      
      if (Platform.isAndroid) {
        // Android平台：使用外部存储的Downloads目录
        downloadsDir = Directory('/storage/emulated/0/Download');
        if (!await downloadsDir.exists()) {
          // 如果标准路径不存在，尝试其他可能的路径
          final externalDir = await getExternalStorageDirectory();
          if (externalDir != null) {
            downloadsDir = Directory('${externalDir.parent.parent.parent.parent.path}/Download');
          }
        }
      } else if (Platform.isIOS) {
        // iOS平台：使用应用的Documents目录（iOS没有公共Downloads文件夹）
        downloadsDir = await getApplicationDocumentsDirectory();
      }
      
      if (downloadsDir == null || !await downloadsDir.exists()) {
        logger.w('无法找到Downloads文件夹，使用Documents目录');
        downloadsDir = await getApplicationDocumentsDirectory();
      }
      
      // 创建带时间戳的文件名前缀
      final now = DateTime.now();
      final dateStr = '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}';
      final timeStr = '${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}${now.second.toString().padLeft(2, '0')}';
      final prefix = '盛邦会议记录_${dateStr}_$timeStr';
      
      // 复制三个文件
      final List<Future<void>> copyTasks = [];
      
      if (_transcriptionFile != null && await _transcriptionFile!.exists()) {
        final targetPath = '${downloadsDir.path}/${prefix}_完整记录.txt';
        copyTasks.add(_copyFile(_transcriptionFile!, targetPath, '完整记录'));
      }
      
      if (_speakerFile != null && await _speakerFile!.exists()) {
        final targetPath = '${downloadsDir.path}/${prefix}_讲话人记录.txt';
        copyTasks.add(_copyFile(_speakerFile!, targetPath, '讲话人记录'));
      }
      
      if (_contentFile != null && await _contentFile!.exists()) {
        final targetPath = '${downloadsDir.path}/${prefix}_纯内容.txt';
        copyTasks.add(_copyFile(_contentFile!, targetPath, '纯内容'));
      }
      
      // 并行执行所有复制任务
      await Future.wait(copyTasks);
      
      logger.i('所有转写文件已复制到Downloads文件夹: ${downloadsDir.path}');
      
    } catch (e, stack) {
      logger.e('复制文件到Downloads文件夹失败', error: e, stackTrace: stack);
    }
  }
  
  /// 复制单个文件
  Future<void> _copyFile(File sourceFile, String targetPath, String fileType) async {
    try {
      await sourceFile.copy(targetPath);
      logger.i('$fileType文件已复制到: $targetPath');
    } catch (e) {
      logger.e('复制$fileType文件失败', error: e);
    }
  }

}

