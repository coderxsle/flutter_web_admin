import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:collection';
import 'package:dang_gui_admin/logger.dart';
import 'package:dang_gui_admin/models/speech_recogntiton.dart';
import 'websocket_manager3.dart';

/// 实时语音转写服务
class FunasrRealtimeService {
  // 服务配置
  late String _serverUrl;                    // 可配置的服务器地址
  
  // 音频处理核心参数
  static const int _sendSize = 1920;         // 每次发送1920字节
  static const int _sendIntervalMs = 30;     // 每30毫秒发送一次
  static const int _maxQueueSize = 1000;     // 最大队列长度
  
  // FunASR配置参数
  static const String _mode = "2pass";              // 2pass 2pass_vad
  static const List<int> _chunkSize = [5, 10, 5];   // 5, 10, 5
  static const int _chunkInterval = 10;             // 10
  static const String _wavFormat = "pcm";           // pcm
  static const String _wavName = "default";         // 音频名称
  
  late final WebSocketManager _channel;
  final _resultController = StreamController<SpeechRecognitionResult>.broadcast();
  
  Stream<SpeechRecognitionResult> get resultStream => _resultController.stream;
  bool get isConnected => _channel.isConnected;

  int _totalFramesSent = 0;
  int _totalBytesSent = 0;
  final _audioDataQueue = Queue<Uint8List>();
  Timer? _sendTimer;
  bool _isRecognitionStarted = false;
  
  // 热词配置（匹配Java格式）
  Map<String, int> _hotwords = {
    "阿里巴巴": 20,
    "达摩院": 20,
    "夜雨飘零": 20,
  };

  FunasrRealtimeService({
    required String serverUrl,
    String? apiKey,
    String? sessionId,
    Map<String, int>? hotwords,
  }) {
    _serverUrl = serverUrl;
    if (hotwords != null) {
      _hotwords = hotwords;
    }
    
    _channel = WebSocketManager(
      onConnectionStatusChanged: _handleConnectionStatus,
      onMessageReceived: _handleMessage,
      onError: _handleError,
    );
  }

  /// 处理连接状态变化
  void _handleConnectionStatus(bool isConnected) {
    logger.i('WebSocket连接状态: ${isConnected ? '已连接' : '已断开'}');
    if (!isConnected) {
      _isRecognitionStarted = false;
      _stopSendTimer();
    }
  }

  /// 处理收到的消息
  void _handleMessage(String message) {
    try {
      // logger.i('收到消息: $message');
      final result = SpeechRecognitionResult.fromJson(json.decode(message));
      // 直接处理FunASR格式的消息
      if (result.text.isNotEmpty) {
        _handleFunasrMessage(result);
      }
      //  else {
      //   // 处理其他格式消息
      //   final messageType = result.status;
        
      //   switch (messageType) {
      //     case 'partial':
      //       _handleStatusMessage(result);
      //       break;
      //     case 'final':
      //       _handleResultMessage(result);
      //       break;
      //     case 'error':
      //       _handleErrorMessage(result);
      //       break;
      //     default:
      //       logger.d('收到未知消息类型: $messageType, 消息: $message');
      //   }
      // }
    } catch (e, stack) {
      logger.e('解析消息失败', error: e, stackTrace: stack);
    }
  }

  /// 处理FunASR格式的消息
  void _handleFunasrMessage(SpeechRecognitionResult result) {
    final name = result.speakerInfo?.name;
    final text = result.text;
    final isFinal = result.isFinal;

    if (text.isNotEmpty) {
      logger.i('收到识别结果 (${isFinal ? '最终' : '实时'}):  $name：$text');
      _resultController.add(result);
    }
    
    // 如果是最终结果，可能需要关闭连接
    if (isFinal) {
      logger.i('收到最终结果，识别完成');
    }
  }

  /// 处理状态消息
  // void _handleStatusMessage(Map<String, dynamic> response) {
  //   final data = response['data'] as Map<String, dynamic>?;
  //   final status = data?['status'] as String?;
    
  //   logger.i('收到状态消息: $status');
  //   _resultController.add(response);
  // }

  /// 处理识别结果消息
  // void _handleResultMessage(Map<String, dynamic> response) {
  //   final data = response['data'] as Map<String, dynamic>?;
  //   final text = data?['text'] as String?;
  //   final isFinal = data?['is_final'] as bool? ?? false;
    
  //   if (text != null && text.isNotEmpty) {
  //     logger.i('收到识别结果 (${isFinal ? '最终' : '实时'}): $text');
  //     _resultController.add(response);
  //   }
  // }

  /// 处理错误消息
  // void _handleErrorMessage(Map<String, dynamic> response) {
  //   final data = response['data'] as Map<String, dynamic>?;
  //   final errorCode = data?['error_code'] as String?;
  //   final message = data?['message'] as String?;
    
  //   logger.e('服务端错误: $errorCode - $message');
  //   _resultController.add(response);
  // }

  /// 处理错误
  void _handleError(dynamic error) {
    logger.e('WebSocket错误: $error');
    // _resultController.add(SpeechRecognitionResult(
    //   messageId: 'error',
    //   text: error.toString(),
    //   status: 'error',
    //   sessionId: 'error',
    //   startTime: 0,
    //   endTime: 0,
    //   duration: 0,
    //   confidence: 0,
    //   timestamp: 0,
    //   mode: 'error',
    //   speakerInfo: null,
    //   metadata: null,
    // ));
  }

  /// 建立连接
  Future<bool> connect() async {
    return await _channel.connect(_serverUrl);
  }

  /// 开始识别会话（发送初始配置消息，匹配Java格式）
  Future<void> startRecognition({
    String? customMode,
    List<int>? customChunkSize, 
    int? customChunkInterval,
    Map<String, int>? customHotwords,
  }) async {
    if (!isConnected) {
      throw StateError('WebSocket未连接');
    }

    // 准备热词JSON字符串（匹配Java格式）
    String? hotwordsJson;
    final hotwords = customHotwords ?? _hotwords;
    if (hotwords.isNotEmpty) {
      hotwordsJson = json.encode(hotwords);
    }

    // 构建消息（完全匹配Java getMessage方法）
    final message = {
      'mode': customMode ?? _mode,
      'chunk_size': customChunkSize ?? _chunkSize,
      'chunk_interval': customChunkInterval ?? _chunkInterval,
      'wav_name': _wavName,
      'wav_format': _wavFormat,
      'is_speaking': true,
    };
    
    // 添加热词（如果有）
    if (hotwordsJson != null) {
      message['hotwords'] = hotwordsJson;
    }

    final messageJson = json.encode(message);
    logger.i('发送识别配置: $messageJson');
    
    await _channel.send(messageJson);
    _isRecognitionStarted = true;
    logger.i('已开始识别会话');
  }

  /// 发送音频数据
  Future<void> sendAudioData(Uint8List audioData) async {
    if (!isConnected || !_isRecognitionStarted) {
      logger.w('识别未开始，无法发送音频数据');
      return;
    }

    // 检查队列大小
    if (_audioDataQueue.length >= _maxQueueSize) {
      logger.w('队列已满，丢弃旧数据');
      _audioDataQueue.removeFirst();
    }

    // 将数据转换为 Uint8List 并加入队列
    _audioDataQueue.add(Uint8List.fromList(audioData));
    
    // 启动发送定时器
    _startSendTimer();
  }

  /// 启动发送定时器
  void _startSendTimer() {
    _sendTimer ??= Timer.periodic(
      const Duration(milliseconds: _sendIntervalMs), 
      (timer) {
        if (_audioDataQueue.isNotEmpty) {
          _sendQueuedData();
        }
      }
    );
  }

  /// 停止发送定时器
  void _stopSendTimer() {
    _sendTimer?.cancel();
    _sendTimer = null;
  }

  /// 发送队列中的数据
  void _sendQueuedData() {
    if (_audioDataQueue.isEmpty || !isConnected) return;

    try {
      // 累积音频数据到指定大小
      final buffer = <int>[];
      
      while (_audioDataQueue.isNotEmpty && buffer.length < _sendSize) {
        final data = _audioDataQueue.removeFirst();
        buffer.addAll(data);
      }
      
      // 如果累积的数据超过发送大小，将多余部分放回队列
      if (buffer.length > _sendSize) {
        final excess = buffer.sublist(_sendSize);
        _audioDataQueue.addFirst(Uint8List.fromList(excess));
        buffer.removeRange(_sendSize, buffer.length);
      }
      
      // 只有当数据量达到指定大小时才发送）
      if (buffer.length == _sendSize) {
        final audioData = Uint8List.fromList(buffer);
        
        // 直接发送二进制数据
        _channel.send(audioData);

        _totalFramesSent++;
        _totalBytesSent += audioData.length;
        
        // logger.d('发送第 $_totalFramesSent 帧音频数据，大小: ${audioData.length} 字节');
        // logger.d('audioData: $audioData');

      }
      
    } catch (e, stack) {
      logger.e('发送音频数据失败', error: e, stackTrace: stack);
    }
  }

  /// 停止识别
  Future<void> stopRecognition() async {
    logger.i('准备停止识别，发送剩余数据...');
    
    _stopSendTimer();

    // 发送剩余的音频数据
    while (_audioDataQueue.isNotEmpty && isConnected) {
      _sendQueuedData();
      await Future.delayed(const Duration(milliseconds: _sendIntervalMs));
    }

    if (!isConnected) {
      logger.w('WebSocket连接已断开，无法发送停止信号');
      return;
    }

    // 发送停止消息
    final stopMessage = {
      'is_speaking': false,
    };

    try {
      await _channel.send(json.encode(stopMessage));
      logger.i('已发送停止信号，共发送 $_totalFramesSent 帧，总计 $_totalBytesSent 字节');
      
      // 等待服务器处理完最后的数据
      await Future.delayed(const Duration(seconds: 2));
      
    } catch (e, stack) {
      logger.e('发送停止信号失败', error: e, stackTrace: stack);
    } finally {
      _cleanupSession();
    }
  }

  /// 清理会话状态
  void _cleanupSession() {
    _isRecognitionStarted = false;
    _totalFramesSent = 0;
    _totalBytesSent = 0;
    _audioDataQueue.clear();
  }

  /// 关闭连接
  void disconnect() {
    _stopSendTimer();
    _cleanupSession();
    _channel.disconnect();
  }

  /// 释放资源
  void dispose() {
    _stopSendTimer();
    _cleanupSession();
    logger.i('正在释放实时转写服务资源');
    _channel.dispose();
    _resultController.close();
    logger.i('实时转写服务资源已释放');
  }
  
  /// 设置热词
  void setHotwords(Map<String, int> hotwords) {
    _hotwords = hotwords;
  }
  
  /// 获取当前热词
  Map<String, int> get hotwords => Map.from(_hotwords);
} 