import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:dang_gui_admin/config/app_config.dart';
import 'controller.dart';

class LaunchingView extends GetView<LaunchingController> {
  const LaunchingView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Obx(() => FadeTransition(
              opacity: controller.fadeAnimation,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const ApplicationLogo(),
                  const SizedBox(height: 24),
                  Text(
                    appName,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Noto Sans SC',
                        ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    controller.statusText.value,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).colorScheme.secondary,
                          fontFamily: 'Noto Sans SC',
                        ),
                  ),
                ],
              ),
            )),
      ),
    );
  }
}

/// A widget that represents the application logo.
class ApplicationLogo extends StatelessWidget {
  const ApplicationLogo({super.key, this.iconWidth = 70});
  final double iconWidth;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.7),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.25),
            blurRadius: 20,
            offset: const Offset(0, 0),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Image.asset('assets/icons/app_icon.png', width: 100, height: 100),
      ),
    );
  }
}