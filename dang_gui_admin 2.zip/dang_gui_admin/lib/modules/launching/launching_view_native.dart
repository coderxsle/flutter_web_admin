import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:dang_gui_admin/logger.dart';
import 'package:dang_gui_admin/app_manager.dart';
import 'package:dang_gui_admin/config/app_config.dart';

class LaunchingViewNative extends StatefulWidget {
  const LaunchingViewNative({super.key});

  @override
  State<LaunchingViewNative> createState() => _LaunchingViewNativeState();
}

class _LaunchingViewNativeState extends State<LaunchingViewNative> with TickerProviderStateMixin {
  
  late LaunchingControllerNative _controller;

  @override
  void initState() {
    super.initState();
    _controller = LaunchingControllerNative(
      vsync: this,
      onNavigate: _navigateToNextPage,
    );
    _controller.initialize();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _navigateToNextPage(String route) {
    if (mounted) {
      Navigator.of(context).pushReplacementNamed(route);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blue,
      child: Center(
        child: AnimatedBuilder(
          animation: _controller.fadeAnimation,
          builder: (context, child) {
            return FadeTransition(
              opacity: _controller.fadeAnimation,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  const ApplicationLogo(),
                  const SizedBox(height: 24),
                  Text(
                    appName,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Noto Sans SC',
                        ),
                  ),
                  const SizedBox(height: 16),
                  AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return Text(
                        _controller.statusText,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Theme.of(context).colorScheme.secondary,
                              fontFamily: 'Noto Sans SC',
                            ),
                      );
                    },
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

/// A widget that represents the application logo.
class ApplicationLogo extends StatelessWidget {
  const ApplicationLogo({super.key, this.iconWidth = 70});
  final double iconWidth;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.7),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.25),
            blurRadius: 20,
            offset: const Offset(0, 0),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Image.asset('assets/icons/app_icon.png', width: 100, height: 100),
      ),
    );
  }
}





class LaunchingControllerNative extends ChangeNotifier {
  late final AnimationController animationController;
  late final Animation<double> fadeAnimation;
  final TickerProvider vsync;
  final Function(String) onNavigate;

  bool _isFontLoaded = false;
  String _statusText = "loading...";

  bool get isFontLoaded => _isFontLoaded;
  String get statusText => _statusText;

  LaunchingControllerNative({
    required this.vsync,
    required this.onNavigate,
  });

  Future<void> initialize() async {
    _initializeAnimations();
    await _loadFonts();
    await _startNavigationTimer();
  }

  void _initializeAnimations() {
    // 初始化动画控制器
    animationController = AnimationController(
      duration: const Duration(milliseconds: animationDuration),
      vsync: vsync,
    );
    // 创建淡入动画
    fadeAnimation = Tween<double>(begin: 0.0, end: 1).animate(animationController);
    // 开始动画
    animationController.forward();
  }

  Future<void> _loadFonts() async {
    _updateStatusText("Loading...");
    try {
      if (kIsWeb) {
        await _loadWebFonts();
      } else {
        await _loadNativeFonts();
      }
      logger.i("字体加载完成");
      _isFontLoaded = true;
      _updateStatusText(appNameIntro);
    } catch (e) {
      logger.e("字体加载失败: $e");
      _updateStatusText(appNameIntro);
      _isFontLoaded = true;
    }
  }

  // 加载Web字体
  Future<void> _loadWebFonts() async {
    // 等待2秒
    await Future.delayed(const Duration(milliseconds: waitLoadingFontsDuration));
  }

  // 加载本地字体
  Future<void> _loadNativeFonts() async {
    final fontLoader = FontLoader('Noto Sans SC');
    fontLoader.addFont(rootBundle.load('assets/fonts/NotoSansSC-Regular.otf'));
    fontLoader.addFont(rootBundle.load('assets/fonts/NotoSansSC-Medium.otf'));
    fontLoader.addFont(rootBundle.load('assets/fonts/NotoSansSC-Bold.otf'));
    await fontLoader.load();
    await Future.delayed(const Duration(milliseconds: waitLoadingFontsDuration));
  }

  // 启动导航计时器
  Future<void> _startNavigationTimer() async {
    // 等待字体加载完成
    while (!_isFontLoaded) {
      await Future.delayed(const Duration(milliseconds: 500));
    }
    
    // 等待动画完成
    if (!animationController.isCompleted) {
      await animationController.forward().orCancel.catchError((_) {
        // 处理可能的动画取消错误
        logger.w("动画被取消");
      });
    }
    
    // 额外等待一小段时间，确保视觉效果完整
    await Future.delayed(const Duration(milliseconds: animationIntroWaitDuration));
    
    // 根据登录状态决定导航目标
    _navigateBasedOnAuthStatus();
  }
  
  // 根据登录状态决定导航目标
  void _navigateBasedOnAuthStatus() {
    // 检查用户是否已登录
    if (AppManager.userInfo == null || AppManager.userInfo?.accessToken == null) {
      logger.i("启动完成：用户未登录，导航到登录页面");
      onNavigate('/auth');
    } else {
      logger.i("启动完成：用户已登录，导航到仪表盘");
      onNavigate('/'); // 使用具体的路由路径
    }
  }

  void _updateStatusText(String text) {
    _statusText = text;
    notifyListeners();
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }
}
