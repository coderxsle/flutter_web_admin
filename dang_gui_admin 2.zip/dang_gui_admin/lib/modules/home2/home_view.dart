import 'package:dang_gui_admin/layout/layout_index.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:dang_gui_admin/theme/app_theme.dart';
import 'package:dang_gui_admin/app_manager.dart';
import '../../theme/theme_controller.dart';
import '../../theme/theme_selector.dart';
import 'controller.dart';

class HomeView2 extends GetView<HomeController2> {
  const HomeView2({super.key});

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('首页'),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Icon(
                Icons.home,
                size: 64,
                color: Theme.of(context).primaryColor,
              ),
              const SizedBox(height: 16),
              Text(
                '欢迎使用 Flutter 布局系统',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                '这是一个完全基于 Flutter 实现的管理后台布局系统',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 32),
              Wrap(
                spacing: 16,
                children: [
                  ElevatedButton(
                    onPressed: () => Get.find<AppLayoutController>().layout = LayoutType.defaultLayout,
                    child: const Text('默认布局'),
                  ),
                  ElevatedButton(
                    onPressed: () => Get.find<AppLayoutController>().layout = LayoutType.mix,
                    child: const Text('混合布局'),
                  ),
                  ElevatedButton(
                    onPressed: () => Get.find<AppLayoutController>().layout = LayoutType.top,
                    child: const Text('顶部布局'),
                  ),
                ],
              ),

            const Text(
              '这是首页',
              style: TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 20),
            // 添加提示
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.info_outline, 
                       color: Theme.of(context).colorScheme.onPrimaryContainer),
                  const SizedBox(width: 8),
                  Text(
                    '点击导航栏右侧的调色板图标打开主题设置',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Get.toNamed('/second'),
              child: const Text('跳转到第二页'),
            ),
            const SizedBox(height: 20),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(
                      '当前主题',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Obx(() {
                      final themeController = Get.find<ThemeController>();
                      final themeName = themeController.getThemeTypeName(
                        themeController.currentThemeType.value,
                      );
                      final modeName = AppTheme.isDarkMode() ? '浅色' : '深色';
                      return Text('$themeName - $modeName');
                    }),
                  ],
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () => Get.toNamed('/recording'),
              child: const Text('讯飞实时转写'),
            ),
            ElevatedButton(
              onPressed: () => Get.toNamed('/realtime'),
              child: const Text('会议录音2'),
            ),
            ElevatedButton(
              onPressed: () => Get.toNamed('/funasr'),
              // 盛邦议录 录 禄 同音，有福禄、俸禄之意
              child: const Text('盛邦议录'),
            ),
            ElevatedButton(
              onPressed: () => Get.toNamed('/demo'),
              // 盛邦议录 录 禄 同音，有福禄、俸禄之意
              child: const Text('组件演示'),
            ),
          ],
        ),
      ),
    );
  }
}
