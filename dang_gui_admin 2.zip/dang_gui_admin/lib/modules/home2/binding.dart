import 'package:get/get.dart';

import 'controller.dart';

class HomeBinding2 extends Binding {
  @override
  List<Bind> dependencies() {
    return [
      Bind.lazyPut<HomeController2>(() => HomeController2()),
    ];
  }
}
