import 'package:get/get.dart';

class ThemeSettingsBinding extends Binding {
  @override
  List<Bind> dependencies() {
    return [
      // 我们不需要为主题设置页面注入任何特定的控制器，因为 ThemeController 已经在应用程序启动时注入
      Bind.put(() => 1), // 添加一个虚拟的绑定项，以满足 GetX 要求
    ];
  }
} 