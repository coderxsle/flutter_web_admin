import 'package:flutter/material.dart';

import 'typewriter_text.dart';

class SpeedControlPanel extends StatefulWidget {
  final TypewriterController controller;
  
  const SpeedControlPanel({
    super.key,
    required this.controller,
  });
  
  @override
  State<SpeedControlPanel> createState() => _SpeedControlPanelState();
}

class _SpeedControlPanelState extends State<SpeedControlPanel> {
  double _baseSpeed = 1.0;
  double _variation = 0.3;
  bool _enablePauses = true;
  
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('打字速度控制', style: Theme.of(context).textTheme.titleMedium),
            
            const SizedBox(height: 16),
            
            Row(
              children: [
                const Text('基础速度:'),
                Expanded(
                  child: Slider(
                    value: _baseSpeed,
                    min: 0.5,
                    max: 2.0,
                    onChanged: (value) {
                      setState(() {
                        _baseSpeed = value;
                        widget.controller.setSpeed(_baseSpeed);
                      });
                    },
                  ),
                ),
                Text('${_baseSpeed.toStringAsFixed(1)}x'),
              ],
            ),
            
            Row(
              children: [
                const Text('变化范围:'),
                Expanded(
                  child: Slider(
                    value: _variation,
                    min: 0.0,
                    max: 1.0,
                    onChanged: (value) {
                      setState(() {
                        _variation = value;
                        // 这里需要为TypewriterText添加设置变化范围的方法
                      });
                    },
                  ),
                ),
                Text('${(_variation * 100).toStringAsFixed(0)}%'),
              ],
            ),
            
            SwitchListTile(
              title: const Text('随机暂停'),
              value: _enablePauses,
              onChanged: (value) {
                setState(() {
                  _enablePauses = value;
                  // 这里需要为TypewriterText添加设置是否允许随机暂停的方法
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}