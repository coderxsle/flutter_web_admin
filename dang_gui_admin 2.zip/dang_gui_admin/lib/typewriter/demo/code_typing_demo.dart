import 'package:flutter/material.dart';
import '../animated_code_typing.dart';

class CodeTypingDemo extends StatelessWidget {
  const CodeTypingDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('代码打字效果'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              AnimatedCodeTyping(
                initialCode: 'class MyClass {\n\n}',
                targetCode: 'class MyClass {\n  String methodToAnimateIn() {\n    return \'Hello world!\';\n  }\n}',
                language: 'dart',
                highlightedLines: [2, 3],
                showLineNumbers: true,
                onComplete: null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}