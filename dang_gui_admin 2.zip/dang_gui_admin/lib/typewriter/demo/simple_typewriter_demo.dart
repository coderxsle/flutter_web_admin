import 'package:flutter/material.dart';
import '../typewriter_text.dart';

class SimpleTypewriterDemo extends StatelessWidget {
  const SimpleTypewriterDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('基础打字效果'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              TypewriterText(
                text: '这是一个简单的打字效果演示，可用于标题、介绍等场景。',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
