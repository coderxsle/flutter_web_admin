import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class TypewriterText extends StatefulWidget {
  /// 要显示的文本
  final String text;

  /// 基础打字速度（毫秒/字符）
  final int baseSpeed;
  
  /// 速度变化范围百分比 (0.0-1.0)
  /// 例如：0.5表示速度可能在baseSpeed的50%到150%之间变化
  final double speedVariation;
  
  /// 是否偶尔暂停（模拟思考）
  final bool randomPauses;
  
  /// 随机暂停的概率 (0.0-1.0)
  final double pauseProbability;
  
  /// 暂停的持续时间范围（毫秒）
  final RangeValues pauseDuration;
  
  /// 自然打字模式（对空格、标点符号等使用不同速度）
  final bool naturalTyping;

  /// 是否循环播放
  final bool loop;

  /// 循环之间的延迟（毫秒）
  final int loopDelay;

  /// 文本样式
  final TextStyle? style;

  /// 打字完成后的回调
  final VoidCallback? onComplete;

  /// 打字开始前的延迟（毫秒）
  final int startDelay;

  /// 是否自动开始动画
  final bool autoStart;
  
  /// 可选的闪烁光标
  final Widget? cursor;

  const TypewriterText({
    super.key,
    required this.text,
    this.baseSpeed = 50,
    this.speedVariation = 0.3,
    this.randomPauses = true,
    this.pauseProbability = 0.1,
    this.pauseDuration = const RangeValues(300, 800),
    this.naturalTyping = true,
    this.loop = false,
    this.loopDelay = 1500,
    this.style,
    this.onComplete,
    this.startDelay = 0,
    this.autoStart = true,
    this.cursor,
  });

  @override
  State<TypewriterText> createState() => TypewriterTextState();
}

class TypewriterTextState extends State<TypewriterText> with SingleTickerProviderStateMixin {
  String _currentText = '';
  Timer? _timer;
  int _currentIndex = 0;
  bool isPlaying = false;
  final Random _random = Random();
  
  // 用于控制器访问
  final GlobalKey<TypewriterTextState> _key = GlobalKey<TypewriterTextState>();
  
  // 速度倍数调整
  double _speedMultiplier = 1.0;

  @override
  void initState() {
    super.initState();
    
    if (widget.autoStart) {
      Future.delayed(Duration(milliseconds: widget.startDelay), () {
        if (mounted) {
          _startTyping();
        }
      });
    }
  }

  @override
  void dispose() {
    _cancelTimer();
    super.dispose();
  }
  
  void _cancelTimer() {
    _timer?.cancel();
    _timer = null;
  }

  // 计算下一个字符的打字速度
  int _getNextCharSpeed() {
    if (!widget.naturalTyping && widget.speedVariation == 0) {
      // 考虑速度倍数调整
      return (widget.baseSpeed / _speedMultiplier).round();
    }
    
    double multiplier = 1.0;
    
    // 基于字符类型的自然打字速度变化
    if (widget.naturalTyping && _currentIndex < widget.text.length) {
      final char = widget.text[_currentIndex];
      
      // 标点符号通常打字较慢
      if ('.,:;!?'.contains(char)) {
        multiplier *= 1.5;
      } 
      // 空格通常打字较快
      else if (char == ' ') {
        multiplier *= 0.7;
      }
      
      // 连续输入相同字符通常较快
      if (_currentIndex > 0 && _currentIndex < widget.text.length - 1 && 
          widget.text[_currentIndex] == widget.text[_currentIndex - 1]) {
        multiplier *= 0.8;
      }
    }
    
    // 随机变化
    if (widget.speedVariation > 0) {
      // 生成一个-variation到+variation之间的随机值
      final randomVariation = ((_random.nextDouble() * 2) - 1) * widget.speedVariation;
      multiplier *= (1 + randomVariation);
    }
    
    // 确保不会太快或太慢
    multiplier = multiplier.clamp(0.5, 2.0);
    
    // 应用用户设置的速度倍数
    int finalSpeed = (widget.baseSpeed * multiplier / _speedMultiplier).round();
    
    // 确保速度不会太快太慢
    return finalSpeed.clamp(10, 300);
  }

  void _startTyping() {
    setState(() {
      isPlaying = true;
    });
    
    _typeNextChar();
  }
  
  void _typeNextChar() {
    if (_currentIndex >= widget.text.length) {
      _onTypingComplete();
      return;
    }
    
    // 计算打字速度
    final typingSpeed = _getNextCharSpeed();
    
    // 是否需要随机暂停
    final shouldPause = widget.randomPauses && 
                       _random.nextDouble() < widget.pauseProbability &&
                       _currentIndex > 0;
                       
    final delay = shouldPause
        ? _random.nextInt(widget.pauseDuration.end.toInt() - 
                         widget.pauseDuration.start.toInt()) +
          widget.pauseDuration.start.toInt()
        : typingSpeed;
    
    _timer = Timer(Duration(milliseconds: delay), () {
      if (mounted) {
        setState(() {
          _currentText += widget.text[_currentIndex];
          _currentIndex++;
        });
        _typeNextChar();
      }
    });
  }
  
  void _onTypingComplete() {
    _cancelTimer();
    
    setState(() {
      isPlaying = false;
    });
    
    if (widget.onComplete != null) {
      widget.onComplete!();
    }

    if (widget.loop) {
      Future.delayed(Duration(milliseconds: widget.loopDelay), () {
        if (mounted) {
          setState(() {
            _currentText = '';
            _currentIndex = 0;
          });
          _startTyping();
        }
      });
    }
  }

  /// 手动启动打字效果
  void startTyping() {
    if (!isPlaying) {
      setState(() {
        _currentText = '';
        _currentIndex = 0;
      });
      _startTyping();
    }
  }

  /// 暂停打字效果
  void pauseTyping() {
    if (isPlaying) {
      _cancelTimer();
      setState(() {
        isPlaying = false;
      });
    }
  }
  
  /// 恢复打字效果
  void resumeTyping() {
    if (!isPlaying && _currentIndex < widget.text.length) {
      setState(() {
        isPlaying = true;
      });
      _typeNextChar();
    }
  }
  
  /// 直接显示全文
  void showFullText() {
    _cancelTimer();
    setState(() {
      _currentText = widget.text;
      _currentIndex = widget.text.length;
      isPlaying = false;
    });
  }
  
  /// 设置速度倍数
  void setSpeedMultiplier(double multiplier) {
    if (multiplier > 0) {
      setState(() {
        _speedMultiplier = multiplier;
      });
      
      // 如果正在播放，重启计时器以应用新速度
      if (isPlaying) {
        _cancelTimer();
        _typeNextChar();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // 使用RichText让光标成为文本的一部分
    return RichText(
      text: TextSpan(
        children: [
          // 主文本
          TextSpan(
            text: _currentText,
            style: widget.style ?? const TextStyle(color: Colors.black),
          ),
          // 光标
          if (isPlaying && widget.cursor != null)
            WidgetSpan(
              child: widget.cursor!,
              alignment: PlaceholderAlignment.middle,
            ),
        ],
      ),
    );
  }
}



class TypewriterController {
  final TypewriterTextState _state;

  TypewriterController._(TypewriterTextState state) : _state = state;

  /// 创建控制器的工厂方法
  static TypewriterController? maybeOf(BuildContext context) {
    final state = context.findAncestorStateOfType<TypewriterTextState>();
    return state != null ? TypewriterController._(state) : null;
  }

  /// 开始打字
  void start() => _state.startTyping();
  
  /// 暂停打字
  void pause() => _state.pauseTyping();
  
  /// 继续打字
  void resume() => _state.resumeTyping();
  
  /// 重置打字
  void reset() => _state.startTyping();
  
  /// 立即显示全部文本
  void showFullText() => _state.showFullText();
  
  /// 调整打字速度（倍率）
  void setSpeed(double multiplier) => _state.setSpeedMultiplier(multiplier);
  
  /// 当前是否正在打字
  bool get isTyping => _state.isPlaying;
  
  /// 当前打字进度（0.0 - 1.0）
  double get progress => _state._currentIndex / (_state.widget.text.isNotEmpty ? _state.widget.text.length : 1);
}