
import 'app_launching.dart';
import 'package:get/get.dart';
import 'routes/route_listener.dart';
import 'theme/theme_controller.dart';
import 'layout/controllers/route_controller.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'bindings/initial_binding.dart';
import 'package:flutter/foundation.dart';
import 'package:dang_gui_admin/config/app_config.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'modules/auth/login_view.dart';
import 'modules/auth/binding.dart';
import 'layout/layout_binding.dart';
import 'layout/components/app_main.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 移动端/桌面端设置系统 UI；Web 不支持，需跳过
  if (!kIsWeb) {
    // 设置全屏模式（隐藏状态栏和导航栏）
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent, // 状态栏透明
        statusBarIconBrightness: Brightness.light, // 状态栏图标亮色
        systemNavigationBarColor: Colors.transparent, // 导航栏透明
        systemNavigationBarIconBrightness: Brightness.light, // 导航栏图标亮色
      ),
    );
    
    // 设置全屏模式（可选择隐藏状态栏和导航栏）
    await SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.edgeToEdge, // 边到边全屏，状态栏和导航栏半透明
      // 如果想完全隐藏状态栏和导航栏，可以使用：
      // SystemUiMode.immersiveSticky,
    );
  }
  
  await AppLaunching.launching();
  
  // 初始化依赖
  InitialBinding().dependencies();
  
  runApp(const MyApp());
}


class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();

    // 注册 RouteController
    if (!Get.isRegistered<RouteController>()) {
      Get.put(RouteController());
    }

    // 初始化路由监听器
    WidgetsBinding.instance.addPostFrameCallback((_) {
      try {
        RouteListener().delayedInitialize();
      } catch (e) {
        debugPrint('❌ [MyApp] Error setting up route listener: $e');
      }
    });
  }

  /// 获取 GetX 路由页面配置
  List<GetPage> _getPages() {
    return [
      // 认证相关页面
      GetPage(
        name: '/login',
        page: () => const LoginView(),
        binding: LoginBinding(),
      ),
      
      // 主布局页面
      GetPage(
        name: '/home',
        page: () => const AppMain(),
        binding: LayoutBinding(),
      ),
      
      // 组件页面
      GetPage(
        name: '/components',
        page: () => const AppMain(),
        binding: LayoutBinding(),
      ),
      
      GetPage(
        name: '/components/button',
        page: () => const AppMain(),
        binding: LayoutBinding(),
      ),
      
      GetPage(
        name: '/components/input',
        page: () => const AppMain(),
        binding: LayoutBinding(),
      ),
      
      // 功能页面
      GetPage(
        name: '/features',
        page: () => const AppMain(),
        binding: LayoutBinding(),
      ),
      
      GetPage(
        name: '/features/table',
        page: () => const AppMain(),
        binding: LayoutBinding(),
      ),
      
      GetPage(
        name: '/features/form',
        page: () => const AppMain(),
        binding: LayoutBinding(),
      ),
      
      // 错误页面
      GetPage(
        name: '/error',
        page: () => const AppMain(),
        binding: LayoutBinding(),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ThemeController>(
      builder: (controller) {
        return GetMaterialApp.router(
          title: appName,
          theme: controller.themeData,
          
          // 路由器配置 - 使用 GetX 5.0.0 标准方式
          routeInformationParser: GetInformationParser(
            initialRoute: '/home',
          ),
          routerDelegate: GetDelegate(
            pages: _getPages(),
          ),
          backButtonDispatcher: RootBackButtonDispatcher(),
          
          // GetX 路由页面配置（必需）
          getPages: _getPages(),
          
          // 其他配置
          debugShowCheckedModeBanner: false,
          builder: FlutterSmartDialog.init(),
          navigatorObservers: [FlutterSmartDialog.observer],
        );
      },
    );
  }

  @override
  void dispose() {
    // 清理路由监听器
    RouteListener().dispose();
    super.dispose();
  }
}